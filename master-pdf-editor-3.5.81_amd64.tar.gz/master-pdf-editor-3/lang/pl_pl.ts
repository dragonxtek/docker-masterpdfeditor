<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pl_PL">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../src/aboutdialog.ui" line="14"/>
        <source>About</source>
        <translation>O Programie</translation>
    </message>
    <message>
        <location filename="../src/aboutdialog.ui" line="60"/>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
</context>
<context>
    <name>BookmarksDialogProp</name>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="14"/>
        <source>Bookmark Properties</source>
        <translation>Właściwości Zakładek</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="24"/>
        <source>Options</source>
        <translation>Opcje</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="48"/>
        <source>Text</source>
        <translation>Tekst</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="83"/>
        <source>Set current position</source>
        <translation>Ustaw bieżącą pozycję</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="93"/>
        <source>Appearance</source>
        <translation>Wygląd</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="112"/>
        <source>Style</source>
        <translation>Styl</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="126"/>
        <source>Plain</source>
        <translation>Zwykły</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="131"/>
        <source>Italic</source>
        <translation>Kursywa</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="136"/>
        <source>Bold</source>
        <translation>Pogrubienie</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="141"/>
        <source>Italic &amp; Bold</source>
        <translation>Pogrubienie i Kursywa</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="162"/>
        <source>Color</source>
        <translation>Kolor</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="69"/>
        <source>Page Number</source>
        <translation>Numer Strony</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="176"/>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="276"/>
        <source>Actions</source>
        <translation>Akcje</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="323"/>
        <source>Delete</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="310"/>
        <source>Edit</source>
        <translation>Edytuj</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="182"/>
        <source>Add an Action</source>
        <translation>Dodaj Akcję</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="188"/>
        <source>Trigger</source>
        <translation>Wyzwalacz</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="217"/>
        <source>Action</source>
        <translation>Akcja</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="196"/>
        <source>Mouse Up</source>
        <translation>Kliknięcie</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="60"/>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="225"/>
        <source>Goto a Page View</source>
        <translation>Przejdź do Widoku Strony</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="230"/>
        <source>Open/execute a File</source>
        <translation>Otwórz Plik</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="235"/>
        <source>Open a web link</source>
        <translation>Otwórz link</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="240"/>
        <source>Reset form</source>
        <translation>Zresetuj formularz</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="245"/>
        <source>Show/Hide fields</source>
        <translation>Pokaż/Ukryj pola</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="250"/>
        <source>Submit a form</source>
        <translation>Prześlij formularz</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="255"/>
        <source>Run a JavaScript</source>
        <translation>Uruchom JavaScript</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="263"/>
        <source>Add</source>
        <translation>Dodaj</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="65"/>
        <source>untitled</source>
        <translation>bez nazwy</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="207"/>
        <source>Do you want to set the current position?</source>
        <translation>Chcesz ustawić bieżącą pozycję?</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="209"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogDeletePages</name>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="14"/>
        <source>Delete Page(s)</source>
        <translation>Usuń Stronę(y)</translation>
    </message>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="26"/>
        <source>Page Range</source>
        <translation>Zakres Stron</translation>
    </message>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="32"/>
        <source>Pages</source>
        <translation>Strony</translation>
    </message>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="58"/>
        <source>Sample: 1,6-8,12</source>
        <translation>Przykład: 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="78"/>
        <source>Current Page</source>
        <translation>Bieżąca Strona</translation>
    </message>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="88"/>
        <source>Pages from</source>
        <translation>Od strony</translation>
    </message>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="114"/>
        <source>to:</source>
        <translation>do:</translation>
    </message>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="140"/>
        <source>The removed page(s) cannot be recovered with undo operation.</source>
        <translation>Usunięte strony nie mogą być odzyskane za pomocą operacji cofania.</translation>
    </message>
</context>
<context>
    <name>DocPage</name>
    <message>
        <location filename="../src/docpage/docpage.cpp" line="17"/>
        <source>Cut</source>
        <translation type="unfinished">Wytnij</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage.cpp" line="18"/>
        <source>Copy</source>
        <translation>Kopiuj</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage.cpp" line="19"/>
        <source>Paste</source>
        <translation type="unfinished">Wklej</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage.cpp" line="20"/>
        <source>Select All</source>
        <translation>Zaznacz Wszystkie</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage.cpp" line="27"/>
        <source>Add Sticky Note</source>
        <translation type="unfinished">Dodaj Notatkę Sticky</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage.cpp" line="28"/>
        <source>Highlight Text</source>
        <translation type="unfinished">Wyróżniony Tekst</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage.cpp" line="29"/>
        <source>Strikeout Text</source>
        <translation type="unfinished">Przekreślony Tekst</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage.cpp" line="30"/>
        <source>Underline Text</source>
        <translation type="unfinished">Podreślony Tekst</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage.cpp" line="31"/>
        <source>Add Bookmark</source>
        <translation type="unfinished">Dodaj Zakładkę</translation>
    </message>
</context>
<context>
    <name>DocPageBase</name>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="78"/>
        <source>Copy</source>
        <translation>Kopiuj</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="79"/>
        <source>Cut</source>
        <translation>Wytnij</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="80"/>
        <source>Paste</source>
        <translation>Wklej</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="81"/>
        <source>Select All</source>
        <translation>Zaznacz Wszystkie</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="82"/>
        <source>Options</source>
        <translation>Opcje</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="83"/>
        <source>Edit text</source>
        <translation>Edytuj tekst</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="84"/>
        <source>Signature options</source>
        <translation>Opcje podpisu</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="85"/>
        <source>Undo</source>
        <translation>Cofnij</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="86"/>
        <source>Delete</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="87"/>
        <source>Set Fit to Page</source>
        <translation>Ustaw Dopasowanie do Strony</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="88"/>
        <source>Save Image to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="731"/>
        <source>Save As...</source>
        <translation type="unfinished">Zapisz Jako...</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="733"/>
        <source>PNG Images (*.png);;BMP Images (*.bmp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="743"/>
        <source>PNG Images (*.png)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="1470"/>
        <source>Open Image</source>
        <translation>Otwórz Obraz</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="1470"/>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image Files (*.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation type="vanished">Pliki Obrazu (*.tif *.png *.jpg *.jpeg *.bmp)</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="1503"/>
        <source>ERORR Load Image !</source>
        <translation>BŁĄD Wczytywania Obrazu!</translation>
    </message>
</context>
<context>
    <name>EditActionForm</name>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="14"/>
        <source>Action</source>
        <translation>Akcja</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="49"/>
        <source>Java script editor</source>
        <translation>Edytor JavaScript</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="80"/>
        <source>Goto a page</source>
        <translation>Idź do strony</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="99"/>
        <location filename="../src/forms/EditActionForm.ui" line="154"/>
        <location filename="../src/forms/EditActionForm.ui" line="243"/>
        <source>auto</source>
        <translation>auto</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="272"/>
        <source>Top</source>
        <translation>Góra</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="236"/>
        <source>Left</source>
        <translation>Lewa</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="92"/>
        <source>Page Number</source>
        <translation>Numer Strony</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="279"/>
        <source>Zoom (%)</source>
        <translation>Powiększenie (%)</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="319"/>
        <location filename="../src/forms/EditActionForm.cpp" line="153"/>
        <source>Open/execute a File</source>
        <translation>Otwórz Plik</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="325"/>
        <source>Edit a file</source>
        <translation>Edytuj plik</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="450"/>
        <source>Show</source>
        <translation>Pokaż</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="362"/>
        <location filename="../src/forms/EditActionForm.ui" line="368"/>
        <location filename="../src/forms/EditActionForm.ui" line="517"/>
        <source>Select Fields</source>
        <translation>Zaznacz Pola</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="411"/>
        <location filename="../src/forms/EditActionForm.ui" line="543"/>
        <source>Deselect All</source>
        <translation>Odznacz Wszystkie</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="437"/>
        <source>Hide</source>
        <translation>Ukryj</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="398"/>
        <location filename="../src/forms/EditActionForm.ui" line="523"/>
        <source>Select All</source>
        <translation>Zaznacz Wszystkie</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="86"/>
        <source>Options</source>
        <translation>Opcje</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="157"/>
        <location filename="../src/forms/EditActionForm.ui" line="246"/>
        <source> px</source>
        <translation>px</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="229"/>
        <source>Zoom Mode</source>
        <translation>Tryb Powiększenia</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="181"/>
        <source>Custom</source>
        <translation>Niestandardowy</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="186"/>
        <source>Inherit Zoom</source>
        <translation>Dziedziczenie Powiększenia</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="191"/>
        <source>Fit Page</source>
        <translation>Dopasuj do Strony</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="196"/>
        <source>Fit Width</source>
        <translation>Dopasuj Do Szerokości</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="201"/>
        <source>FitV</source>
        <translation>Dopasuj do Widoku</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="206"/>
        <source>FitR</source>
        <translation>FitR</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="211"/>
        <source>FitB</source>
        <translation>FitB</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="216"/>
        <source>FitBH</source>
        <translation>FitBH</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="221"/>
        <source>FitBV</source>
        <translation>FitBV</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="335"/>
        <location filename="../src/forms/EditActionForm.ui" line="608"/>
        <source>Browse</source>
        <translation>Przeglądaj</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="464"/>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="470"/>
        <source>FDF</source>
        <translation>FDF</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="480"/>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="487"/>
        <source>XFDF</source>
        <translation>XFDF</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="494"/>
        <source>PDF</source>
        <translation>PDF</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="556"/>
        <source>Method</source>
        <translation>Metoda</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="563"/>
        <source>Local file</source>
        <translation>Plik lokalny</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="568"/>
        <source>E-mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="573"/>
        <source>FTP</source>
        <translation>FTP</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="578"/>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="621"/>
        <source>Use anonymous</source>
        <translation>Anominowo</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="628"/>
        <source>Need user name and password</source>
        <translation>Nazwa użytkownika i hasło</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="638"/>
        <source>User name</source>
        <translation>Nazwa użytkownika</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="661"/>
        <source>Password</source>
        <translation>Hasło</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="112"/>
        <location filename="../src/forms/EditActionForm.cpp" line="126"/>
        <source>Open File</source>
        <translation>Otwórz Plik</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="114"/>
        <location filename="../src/forms/EditActionForm.cpp" line="128"/>
        <source>All Files (*.*)</source>
        <translation>Wszystkie Pliki (*.*)</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="154"/>
        <source>Enter a file:</source>
        <translation>Wybierz plik:</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="161"/>
        <source>Open a web link</source>
        <translation>Otwórz link</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="163"/>
        <source>Enter a web site:</source>
        <translation>Wpisz stronę sieciową:</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="214"/>
        <source>Show/Hide Fields</source>
        <translation>Pokaż/Ukryj Pola</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="218"/>
        <source>Select Field</source>
        <translation>Zaznacz Pole</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="247"/>
        <source>Reset Form</source>
        <translation>Zresetuj Formularz</translation>
    </message>
</context>
<context>
    <name>EditActionSmallForm</name>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="14"/>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="116"/>
        <source>Action</source>
        <translation>Akcja</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="27"/>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="99"/>
        <source>Open/execute a File</source>
        <translation>Otwórz Plik</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="36"/>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="100"/>
        <source>Enter a file:</source>
        <translation>Wybierz plik:</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="49"/>
        <source>Browse</source>
        <translation>Przeglądaj</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="76"/>
        <source>Goto a page</source>
        <translation>Idź do strony</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="82"/>
        <source>Page Number</source>
        <translation>Numer Strony</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="89"/>
        <source>Zoom Mode</source>
        <translation>Tryb Powiększenia</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="96"/>
        <source>Zoom (%)</source>
        <translation>Powiększenie (%)</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="103"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="110"/>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="134"/>
        <source>XYZ</source>
        <translation>XYZ</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="139"/>
        <source>Fit</source>
        <translation>Dopasuj</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="144"/>
        <source>FitH</source>
        <translation>Dopasuj do wysokości</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="149"/>
        <source>FitV</source>
        <translation>Dopasuj do widoku</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="154"/>
        <source>FitR</source>
        <translation>FitR</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="159"/>
        <source>FitB</source>
        <translation>FitB</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="164"/>
        <source>FitBH</source>
        <translation>FitBH</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="169"/>
        <source>FitBV</source>
        <translation>FitBV</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="177"/>
        <location filename="../src/forms/EditActionSmallForm.ui" line="193"/>
        <location filename="../src/forms/EditActionSmallForm.ui" line="209"/>
        <source>auto</source>
        <translation>auto</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="196"/>
        <location filename="../src/forms/EditActionSmallForm.ui" line="212"/>
        <source> px</source>
        <translation> px</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="107"/>
        <source>Open a web link</source>
        <translation>Otwórz link</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="108"/>
        <source>Enter a web site:</source>
        <translation>Wpisz adres strony internetowej:</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="115"/>
        <source>Named Action</source>
        <translation>Nazwana Akcja</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="165"/>
        <source>Open File</source>
        <translation>Otwórz Plik</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="167"/>
        <source>All Files (*.*)</source>
        <translation>Wszystkie Pliki (*.*)</translation>
    </message>
</context>
<context>
    <name>ExportPageDialog</name>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="14"/>
        <source>Extract Pages</source>
        <translation>Wyodrębnij Strony</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="26"/>
        <source>File Name</source>
        <translation>Nazwa Pliku</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="54"/>
        <source>Browse</source>
        <translation>Przeglądaj</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="67"/>
        <source>Page Range</source>
        <translation>Zakres Stron</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="73"/>
        <source>Current Page</source>
        <translation>Bieżąca Strona</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="83"/>
        <source>All Pages</source>
        <translation type="unfinished">Wszystkie Strony</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="93"/>
        <source>Pages</source>
        <translation type="unfinished">Strony</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="123"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished">Przykład: 1,6-8,12</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Od strony</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">do:</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="133"/>
        <source>Extract pages as a single file</source>
        <translation>Wyodrębnij strony jako pojedynczy plik</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="143"/>
        <source>Export Bookmarks</source>
        <translation>Eksportuj Zakładki</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.cpp" line="10"/>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.cpp" line="36"/>
        <source>Export Pages</source>
        <translation>Eksportuj Strony</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.cpp" line="74"/>
        <source>Export Pages </source>
        <translation>Eksportuj Strony </translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.cpp" line="113"/>
        <source>Save As PDF</source>
        <translation>Zapisz Jako PDF</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.cpp" line="115"/>
        <source>PDF Files (*.pdf)</source>
        <translation>Pliki PDF (*.pdf)</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.cpp" line="146"/>
        <location filename="../src/ExportPageDialog.cpp" line="173"/>
        <source>Can&apos;t save to the file:</source>
        <translation>Nie można zapisać do pliku:</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.cpp" line="146"/>
        <location filename="../src/ExportPageDialog.cpp" line="173"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>Plik może być tylko do odczytu lub używany przez inną aplikację.</translation>
    </message>
</context>
<context>
    <name>FileSettings</name>
    <message>
        <location filename="../src/FileSettings.ui" line="14"/>
        <source>Document Properties</source>
        <translation>Właściwości Dokumentu</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="37"/>
        <source>Document Info</source>
        <translation>Informacja o Dokumencie</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="43"/>
        <source>PDF Information</source>
        <translation>Informacje o PDF</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="49"/>
        <source>Title</source>
        <translation>Tytuł</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="59"/>
        <source>Subject</source>
        <translation>Temat</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="69"/>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="99"/>
        <source>Keywords</source>
        <translation>Słowa Kluczowe</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="79"/>
        <source>Creator</source>
        <translation>Kreator</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="89"/>
        <source>Producer</source>
        <translation>Producent</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="113"/>
        <source>Security</source>
        <translation>Bezpieczeństwo</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="225"/>
        <source>Printing the document</source>
        <translation>Drukowanie dokumentu</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="212"/>
        <source>Print a high resolution version of the document</source>
        <translation>Drukuj wysokiej jakości wersję dokumentu</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="290"/>
        <source>Modifying document</source>
        <translation>Modyfikowanie dokumentu</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="238"/>
        <source>Fill in existing form or signature fields</source>
        <translation>Wypełnij isniejące pola formularzy i podpisów</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="303"/>
        <source>Manage Pages and bookmarks</source>
        <translation>Zarządzaj Stronami i Zakładkami</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="145"/>
        <source>No Encryption</source>
        <translation>Brak Szyfrowania</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="150"/>
        <source>Password Encryption</source>
        <translation>Szyfrowanie Hasła</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="158"/>
        <source>Change</source>
        <translation>Zmień</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="184"/>
        <source>Permissions</source>
        <translation>Uprawnienia</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="199"/>
        <source>Extract the content of the document</source>
        <translation>Wyodrębnij treść dokumentu</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="251"/>
        <source>Content copying for accessibility</source>
        <translation>Kopiowanie treści dla ułatwienia dostępu</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="277"/>
        <source>Commenting</source>
        <translation>Komentowanie</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="320"/>
        <source>Initial View</source>
        <translation>Widok Początkowy</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="342"/>
        <source>Page Mode:</source>
        <translation>Tryb Strony:</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="350"/>
        <source>Page Only</source>
        <translation>Tylko Strona</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="355"/>
        <source>Bookmarks Panel</source>
        <translation>Panel Zakładek</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="360"/>
        <source>Pages Panel</source>
        <translation>Panel Stron</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="375"/>
        <source>Attachments Panel</source>
        <translation>Panel Załączników</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="417"/>
        <source>Run JavaScript on Document Open</source>
        <translation>Uruchom JavaScript przy Otwarciu Dokumentu</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="442"/>
        <source>Add</source>
        <translation>Dodaj</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="449"/>
        <source>Edit</source>
        <translation>Edytuj</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="456"/>
        <source>Delete</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="370"/>
        <source>Layers Panel</source>
        <translation>Panel Warstw</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="365"/>
        <source>Full Screen</source>
        <translation>Pełny Ekran</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="396"/>
        <source>Open to Page:</source>
        <translation>Otwórz na Stronie:</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="410"/>
        <source>of :</source>
        <translation>z:</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="483"/>
        <source>Fonts</source>
        <translation>Czcionki</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="499"/>
        <source>Fonts used in this document</source>
        <translation>Czcionki w tym dokumencie</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.cpp" line="420"/>
        <source>Password</source>
        <translation>Hasło</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.cpp" line="421"/>
        <source>The document is protected. Please enter a permissions password:</source>
        <translation>Dokument jest chroniony. Proszę wpisać hasło uprawnień:</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.cpp" line="438"/>
        <source>Incorrect password. Please input the owner password.</source>
        <translation>Nieprawidłowe hasło.Proszę wpisać hasło właściciela.</translation>
    </message>
</context>
<context>
    <name>ImportPageDialog</name>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="14"/>
        <source>Insert Pages</source>
        <translation>Wstaw Strony</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="26"/>
        <source>Before page</source>
        <translation>Przed stroną</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="78"/>
        <source>After page</source>
        <translation>Po stronie</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="178"/>
        <source>Page Range</source>
        <translation>Zakres Stron</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="184"/>
        <source>All Pages</source>
        <translation>Wszystkie Strony</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="194"/>
        <source>Pages</source>
        <translation>Strony</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="220"/>
        <source>Sample: 1,6-8,12</source>
        <translation>Przykład: 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="230"/>
        <source>Import Bookmarks</source>
        <translation>Importuj Zakładki</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="130"/>
        <source>File Name</source>
        <translation>Nazwa Pliku</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="165"/>
        <source>Browse</source>
        <translation>Przeglądaj</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="145"/>
        <location filename="../src/ImportPageDialog.cpp" line="184"/>
        <source>Total pages :</source>
        <translation>Liczba stron:</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="20"/>
        <source>Position</source>
        <translation>Pozycja</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="107"/>
        <source>After last page</source>
        <translation>Po ostatniej stronie</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="58"/>
        <source>Before first page</source>
        <translation>Przed pierwszą stroną</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.cpp" line="10"/>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.cpp" line="108"/>
        <source>Open File</source>
        <translation>Otwórz Plik</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.cpp" line="108"/>
        <source>PDF Files (*.pdf)</source>
        <translation>Pliki PDF (*.pdf)</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.cpp" line="138"/>
        <source>Password</source>
        <translation>Hasło</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.cpp" line="139"/>
        <source>The file is protected. Please enter a Document Open Password:</source>
        <translation>Dokument jest chroniony. Proszę wpisać Hasło Otwarcia Dokumentu:</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.cpp" line="177"/>
        <source>Error read: This PDF is protected.</source>
        <translation>Błąd wczytywania: PDF jest chroniony.</translation>
    </message>
</context>
<context>
    <name>JavaScriptEditDialog</name>
    <message>
        <location filename="../src/forms/javascripteditdialog.ui" line="14"/>
        <source>Java Script Editor</source>
        <translation>Edytor JavaScript</translation>
    </message>
    <message>
        <location filename="../src/forms/javascripteditdialog.ui" line="20"/>
        <source>Function Name</source>
        <translation>Nazwa Funkcji</translation>
    </message>
    <message>
        <location filename="../src/forms/javascripteditdialog.ui" line="32"/>
        <source>Java Script</source>
        <translation>JavaScript</translation>
    </message>
</context>
<context>
    <name>MainOptionsDialog</name>
    <message>
        <source>Options</source>
        <translation type="vanished">Opcje</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="250"/>
        <source> ms</source>
        <translation> ms</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="584"/>
        <source>Smooth text and images</source>
        <translation>Płynny tekst i obrazy</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="266"/>
        <source>Time before a move or resize starts:</source>
        <translation>Rozpoczęcie ruchu i zmiany rozmiaru po:</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="279"/>
        <source>Select item by hovering the mouse</source>
        <translation>Zaznacz element przenosząc myszkę</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="46"/>
        <source>Saving Documents</source>
        <translation>Zapisywanie Dokumentów</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="86"/>
        <source>Create backup file</source>
        <translation>Utwórz kopię pliku</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="72"/>
        <source>Choice destination for &quot;Save As&quot; documents</source>
        <translation>Wybierz folder dokumentów dla &quot;Zapisz Jako&quot;</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="59"/>
        <source>Last used folder</source>
        <translation>Ostatnio używany folder</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="64"/>
        <source>Original documents folder</source>
        <translation>Folder oryginalnych dokumentów</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="195"/>
        <source>Required field highlight color</source>
        <translation>Kolor wyróżnienia wymaganych pól</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="181"/>
        <source>Highlight color</source>
        <translation>Kolor wyróżnienia</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="318"/>
        <source>Default font</source>
        <translation>Domyślna czcionka</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="768"/>
        <source>Built-in</source>
        <translation>Wbudowany</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="754"/>
        <source>Please choose the interface language</source>
        <translation>Proszę wybrać język interfejsu</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="574"/>
        <location filename="../src/mainoptionsdialog.ui" line="789"/>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation>Wymagane jest ponowne uruchomienie programu, aby wprowadzić zmiany.</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="855"/>
        <source>Never</source>
        <translation>Nigdy</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="860"/>
        <source>Weekly</source>
        <translation>Co Tydzień</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="865"/>
        <source>Monthly</source>
        <translation>Co Miesiąc</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="841"/>
        <source>Check for Updates Automatically</source>
        <translation>Sprawdź Aktualizacje Automatycznie</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="79"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="379"/>
        <source>Color</source>
        <translation>Kolor</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="330"/>
        <source>Size</source>
        <translation>Rozmiar</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="17"/>
        <source>Settings</source>
        <translation>Ustawienia</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="96"/>
        <source>History</source>
        <translation>Historia</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="108"/>
        <source>Restore last session when application start</source>
        <translation>Przywróć ostatnią sesję po uruchomieniu aplikacji</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="115"/>
        <source>Restore last view settings when reopening</source>
        <translation>Przywróć ustawienia ostatniego widoku po ponownym otwarciu</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="125"/>
        <source>Enable JavaScript</source>
        <translation>Włącz JavaScript</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="188"/>
        <source> Always hide document message bar </source>
        <translation> Zawsze ukrywaj pasek wiadomości dokumentu</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="432"/>
        <source>Default Layout and Zoom</source>
        <translation>Domyślny Układ i Powiększenie</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="438"/>
        <source>Default page layout</source>
        <translation>Domyślny układ strony</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="456"/>
        <location filename="../src/mainoptionsdialog.ui" line="533"/>
        <source>Automatic</source>
        <translation>Automatyczny</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="538"/>
        <source>Single Page</source>
        <translation>Pojedyncza Strona</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="543"/>
        <source>Facing Pages</source>
        <translation>Strony Przeciwległe</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="445"/>
        <source>Zoom</source>
        <translation>Powiększenie</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="408"/>
        <source>Automatically change font when editing text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="461"/>
        <source>Actual Size</source>
        <translation>Rzeczywisty Rozmiar</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="466"/>
        <source>Fit Page</source>
        <translation>Dopasuj do Strony</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="471"/>
        <source>Fit Width</source>
        <translation>Dopasuj do Szerokości</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="476"/>
        <source>25%</source>
        <translation>25%</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="481"/>
        <source>50%</source>
        <translation>50%</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="486"/>
        <source>75%</source>
        <translation>75%</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="491"/>
        <source>100%</source>
        <translation>100%</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="496"/>
        <source>125%</source>
        <translation>125%</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="501"/>
        <source>150%</source>
        <translation>150%</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="506"/>
        <source>200%</source>
        <translation>200%</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="511"/>
        <source>300%</source>
        <translation>300%</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="516"/>
        <source>400%</source>
        <translation>400%</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="521"/>
        <source>600%</source>
        <translation>600%</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="590"/>
        <location filename="../src/mainoptionsdialog.ui" line="691"/>
        <source>Text</source>
        <translation>Tekst</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="597"/>
        <source>Bitmap Images</source>
        <translation>Obrazy Map Bitowych</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="604"/>
        <source>Vector Images</source>
        <translation>Obrazy Wektorowe</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="633"/>
        <source>System PPI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="679"/>
        <source>Replace Document Colors</source>
        <translation>Zamień Kolory Dokumentu</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="698"/>
        <source>Page Background</source>
        <translation>Tło Strony</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="551"/>
        <source> Always show Object Inspector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="561"/>
        <source>Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="567"/>
        <source>Fusion Dark Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="627"/>
        <source>Resolution</source>
        <translation type="unfinished">Rozdzielczość</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="643"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="721"/>
        <source>Icons in menus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="930"/>
        <source>toolBar</source>
        <translation>Pasek Narzędzi</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="972"/>
        <location filename="../src/mainoptionsdialog.ui" line="975"/>
        <source>System</source>
        <translation>System</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="987"/>
        <source>Language</source>
        <translation>Język</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="999"/>
        <source>Update</source>
        <translation>Aktualizacja</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="1011"/>
        <source>Forms</source>
        <translation>Formularze</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="1023"/>
        <source>Editing</source>
        <translation>Edytowanie</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="1035"/>
        <source>Display</source>
        <translation>Wyświetlanie</translation>
    </message>
    <message>
        <source>T_Select directory</source>
        <translation type="vanished">Wybierz katalog</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="318"/>
        <source>Select directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="614"/>
        <source>Arabic</source>
        <translation>Arabski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="615"/>
        <source>Armenian</source>
        <translation>Armeński</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="616"/>
        <source>Bulgarian</source>
        <translation>Bułgarski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="617"/>
        <source>Catalan</source>
        <translation>Kataloński</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="618"/>
        <source>Chinese-Simplified</source>
        <translation>Chiński-Uproszczony</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="619"/>
        <source>Chinese-Traditional</source>
        <translation>Chiński-Tradycyjny</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="620"/>
        <source>Czech</source>
        <translation>Czeski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="621"/>
        <source>Danish</source>
        <translation>Duński</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="622"/>
        <source>Dutch</source>
        <translation>Holenderski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="623"/>
        <source>English</source>
        <translation>Angielski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="624"/>
        <source>Estonian</source>
        <translation>Estoński</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="625"/>
        <source>Finnish</source>
        <translation>Fiński</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="626"/>
        <source>French</source>
        <translation>Francuski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="627"/>
        <source>Galician</source>
        <translation>Galicyjski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="628"/>
        <source>German</source>
        <translation>Niemiecki</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="629"/>
        <source>Greek</source>
        <translation>Grecki</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="630"/>
        <source>Hebrew</source>
        <translation>Hebrajski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="631"/>
        <source>Hungarian</source>
        <translation>Węgierski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="632"/>
        <source>Irish</source>
        <translation>Irlandzki</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="633"/>
        <source>Italian</source>
        <translation>Włoski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="634"/>
        <source>Japanese</source>
        <translation>Japoński</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="635"/>
        <source>Korean</source>
        <translation>Koreański</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="636"/>
        <source>Latvian</source>
        <translation>Łotewski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="637"/>
        <source>Lithuanian</source>
        <translation>Litewski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="638"/>
        <source>Norwegian</source>
        <translation>Norweski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="639"/>
        <source>Norwegian-Nynorsk</source>
        <translation>Norweski-Nynorsk</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="640"/>
        <source>Polish</source>
        <translation>Polski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="641"/>
        <source>Portuguese</source>
        <translation>Portugalski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="642"/>
        <source>Portuguese-Brazilian</source>
        <translation>Portugalski-Brazylijski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="643"/>
        <source>Romanian</source>
        <translation>Rumuński</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="644"/>
        <source>Russian</source>
        <translation>Rosyjski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="645"/>
        <source>Serbian</source>
        <translation>Serbski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="646"/>
        <source>Slovak</source>
        <translation>Słowacki</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="647"/>
        <source>Slovenian</source>
        <translation>Słoweński</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="648"/>
        <source>Spanish</source>
        <translation>Hiszpański</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="649"/>
        <source>Swedish</source>
        <translation>Szwedzki</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="650"/>
        <source>Thai</source>
        <translation>Tajski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="651"/>
        <source>Turkish</source>
        <translation>Turecki</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="652"/>
        <source>Ukrainian</source>
        <translation>Ukraiński</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="653"/>
        <source>Valencian</source>
        <translation>Walencki</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="654"/>
        <source>Vietnamese</source>
        <translation>Wietnamski</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="36"/>
        <source>File</source>
        <translation>Plik</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="46"/>
        <source>Export to</source>
        <translation>Eksportuj do</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="137"/>
        <location filename="../src/mainwindow.ui" line="1318"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="310"/>
        <source>Edit</source>
        <translation>Edytuj</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="141"/>
        <source>Align Objects</source>
        <translation>Wyrównaj Obiekty</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="68"/>
        <location filename="../src/mainwindow.ui" line="1310"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="334"/>
        <source>View</source>
        <translation>Widok</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="165"/>
        <source>Document</source>
        <translation>Dokument</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="95"/>
        <source>Help</source>
        <translation>Pomoc</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="193"/>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="113"/>
        <source>Insert</source>
        <translation>Wstaw</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="180"/>
        <location filename="../src/mainwindow.ui" line="1334"/>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="102"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="412"/>
        <source>Comments</source>
        <translation>Komentarze</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="105"/>
        <location filename="../src/mainwindow.ui" line="1326"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="380"/>
        <source>Tools</source>
        <translation>Narzędzia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="689"/>
        <source>New</source>
        <translation>Nowy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="695"/>
        <location filename="../src/mainwindow.cpp" line="1916"/>
        <source>Create a new blank PDF</source>
        <translation>Utwórz pusty plik PDF</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="698"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="219"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="294"/>
        <source>Open</source>
        <translation>Otwórz</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="222"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Open File (Ctrl+O)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Open a PDF or XPS file&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="234"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="281"/>
        <source>Select text for copying and pasting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="284"/>
        <source>Alt+5</source>
        <translation>Alt+5</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="318"/>
        <source>PgUp</source>
        <translation>PgUp</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="333"/>
        <source>PgDown</source>
        <translation>PgDown</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="374"/>
        <source>Ctrl+0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="403"/>
        <source>Ctrl+H</source>
        <translation>Ctrl+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="429"/>
        <source>Ctrl+1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="447"/>
        <source>Ctrl+2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="456"/>
        <location filename="../src/mainwindow.cpp" line="1619"/>
        <source>Save</source>
        <translation>Zapisz</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="459"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Save (Ctrl+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Save the document&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="468"/>
        <source>Save the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="471"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="480"/>
        <location filename="../src/mainwindow.cpp" line="402"/>
        <location filename="../src/mainwindow.cpp" line="3044"/>
        <location filename="../src/mainwindow.cpp" line="3101"/>
        <source>Save As...</source>
        <translation>Zapisz Jako...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="483"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Save As PDF(Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Save the document with a new name&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="491"/>
        <source>Save the document with a new name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="503"/>
        <source>Print</source>
        <translation>Drukuj</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="506"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print (Ctrl+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Drukuj (Ctrl+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Drukuj dokument&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="509"/>
        <source>Print the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="512"/>
        <source>Ctrl+P</source>
        <translation>Ctrl+P</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="517"/>
        <location filename="../src/mainwindow.ui" line="520"/>
        <source>Close</source>
        <translation>Zamknij</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="523"/>
        <source>Ctrl+W</source>
        <translation>Ctrl+W</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="528"/>
        <location filename="../src/mainwindow.ui" line="531"/>
        <source>Exit</source>
        <translation>Wyjdź</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="552"/>
        <source>Ctrl+3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="583"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Document (Alt+1)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select and edit text, images, annotations, form fields ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="586"/>
        <source>Select and edit text, images, annotations, form fields ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="607"/>
        <source>Select text for editing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="610"/>
        <source>Alt+2</source>
        <translation>Alt+2</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="619"/>
        <source>Delete</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="622"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Delete Object(s) (Del)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Delete the currently selected object(s)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="631"/>
        <source>Delete the currently selected object(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="660"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Form (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select form and annotations for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="692"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;New (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Create a new blank PDF&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="717"/>
        <source>Ctrl+Shift+P</source>
        <translation>Ctrl+Shift+P</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="732"/>
        <source>Cut the selection Object(s) and place on the Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="750"/>
        <source>Copy the selection Object(s) and place on the Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="768"/>
        <source>Paste from the Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="801"/>
        <source>Ctrl+F</source>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="816"/>
        <source>Undo the last action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="834"/>
        <source>Redo the previously undone action.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="852"/>
        <source>Send to Back selected object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="861"/>
        <source>Bring to Front</source>
        <translation>Przesuń na Wierzch</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="864"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Bring To Front&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Bring to Front selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Przesuń na Wierzch&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Przesuń na Wierzch zaznaczony obiekt.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="867"/>
        <source>Bring to Front selected object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="914"/>
        <source>Ctrl+Shift+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="933"/>
        <source>Ctrl+Shift+L</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="944"/>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="949"/>
        <location filename="../src/mainwindow.ui" line="952"/>
        <source>Extract Pages...</source>
        <translation>Wyodrębnij Strony...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="955"/>
        <source>Ctrl+Shift+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="960"/>
        <location filename="../src/mainwindow.ui" line="963"/>
        <source>Insert Pages...</source>
        <translation>Wstaw Strony...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="966"/>
        <source>Ctrl+Shift+I</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="986"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Properties (Ctrl+D)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Open window with document properties&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="994"/>
        <source>Open window with document properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1012"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Sticky Note&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Click the page to add a note at that position&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1015"/>
        <source>Click the page to add a note at that position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1018"/>
        <source>Ctrl+6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1063"/>
        <location filename="../src/mainwindow.cpp" line="2448"/>
        <source>Text</source>
        <translation>Tekst</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1066"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Text (Ctrl+T)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new text to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1074"/>
        <source>Insert new text to current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1077"/>
        <source>Ctrl+T</source>
        <translation>Ctrl+T</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1086"/>
        <location filename="../src/mainwindow.cpp" line="2457"/>
        <source>Image</source>
        <translation>Obraz</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1089"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Image (Ctrl+I)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new image to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1097"/>
        <source>Insert new image to current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1100"/>
        <source>Ctrl+I</source>
        <translation>Ctrl+I</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1160"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Link (Ctrl+L)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new link to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1168"/>
        <source>Insert new link to current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1354"/>
        <location filename="../src/mainwindow.ui" line="1357"/>
        <source>Open Object Inspector</source>
        <translation>Otwórz Inspektora Obiektów</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1362"/>
        <location filename="../src/mainwindow.ui" line="1365"/>
        <source>Crop Pages</source>
        <translation>Przytnij Strony</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1368"/>
        <source>Ctrl+K</source>
        <translation>Ctrl+K</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1377"/>
        <location filename="../src/mainwindow.ui" line="1380"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation>Obróć o 90 stopni Zgodnie z Zegarem</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1389"/>
        <location filename="../src/mainwindow.ui" line="1392"/>
        <location filename="../src/mainwindow.ui" line="1395"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation>Obróć o 90 stopni Przeciwnie do Zegara</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1400"/>
        <source>Export Form Data...</source>
        <translation type="unfinished">Eksportuj dane formularza...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1405"/>
        <source>Import Form Data...</source>
        <translation type="unfinished">Importuj dane formularza...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1410"/>
        <source>Export Comments Data...</source>
        <translation type="unfinished">Eksportuj dane...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1415"/>
        <source>Import Comments Data...</source>
        <translation type="unfinished">Importuj dane...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1420"/>
        <source>Save Optimized As...</source>
        <translation>Zoptymalizowany plik PDF</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1423"/>
        <source>Ctrl+Alt+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1434"/>
        <source>F3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FDF</source>
        <translation type="vanished">FDF</translation>
    </message>
    <message>
        <source>Export Data...</source>
        <translation type="vanished">Eksportuj dane formularza...</translation>
    </message>
    <message>
        <source>Import Data...</source>
        <translation type="vanished">Importuj dane formularza...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="846"/>
        <source>Send to Back</source>
        <translation>Przesuń pod Spód</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="849"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Send to Back&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send to Back selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Przesuń pod Spód&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Przesuń pod Spód zaznaczony obiekt.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="634"/>
        <source>Del</source>
        <translation>Del</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1294"/>
        <source>Statusbar</source>
        <translation>Pasek Stanu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="297"/>
        <location filename="../src/mainwindow.ui" line="300"/>
        <source>First Page</source>
        <translation>Pierwsza Strona</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="312"/>
        <location filename="../src/mainwindow.ui" line="315"/>
        <source>Previous Page</source>
        <translation>Poprzednia Strona</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="327"/>
        <location filename="../src/mainwindow.ui" line="330"/>
        <source>Next Page</source>
        <translation>Następna Strona</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="338"/>
        <location filename="../src/mainwindow.ui" line="341"/>
        <source>Last Page</source>
        <translation>Ostatnia Strona</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="645"/>
        <source>Alt+Del</source>
        <translation>Alt+Del</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1195"/>
        <location filename="../src/mainwindow.ui" line="1198"/>
        <source>Check box</source>
        <translation>Pole wyboru</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1180"/>
        <location filename="../src/mainwindow.ui" line="1183"/>
        <source>Edit Box</source>
        <translation>Pole Edycji</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1207"/>
        <location filename="../src/mainwindow.ui" line="1210"/>
        <source>Radio button</source>
        <translation>Przycisk Radiowy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1231"/>
        <location filename="../src/mainwindow.ui" line="1234"/>
        <source>List box</source>
        <translation>Pole listy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1219"/>
        <location filename="../src/mainwindow.ui" line="1222"/>
        <source>Combo box</source>
        <translation>Pole kombi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1302"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="286"/>
        <source>Main</source>
        <translation>Główny</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1255"/>
        <location filename="../src/mainwindow.ui" line="1258"/>
        <source>Signature</source>
        <translation>Podpis</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="765"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Paste (Ctrl+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Paste from the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Wklej (Ctrl+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Wklej ze Schowka&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="787"/>
        <location filename="../src/mainwindow.ui" line="790"/>
        <source>Set Fit to Page</source>
        <translation>Ustaw Dopasowanie do Strony</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1109"/>
        <location filename="../src/mainwindow.ui" line="1112"/>
        <source>Line</source>
        <translation>Linia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1121"/>
        <location filename="../src/mainwindow.ui" line="1124"/>
        <source>Rectangle</source>
        <translation>Prostokąt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1133"/>
        <location filename="../src/mainwindow.ui" line="1136"/>
        <source>Ellipse</source>
        <translation>Elipsa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="711"/>
        <location filename="../src/mainwindow.ui" line="714"/>
        <source>Print Preview</source>
        <translation>Podgląd Wydruku</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="876"/>
        <location filename="../src/mainwindow.ui" line="879"/>
        <source>Align Left</source>
        <translation>Wyrównaj do Lewej</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="888"/>
        <location filename="../src/mainwindow.ui" line="891"/>
        <source>Align Right</source>
        <translation>Wyrównaj do Prawej</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="900"/>
        <location filename="../src/mainwindow.ui" line="903"/>
        <source>Align Top</source>
        <translation>Wyrównaj do Góry</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="975"/>
        <location filename="../src/mainwindow.ui" line="978"/>
        <source>Align Bottom</source>
        <translation>Wyrównaj do Dołu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="565"/>
        <location filename="../src/mainwindow.ui" line="568"/>
        <source>Reduce Page Thumbnails</source>
        <translation>Zmniejsz Miniatury Stron</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="557"/>
        <location filename="../src/mainwindow.ui" line="560"/>
        <source>Enlarge Page Thumbnails</source>
        <translation>Powiększ Miniatury Stron</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="703"/>
        <location filename="../src/mainwindow.ui" line="706"/>
        <source>Images</source>
        <translation>Obrazy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="908"/>
        <location filename="../src/mainwindow.ui" line="911"/>
        <source>Insert Blank Pages</source>
        <translation>Wstaw Puste Strony</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="983"/>
        <source>Properties</source>
        <translation>Właściwości</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1000"/>
        <source>Ctrl+D</source>
        <translation>Ctrl+D</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1171"/>
        <source>Ctrl+L</source>
        <translation>Ctrl+L</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1186"/>
        <source>Ctrl+E</source>
        <translation>Ctrl+E</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1273"/>
        <source>Home page</source>
        <translation>Strona domowa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1278"/>
        <source>Register...</source>
        <translation>Zarejestruj...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1283"/>
        <source>Check for Update</source>
        <translation>Sprawdź Aktualizacje</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="810"/>
        <source>Undo</source>
        <translation>Cofnij</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="813"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Undo (Ctrl+Z)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Undo the last action&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cofnij (Ctrl+Z)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cofnij ostatnią akcję&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="819"/>
        <source>Ctrl+Z</source>
        <translation>Ctrl+Z</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1145"/>
        <location filename="../src/mainwindow.ui" line="1148"/>
        <source>Pencil</source>
        <translation>Ołówek</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1243"/>
        <location filename="../src/mainwindow.ui" line="1246"/>
        <source>Button</source>
        <translation>Przycisk</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="353"/>
        <location filename="../src/mainwindow.ui" line="356"/>
        <source>Zoom In</source>
        <translation>Powiększ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="359"/>
        <source>Ctrl++</source>
        <translation>Ctrl++</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="383"/>
        <location filename="../src/mainwindow.ui" line="386"/>
        <source>Zoom Out</source>
        <translation>Pomniejsz</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="389"/>
        <source>Ctrl+-</source>
        <translation>Ctrl+-</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="368"/>
        <location filename="../src/mainwindow.ui" line="371"/>
        <source>Actual Size</source>
        <translation>Rzeczywisty Rozmiar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="289"/>
        <location filename="../src/mainwindow.ui" line="292"/>
        <source>Settings</source>
        <translation>Ustawienia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1268"/>
        <source>Contents</source>
        <translation>Spis Treści</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="397"/>
        <location filename="../src/mainwindow.ui" line="400"/>
        <source>Highlight Fields</source>
        <translation>Wyróżnione Pola</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="254"/>
        <location filename="../src/mainwindow.ui" line="260"/>
        <source>Hand Tool</source>
        <translation>Narzędzie Dłoni</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="601"/>
        <source>Edit Text</source>
        <translation>Edytuj Tekst</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="927"/>
        <location filename="../src/mainwindow.ui" line="930"/>
        <source>Page layout</source>
        <translation>Układ strony</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="828"/>
        <source>Redo</source>
        <translation>Przywróć</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="831"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redo (Ctrl+Y)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Redo the previously undone action.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Przywróć (Ctrl+Y)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Przywróć poprzednio cofniętą akcję.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="837"/>
        <source>Ctrl+Y</source>
        <translation>Ctrl+Y</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="726"/>
        <source>Cut</source>
        <translation>Wytnij</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <source>Master PDF Editor</source>
        <translation>Master PDF Editor</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="117"/>
        <location filename="../src/mainwindow.ui" line="1342"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="396"/>
        <source>Forms</source>
        <translation>Formularze</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="239"/>
        <location filename="../src/mainwindow.ui" line="242"/>
        <source>About</source>
        <translation>O Programie</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="257"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use the hand tool for moving pages, open links and selecting text.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="278"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text (Alt+5)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for copying and pasting&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="303"/>
        <source>Home</source>
        <translation>Home</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="344"/>
        <source>End</source>
        <translation>End</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="408"/>
        <location filename="../src/mainwindow.ui" line="411"/>
        <source>Reset Forms</source>
        <translation>Zresetuj Formularze</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="423"/>
        <location filename="../src/mainwindow.ui" line="426"/>
        <source>Fit Page</source>
        <translation>Dopasuj do Strony</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="441"/>
        <location filename="../src/mainwindow.ui" line="444"/>
        <source>Fit Width</source>
        <translation>Dopasuj do Szerokości</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="534"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="546"/>
        <location filename="../src/mainwindow.ui" line="549"/>
        <source>Facing Pages</source>
        <translation>Strony Przeciwległe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="604"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Text Object(Alt+2)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="639"/>
        <location filename="../src/mainwindow.ui" line="642"/>
        <source>Delete Pages</source>
        <translation>Usuń Strony</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="657"/>
        <location filename="../src/mainwindow.ui" line="663"/>
        <source>Edit Forms</source>
        <translation>Edytuj Formularze</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="680"/>
        <source>Ctrl+F11</source>
        <translation>Ctrl+F11</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;New (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Create a new blank PDF&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Nowy (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Utwórz pusty plik PDF&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="729"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cut (Ctrl+X)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cut the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Wytnij (Ctrl+X)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Wytnij zaznaczone Obiekty i umieść w Schowku&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="735"/>
        <source>Ctrl+X</source>
        <translation>Ctrl+X</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="744"/>
        <source>Copy</source>
        <translation>Kopiuj</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="747"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copy (Ctrl+C)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copy the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Kopiuj (Ctrl+C)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Kopiuj zaznaczone Obiekty i umieść w Schowku&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="753"/>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="762"/>
        <source>Paste</source>
        <translation>Wklej</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="771"/>
        <source>Ctrl+V</source>
        <translation>Ctrl+V</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="776"/>
        <location filename="../src/mainwindow.ui" line="779"/>
        <source>Select All</source>
        <translation>Zaznacz Wszystkie</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="782"/>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="580"/>
        <source>Edit Document</source>
        <translation>Edytuj Dokument</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="589"/>
        <source>Alt+1</source>
        <translation>Alt+1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1157"/>
        <source>Link</source>
        <translation>Link</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1027"/>
        <location filename="../src/mainwindow.ui" line="1030"/>
        <source>Highlight Text</source>
        <translation>Wyróżniony Tekst</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1009"/>
        <source>Add Sticky Note</source>
        <translation>Dodaj Notatkę Sticky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1039"/>
        <location filename="../src/mainwindow.ui" line="1042"/>
        <source>Strikeout Text</source>
        <translation>Przekreślony Tekst</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1051"/>
        <location filename="../src/mainwindow.ui" line="1054"/>
        <source>Underline Text</source>
        <translation>Podreślony Tekst</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="275"/>
        <source>Select Text</source>
        <translation>Zaznacz Tekst</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="666"/>
        <source>Alt+3</source>
        <translation>Alt+3</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="494"/>
        <source>Ctrl+Shift+S</source>
        <translation>Ctrl+Shift+S</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1263"/>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="795"/>
        <location filename="../src/mainwindow.ui" line="798"/>
        <location filename="../src/mainwindow.ui" line="1442"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="369"/>
        <source>Find</source>
        <translation>Znajdź</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1431"/>
        <source>Find Next</source>
        <translation>Znajdź Następne</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="938"/>
        <location filename="../src/mainwindow.ui" line="941"/>
        <source>Rotate Pages</source>
        <translation>Obróć Strony</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="919"/>
        <location filename="../src/mainwindow.ui" line="922"/>
        <source>Move Pages</source>
        <translation>Przenieś Strony</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="263"/>
        <source>Alt+4</source>
        <translation>Alt+4</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1420"/>
        <source>Open failed</source>
        <translation>Błąd otwierania</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1421"/>
        <source>Cannot open file :
</source>
        <translation>Nie można otworzyć pliku:
</translation>
    </message>
    <message>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="38"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="271"/>
        <source>Empty recent files list</source>
        <translation>Wyczyść listę ostatnich plików</translation>
    </message>
    <message>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="67"/>
        <source>Prev/Next</source>
        <translation>Poprzedni/Następny</translation>
    </message>
    <message>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="90"/>
        <source>Edit Tools</source>
        <translation>Edytuj Narzędzia</translation>
    </message>
    <message>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="146"/>
        <source>Page :</source>
        <translation>Strona:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="231"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="296"/>
        <source>Open a PDF file</source>
        <translation>Owórz plik PDF</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="383"/>
        <location filename="../src/mainwindow.cpp" line="3035"/>
        <location filename="../src/mainwindow.cpp" line="3092"/>
        <source>untitled</source>
        <translation>bez nazwy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="402"/>
        <source>PDF Files (*.pdf)</source>
        <translation>Pliki PDF (*.pdf)</translation>
    </message>
    <message>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="35"/>
        <location filename="../src/mainwindow.cpp" line="2296"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="268"/>
        <source>Recent Files</source>
        <translation>Ostatnie Pliki</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="203"/>
        <location filename="../src/mainwindow.cpp" line="268"/>
        <source>There was an error opening the document !</source>
        <translation>Wystąpił błąd podczas otwierania dokumentu!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="343"/>
        <source>Saving in XPS is temporarily not supported.
Choose PDF file name for saving.</source>
        <translation>Zapisywanie XPS jest tymczasowo nieobsługiwane.
Wybierz nazwę pliku PDF do zapisu.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="525"/>
        <source>Export completed</source>
        <translation>Eksportowanie zakończone</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="815"/>
        <source>Can&apos;t find :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1613"/>
        <source>The document %s has been modified. 
Do you want to save your changes?</source>
        <translation>Dokument %s został zmodyfikowany.
Chcesz zapisać zmiany?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1620"/>
        <source>Close Without Saving</source>
        <translation>Nie Zapisuj</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1621"/>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2442"/>
        <source>Chacters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2443"/>
        <source>Font type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2445"/>
        <source>Font Embedded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2447"/>
        <source>Font Not Embedded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2453"/>
        <location filename="../src/mainwindow.cpp" line="2503"/>
        <source>Width</source>
        <translation type="unfinished">Szerokość</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2454"/>
        <location filename="../src/mainwindow.cpp" line="2504"/>
        <source>Height</source>
        <translation type="unfinished">Wysokość</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2455"/>
        <source>Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2461"/>
        <source>Path</source>
        <translation type="unfinished">Ścieżka</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2465"/>
        <source>Shading</source>
        <translation type="unfinished">Cieniowanie</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2477"/>
        <location filename="../src/mainwindow.cpp" line="2500"/>
        <source>Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2477"/>
        <location filename="../src/mainwindow.cpp" line="2513"/>
        <source>Selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2517"/>
        <source>Page</source>
        <translation type="unfinished">Strona</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3044"/>
        <location filename="../src/mainwindow.cpp" line="3065"/>
        <location filename="../src/mainwindow.cpp" line="3068"/>
        <location filename="../src/mainwindow.cpp" line="3101"/>
        <location filename="../src/mainwindow.cpp" line="3121"/>
        <location filename="../src/mainwindow.cpp" line="3124"/>
        <source>FDF Files (*.fdf)</source>
        <translation>Pliki FDF (*.fdf)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="312"/>
        <source>The unregistered version will insert a watermark</source>
        <translation>Niezarejestrowana wersja umieści znak wodny</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1716"/>
        <source>A error occurred during the signature verification!</source>
        <translation>Pojawił się błąd podczas weryfikacji podpisu!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="359"/>
        <location filename="../src/mainwindow.cpp" line="416"/>
        <source>Save failed</source>
        <translation>Błąd zapisu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="40"/>
        <source>Ctrl+Shift++</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="41"/>
        <source>Ctrl+Shift+-</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="360"/>
        <location filename="../src/mainwindow.cpp" line="417"/>
        <source>Can&apos;t save to the file:</source>
        <translation>Nie można zapisać pliku:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="360"/>
        <location filename="../src/mainwindow.cpp" line="417"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
Plik może być tylko do odczytu lub używany przez inną aplikację.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_update.cpp" line="32"/>
        <source>Your version already has the last update!</source>
        <translation>Twoja wersja ma najnowszą aktualizację!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_update.cpp" line="40"/>
        <source>New Version Is Available !
Do you want to Download Now?</source>
        <translation>Nowa Wersja Jest Dostępna!
Chcesz Pobrać Teraz?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="278"/>
        <location filename="../src/mainwindow.cpp" line="281"/>
        <location filename="../src/mainwindow.cpp" line="3065"/>
        <location filename="../src/mainwindow.cpp" line="3068"/>
        <location filename="../src/mainwindow.cpp" line="3121"/>
        <location filename="../src/mainwindow.cpp" line="3124"/>
        <source>Open File</source>
        <translation>Otwórz Plik</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="278"/>
        <location filename="../src/mainwindow.cpp" line="281"/>
        <source>All Files (*.pdf *.xps);;PDF Files (*.pdf);;XPS Files (*.xps)</source>
        <translation>Wszystkie Pliki (*.pdf *.xps);;Pliki PDF (*.pdf);;Pliki XPS (*.xps)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="674"/>
        <location filename="../src/mainwindow.ui" line="677"/>
        <location filename="../src/mainwindow.ui" line="1351"/>
        <source>Object Inspector</source>
        <translation>Inspektor Obiektu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_tool_bars.cpp" line="432"/>
        <source>Toolbars</source>
        <translation>Paski Narzędzi</translation>
    </message>
    <message>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="76"/>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="132"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="353"/>
        <source>Zoom</source>
        <translation>Powiększenie</translation>
    </message>
</context>
<context>
    <name>MovePagesDialog</name>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="14"/>
        <source>Move Pages</source>
        <translation>Przenieś Strony</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="26"/>
        <source>Page Range</source>
        <translation>Zakres Stron</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="32"/>
        <source>Pages</source>
        <translation>Strony</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="58"/>
        <source>Sample: 1,6-8,12</source>
        <translation>Przykład: 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="78"/>
        <source>Current Page</source>
        <translation>Bieżąca Strona</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="88"/>
        <source>Pages from</source>
        <translation>Od strony</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="114"/>
        <source>to:</source>
        <translation>do:</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="140"/>
        <source>Destination</source>
        <translation>Przeznaczenie</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="152"/>
        <source>To:</source>
        <translation>Do:</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="162"/>
        <source>Page</source>
        <translation>Strona</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="211"/>
        <source>First</source>
        <translation>Pierwsza</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="218"/>
        <source>Last</source>
        <translation>Ostatnia</translation>
    </message>
</context>
<context>
    <name>NewPageDialog</name>
    <message>
        <location filename="../src/NewPageDialog.ui" line="20"/>
        <source>Page Size</source>
        <translation>Rozmiar Strony</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="191"/>
        <source>Width</source>
        <translation>Szerokość</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="228"/>
        <source>Height</source>
        <translation>Wysokość</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="30"/>
        <source>A0</source>
        <translation>A0</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="35"/>
        <source>A1</source>
        <translation>A1</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="40"/>
        <source>A2</source>
        <translation>A2</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="45"/>
        <source>A3</source>
        <translation>A3</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="50"/>
        <source>A4</source>
        <translation>A4</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="55"/>
        <source>A5</source>
        <translation>A5</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="60"/>
        <source>A6</source>
        <translation>A6</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="65"/>
        <source>A7</source>
        <translation>A7</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="70"/>
        <source>A8</source>
        <translation>A8</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="75"/>
        <source>A9</source>
        <translation>A9</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="80"/>
        <source>A10</source>
        <translation>A10</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="85"/>
        <source>Letter</source>
        <translation>Koperta</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="90"/>
        <source>Tabloid</source>
        <translation>Tabloid</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="95"/>
        <source>B0</source>
        <translation>B0</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="100"/>
        <source>B1</source>
        <translation>B1</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="105"/>
        <source>B2</source>
        <translation>B2</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="110"/>
        <source>B3</source>
        <translation>B3</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="115"/>
        <source>B4</source>
        <translation>B4</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="120"/>
        <source>B5</source>
        <translation>B5</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="125"/>
        <source>Statement</source>
        <translation>Deklaracja</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="130"/>
        <source>Executive</source>
        <translation>Executive</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="135"/>
        <source>Folio</source>
        <translation>Folio</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="140"/>
        <source>Quarto</source>
        <translation>Quarto</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="145"/>
        <source>Note</source>
        <translation>Notatka</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="150"/>
        <source>ANSI C</source>
        <translation>ANSI C</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="155"/>
        <source>ANSI D</source>
        <translation>ANSI D</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="160"/>
        <source>ANSI E</source>
        <translation>ANSI E</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="165"/>
        <source>ANSI F</source>
        <translation>ANSI F</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="170"/>
        <source>Custom page size</source>
        <translation>Niestandardowy rozmiar strony</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="215"/>
        <source>Portrait</source>
        <translation>Pionowo</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="220"/>
        <source>Landscape</source>
        <translation>Poziomo</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="264"/>
        <source>Units</source>
        <translation>Jednostki</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="272"/>
        <source>points</source>
        <translation>piksele</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="277"/>
        <source>inch</source>
        <translation>cale</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="282"/>
        <source>millimeter</source>
        <translation>milimetry</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="293"/>
        <source>Contents Size</source>
        <translation>Rozmiar Zawartości</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="305"/>
        <source>Left margin</source>
        <translation>Lewy margines</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="345"/>
        <source>Top margin</source>
        <translation>Górny margines</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="325"/>
        <source>Right margin</source>
        <translation>Prawy margines</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="365"/>
        <source>Bottom margin</source>
        <translation>Dolny margines</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="388"/>
        <source>Position</source>
        <translation>Pozycja</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="394"/>
        <source>Before current page</source>
        <translation>Przed bieżącą stroną</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="411"/>
        <source>After current page</source>
        <translation>Po bieżącej stronie</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="418"/>
        <source>After last page</source>
        <translation>Po ostatniej stronie</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="404"/>
        <source>Before first page</source>
        <translation>Przed pierwszą stroną</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="428"/>
        <source>Number of pages</source>
        <translation>Liczba stron</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="454"/>
        <source>Page(s)</source>
        <translation>Strona(y)</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="434"/>
        <source>Create</source>
        <translation>Utwórz</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.cpp" line="142"/>
        <source> px</source>
        <translation>px</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.cpp" line="166"/>
        <source> in</source>
        <translation>&quot;</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.cpp" line="188"/>
        <source> mm</source>
        <translation>mm</translation>
    </message>
</context>
<context>
    <name>ObjectInspector</name>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="60"/>
        <source>No Properties
There is no object selections.</source>
        <translation>Brak Właściwości
Nie wybrano obiektu.</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="308"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2708"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2927"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1638"/>
        <source>Text</source>
        <translation>Tekst</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="142"/>
        <source>Property</source>
        <translation>Właściwość</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="147"/>
        <source>Value</source>
        <translation>Wartość</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="443"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="647"/>
        <source>Add</source>
        <translation>Dodaj</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="453"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2390"/>
        <source>Actions</source>
        <translation>Akcje</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="475"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1672"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1706"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1778"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1834"/>
        <source>Edit</source>
        <translation>Edytuj</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="485"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="664"/>
        <source>Delete</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="541"/>
        <source>Up Label</source>
        <translation>Górna Etykieta</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="548"/>
        <source>Behavior</source>
        <translation>Zachowanie</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="562"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1096"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1258"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1413"/>
        <source>None</source>
        <translation>Brak</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="567"/>
        <source>Push</source>
        <translation>Wciśnięcie</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="572"/>
        <source>Outline</source>
        <translation>Kontur</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="577"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1101"/>
        <source>Invert</source>
        <translation>Odwrócenie</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="585"/>
        <source>Down Label</source>
        <translation>Dolna Etykieta</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="595"/>
        <source>RollOver Label</source>
        <translation>Etykieta Najechania</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="631"/>
        <source>Item</source>
        <translation>Element</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="654"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="969"/>
        <source>Export Value</source>
        <translation>Eksportuj Wartość</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="693"/>
        <source>Up</source>
        <translation>W Górę</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="706"/>
        <source>Down</source>
        <translation>W Dół</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="713"/>
        <source>Sort Items</source>
        <translation>Sortuj Elementy</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="720"/>
        <source>Commit selected value immediately</source>
        <translation>Przydziel zaznaczoną wartość natychmiast</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="727"/>
        <source>Multiple selection</source>
        <translation>Wybór wielokrotny</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="734"/>
        <source>Allow user to enter custom text</source>
        <translation>Pozwól na wpisanie niestandardowego tekstu</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="866"/>
        <source>Password</source>
        <translation>Hasło</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="859"/>
        <source>Scrollable</source>
        <translation>Przewijalny</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="852"/>
        <source>Check spelling</source>
        <translation>Sprawdzanie pisowni</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="767"/>
        <source>Limit to</source>
        <translation>Ogranicz do</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="781"/>
        <source>chars</source>
        <translation>znaków</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="788"/>
        <source>Split into</source>
        <translation>Podziel na</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="802"/>
        <source>Allow Rich Text formatting</source>
        <translation>Zezwól na Formatowanie Tekstu</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="873"/>
        <source>Multi-line</source>
        <translation>Wiele linii</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="812"/>
        <source>cells</source>
        <translation>komórki</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="820"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2195"/>
        <source>Left</source>
        <translation>Lewa</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="825"/>
        <source>Center</source>
        <translation>Wyśrodkuj</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="830"/>
        <source>Right</source>
        <translation>Do Prawej</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="838"/>
        <source>Default Value</source>
        <translation>Domyślna Wartość</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="845"/>
        <source>Alignment</source>
        <translation>Wyrównanie</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="912"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2276"/>
        <source>Style</source>
        <translation>Styl</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="923"/>
        <source>Check</source>
        <translation>Ptaszek</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="928"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="203"/>
        <source>Circle</source>
        <translation>Koło</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="933"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="205"/>
        <source>Cross</source>
        <translation>Krzyżyk</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="938"/>
        <source>Diamond</source>
        <translation>Diament</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="943"/>
        <source>Square</source>
        <translation>Kwadrat</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="948"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="214"/>
        <source>Star</source>
        <translation>Gwiazda</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="992"/>
        <source>Checked by Default</source>
        <translation>Domyślnie Zaznaczone</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1038"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2698"/>
        <source>Line Thickness</source>
        <translation>Grubość Linii</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1052"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2648"/>
        <source>Border Color</source>
        <translation>Kolor Ramki</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1059"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2691"/>
        <source>Line Style</source>
        <translation>Styl Linii</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1067"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2663"/>
        <source>Solid</source>
        <translation>Pełna</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1072"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2668"/>
        <source>Dashed</source>
        <translation>Przerywana</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1077"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2683"/>
        <source>Underline</source>
        <translation>Podkreślona</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1085"/>
        <source>Highlight</source>
        <translation>Wyróżnienie</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1106"/>
        <source>OutLine</source>
        <translation>Kontur</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1111"/>
        <source>Insert</source>
        <translation>Wciśnięcie</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1145"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Signature.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;No available options&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Podpis.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Brak dostępnych opcji&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1204"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2409"/>
        <source>Format</source>
        <translation>Formatowanie</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1244"/>
        <source>Format category</source>
        <translation>Kategoria formatowania</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1263"/>
        <source>Number</source>
        <translation>Numer</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1268"/>
        <source>Percentage</source>
        <translation>Procent</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1273"/>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1278"/>
        <source>Time</source>
        <translation>Czas</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1283"/>
        <source>Special</source>
        <translation>Specjalna</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1288"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1443"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="189"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="193"/>
        <source>Custom</source>
        <translation>Niestandardowa</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1307"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1312"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1317"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1322"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1327"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1332"/>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1337"/>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1342"/>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1347"/>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1352"/>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1357"/>
        <source>10</source>
        <translation>10</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1366"/>
        <source>1,234.56</source>
        <translation>1,234.56</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1371"/>
        <source>1234.56</source>
        <translation>1234.56</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1376"/>
        <source>1.234,56</source>
        <translation>1.234,56</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1381"/>
        <source>1234,56</source>
        <translation>1234,56</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1395"/>
        <source>Currency Symbol</source>
        <translation>Symbol Waluty</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1418"/>
        <source>Dollar ($)</source>
        <translation>Dolar ($)</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1423"/>
        <source>Euro (€)</source>
        <translation>Euro (€)</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1428"/>
        <source>Pound (£)</source>
        <translation>Funt (£)</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1433"/>
        <source>Yen (¥)</source>
        <translation>Jen (¥)</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1438"/>
        <source>Ruble (Руб)</source>
        <translation>Rubel (Руб)</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1464"/>
        <source>Show parentheses</source>
        <translation>Pokaż nawiasy</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1484"/>
        <source>Decimal Places</source>
        <translation>Miejsca Dziesiętne</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1491"/>
        <source>Separation Style</source>
        <translation>Styl Separatora</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1498"/>
        <source>Use red text</source>
        <translation>Użyj czerwonego tekstu</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1515"/>
        <source>Date Options</source>
        <translation>Opcje Daty</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1554"/>
        <source>Time Options</source>
        <translation>Opcje Czasu</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1587"/>
        <source>Special Options</source>
        <translation>Opcje Specjalne</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1645"/>
        <source>Format Script</source>
        <translation>Skrypt Formatowania</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1679"/>
        <source>KeyStroke Script</source>
        <translation>Skrypt Naciśnięcia Klawisza</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1730"/>
        <source>Validate</source>
        <translation>Weryfikacja</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1751"/>
        <source>Validation Script</source>
        <translation>Skrypt Weryfikacji</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1786"/>
        <source>Calculate</source>
        <translation>Kalkulacja</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1807"/>
        <source>Calculation Script</source>
        <translation>Skrypt Kalkulowania</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1936"/>
        <source>Full text</source>
        <translation>Pełny tekst</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1941"/>
        <source>Stroke Text</source>
        <translation>Obramowany Tekst</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1946"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2488"/>
        <source>Full and Stroke</source>
        <translation>Pełny i Obramowany</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1951"/>
        <source>Invisible</source>
        <translation>Niewidoczny</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1965"/>
        <source>Full Color</source>
        <translation>Pełny Kolor</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1991"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2556"/>
        <source>Line Width</source>
        <translation>Szerokość Linii</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2020"/>
        <source>Character spacing</source>
        <translation>Odstępy między znakami</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2027"/>
        <source>Word spacing</source>
        <translation>Odstępy między wyrazami</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2061"/>
        <source>F</source>
        <translation>F</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2087"/>
        <source>D</source>
        <translation>D</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2097"/>
        <source>E</source>
        <translation>E</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2107"/>
        <source>A</source>
        <translation>A</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2117"/>
        <source>C</source>
        <translation>C</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2127"/>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2168"/>
        <source>Top</source>
        <translation>Góra</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2216"/>
        <source>Maintain aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2673"/>
        <source>Beveled</source>
        <translation>Wypukła</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2678"/>
        <source>Inset</source>
        <translation>Wklęsła</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2733"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2797"/>
        <source>ToolTip</source>
        <translation>Etykietka Narzędzia</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2813"/>
        <source>Orientation</source>
        <translation>Orientacja</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2821"/>
        <source>0 Degrees</source>
        <translation>0 Stopni</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2826"/>
        <source>90 Degrees</source>
        <translation>90 Stopni</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2831"/>
        <source>180 Degrees</source>
        <translation>180 Stopni</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2836"/>
        <source>270 Degrees</source>
        <translation>270 Stopni</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2857"/>
        <source>Read Only</source>
        <translation>Tylko do Odczytu</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2872"/>
        <source>Visible</source>
        <translation>Widoczne</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2877"/>
        <source>Hidden</source>
        <translation>Ukryte</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2882"/>
        <source>Visible but doesn&apos;t print</source>
        <translation>Widoczne, bez drukowania</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2887"/>
        <source>Hidden but printable</source>
        <translation>Ukryte, z drukowaniem</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2895"/>
        <source>Required</source>
        <translation>Wymagane</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2905"/>
        <source>Locked</source>
        <translation>Zablokowane</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2934"/>
        <source>Subject</source>
        <translation type="unfinished">Temat</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2982"/>
        <source>Author</source>
        <translation type="unfinished">Autor</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1871"/>
        <source>Font Family</source>
        <translation>Rodzina Czcionek</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1900"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2720"/>
        <source>Size</source>
        <translation>Rozmiar</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1916"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2458"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="3002"/>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2175"/>
        <source>Coordinates</source>
        <translation>Współrzędne</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2203"/>
        <source>Absolute</source>
        <translation>Bezwględne</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2208"/>
        <source>Relative</source>
        <translation>Względne</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2235"/>
        <source>Geometry</source>
        <translation>Geometria</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2257"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2762"/>
        <source>Font</source>
        <translation>Czcionka</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2295"/>
        <source>Matrix</source>
        <translation>Matryca</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2314"/>
        <source>Cliping Path</source>
        <translation>Ścieżka Podcinania</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2333"/>
        <source>General</source>
        <translation>Ogólne</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2352"/>
        <source>Appearance</source>
        <translation>Wygląd</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2371"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2428"/>
        <source>Options</source>
        <translation>Opcje</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2478"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2496"/>
        <source>Full</source>
        <translation>Pełny</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2483"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2531"/>
        <source>Stroke</source>
        <translation>Obramowany</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2521"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2543"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2749"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2959"/>
        <source>Color</source>
        <translation>Kolor</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2623"/>
        <source>Borders and Colors</source>
        <translation>Obramowania i Kolory</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2630"/>
        <source>Thin</source>
        <translation>Cienka</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2635"/>
        <source>Medium</source>
        <translation>Zwykła</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2640"/>
        <source>Thick</source>
        <translation>Gruba</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2655"/>
        <source>Fill Color</source>
        <translation>Kolor Wypełnienia</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1978"/>
        <source>Stroke Color</source>
        <translation>Kolor Obramowania</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2004"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2508"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2569"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2972"/>
        <source>Opacity</source>
        <translation>Widoczność</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="196"/>
        <source>Zip Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="196"/>
        <source>Zip Code+4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="196"/>
        <source>Phone Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="196"/>
        <source>Social Security Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="202"/>
        <source>Check Mark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="204"/>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="206"/>
        <source>Help</source>
        <translation type="unfinished">Pomoc</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="207"/>
        <source>Insert Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="208"/>
        <source>Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="209"/>
        <source>New Paragraph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="210"/>
        <source>Text Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="211"/>
        <source>Paragraph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="212"/>
        <source>Right Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="213"/>
        <source>Right Pointer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="215"/>
        <source>Up Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="216"/>
        <source>Up Left Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="217"/>
        <source>Graph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="218"/>
        <source>Paper Clip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="219"/>
        <source>Attachment</source>
        <translation type="unfinished">Załącznik</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="220"/>
        <source>Tag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1215"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1222"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1235"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1242"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1284"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the fill color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Zmień kolor wypełnienia&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1290"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font Stroke color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the stroke color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font Stroke color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Zmień kolor obramowania&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1661"/>
        <source>Image</source>
        <translation>Obraz</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1701"/>
        <source>Shading</source>
        <translation>Cieniowanie</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1723"/>
        <source>Image Form</source>
        <translation>Formularz Obrazu</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2158"/>
        <source>Width</source>
        <translation>Szerokość</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2185"/>
        <source>Height</source>
        <translation>Wysokość</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1681"/>
        <source>Path</source>
        <translation>Ścieżka</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2864"/>
        <source>Form Field</source>
        <translation>Pole Formularza</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2787"/>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1227"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1272"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Zmień rodzinę czcionek&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2604"/>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="399"/>
        <source>Goto a Page View</source>
        <translation>Idź do Widoku Strony</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="331"/>
        <source>Add an Action</source>
        <translation>Dodaj Akcję</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="337"/>
        <source>Trigger</source>
        <translation>Wyzwalacz</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="345"/>
        <source>Mouse Up</source>
        <translation>Kliknięcie</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="350"/>
        <source>Mouse Down</source>
        <translation>Kliknięcie 2</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="355"/>
        <source>Mouse Enter</source>
        <translation>Najechanie</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="360"/>
        <source>Mouse Exit</source>
        <translation>Opuszczenie</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="365"/>
        <source>On Receive Focus</source>
        <translation>Otrzymanie Fokusu</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="370"/>
        <source>On Lose Focus</source>
        <translation>Opuszczenie Fokusu</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="391"/>
        <source>Action</source>
        <translation>Akcja</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="404"/>
        <source>Open/execute a File</source>
        <translation>Otwórz Plik</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="409"/>
        <source>Open a web link</source>
        <translation>Otwórz link</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="414"/>
        <source>Reset form</source>
        <translation>Zresetuj formularz</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="419"/>
        <source>Show/Hide fields</source>
        <translation>Pokaż/Ukryj pola</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="424"/>
        <source>Submit a form</source>
        <translation>Prześlij formularz</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="429"/>
        <source>Run a JavaScript</source>
        <translation>Uruchom JavaScript</translation>
    </message>
</context>
<context>
    <name>PageLayoutDialog</name>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="14"/>
        <source>Page Layout</source>
        <translation>Układ Strony</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="96"/>
        <source>Contents Size</source>
        <translation>Rozmiar Zawartości</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="108"/>
        <source>Left margin</source>
        <translation>Lewy margines</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="122"/>
        <source>Top margin</source>
        <translation>Górny margines</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="136"/>
        <source>Right margin</source>
        <translation>Prawy margines</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="150"/>
        <source>Bottom margin</source>
        <translation>Dolny margines</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="53"/>
        <source>Page Size</source>
        <translation>Rozmiar Strony</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="59"/>
        <source>Width</source>
        <translation>Szerokość</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.cpp" line="236"/>
        <source> px</source>
        <translation>px</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.cpp" line="260"/>
        <source> in</source>
        <translation>&quot;</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.cpp" line="282"/>
        <source> mm</source>
        <translation>mm</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="76"/>
        <source>Height</source>
        <translation>Wysokość</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="167"/>
        <source>Units</source>
        <translation>Jednostki</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="178"/>
        <source>points</source>
        <translation>piksele</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="183"/>
        <source>inch</source>
        <translation>cale</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="188"/>
        <source>millimeter</source>
        <translation>milimetry</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="196"/>
        <source>Page Range</source>
        <translation>Zares Stron</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="255"/>
        <source>Even and Odd pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="260"/>
        <source>Even pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="265"/>
        <source>Odd pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="283"/>
        <source>Pages from</source>
        <translation>Od strony</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="273"/>
        <source>Current Page</source>
        <translation>Bieżąca Strona</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="202"/>
        <source>All Pages</source>
        <translation>Wszystkie Strony</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="231"/>
        <source>to:</source>
        <translation>do:</translation>
    </message>
</context>
<context>
    <name>PasswordOpenDialog</name>
    <message>
        <location filename="../src/passwordopendialog.ui" line="14"/>
        <source>Enter Password</source>
        <translation>Wpisz Hasło</translation>
    </message>
    <message>
        <location filename="../src/passwordopendialog.ui" line="66"/>
        <source>Password:</source>
        <translation>Hasło:</translation>
    </message>
    <message>
        <location filename="../src/passwordopendialog.ui" line="56"/>
        <source>The file is protected. Please enter a Document Open Password</source>
        <translation>Dokument jest chroniony. Proszę wpisać Hasło Otwarcia Dokumentu</translation>
    </message>
</context>
<context>
    <name>PlainTextEdit</name>
    <message>
        <location filename="../src/docpage/texteditor/plaintextedit.cpp" line="234"/>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation>Czcionka nie zawiera tych znaków.
Spróbuj wybrać inną czcionkę.</translation>
    </message>
</context>
<context>
    <name>PrintDialog</name>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="14"/>
        <source>Print Preview</source>
        <translation>Podgląd Drukowania</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="35"/>
        <source>Printer</source>
        <translation>Drukarka</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="50"/>
        <source>Properties</source>
        <translation>Właściwości</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="74"/>
        <source>72</source>
        <translation type="unfinished">72</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="79"/>
        <source>150</source>
        <translation type="unfinished">150</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="84"/>
        <source>300</source>
        <translation type="unfinished">300</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="89"/>
        <source>600</source>
        <translation type="unfinished">600</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="94"/>
        <source>900</source>
        <translation type="unfinished">900</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="99"/>
        <source>1200</source>
        <translation type="unfinished">1200</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="113"/>
        <source>DPI</source>
        <translation type="unfinished">DPI</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="237"/>
        <source>Antialiasing</source>
        <translation>Antyaliasing</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="244"/>
        <source>Center</source>
        <translation>Wyśrodkuj</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="251"/>
        <source>Print as Grayscale</source>
        <translation>Drukuj w Skali Szarości</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="258"/>
        <source>Aspect Ratio</source>
        <translation>Wpółczynnik Proporcji</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="265"/>
        <source>Ignore aspect ratio</source>
        <translation>Ignoruj wpółczynnik proporcji</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="270"/>
        <source>Keep aspect ratio</source>
        <translation>Zachowaj wpółczynnik proporcji</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="275"/>
        <source>Keep aspect ratio by expanding</source>
        <translation>Zachowaj wpółczynnik proporcji rozciągając</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="289"/>
        <source>Orientation</source>
        <translation>Orientacja</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="295"/>
        <source>Portrait</source>
        <translation>Pionowa</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="302"/>
        <source>Landscape</source>
        <translation>Pozioma</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="371"/>
        <source>Page</source>
        <translation>Strona</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="381"/>
        <source>of:</source>
        <translation>z:</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="66"/>
        <source>Resolution</source>
        <translation>Rozdzielczość</translation>
    </message>
    <message>
        <source>Low</source>
        <translation type="vanished">Niska</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation type="vanished">Normalna</translation>
    </message>
    <message>
        <source>High</source>
        <translation type="vanished">Wysoka</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="129"/>
        <source>Page Range</source>
        <translation>Zakres Stron</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="135"/>
        <source>All Pages</source>
        <translation>Wszystkie Strony</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="145"/>
        <source>Pages from</source>
        <translation>Od strony</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="152"/>
        <source>Current Page</source>
        <translation>Bieżąca Strona</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="175"/>
        <source>to:</source>
        <translation>do:</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="207"/>
        <source>Number of copies</source>
        <translation>Liczba kopii</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="221"/>
        <source>Collate</source>
        <translation>Sortuj</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.cpp" line="67"/>
        <source>of </source>
        <translation>z </translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.cpp" line="97"/>
        <source>Print</source>
        <translation>Drukuj</translation>
    </message>
</context>
<context>
    <name>QAttachment</name>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="19"/>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="19"/>
        <source>Description</source>
        <translation>Opis</translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="19"/>
        <source>Size</source>
        <translation>Rozmiar</translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="19"/>
        <source>Location</source>
        <translation>Lokalizacja</translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="34"/>
        <source>Insert</source>
        <translation>Wstaw</translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="35"/>
        <source>Delete</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="36"/>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="415"/>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="435"/>
        <source>Save As...</source>
        <translation>Zapisz Jako...</translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="98"/>
        <source>Page </source>
        <translation>Strona </translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="102"/>
        <source>Attachment Tab</source>
        <translation>Karta Załącznika</translation>
    </message>
</context>
<context>
    <name>QBookmarksTree</name>
    <message>
        <location filename="../src/leftTab/bookmark/qbookmarks.cpp" line="17"/>
        <source>Add Bookmark</source>
        <translation>Dodaj Zakładkę</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/qbookmarks.cpp" line="18"/>
        <source>Delete Bookmark</source>
        <translation>Usuń Zakładkę</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/qbookmarks.cpp" line="19"/>
        <source>Bookmark Properties</source>
        <translation>Właściwości Zakładki</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/qbookmarks.cpp" line="20"/>
        <source>Set Destination</source>
        <translation>Ustaw Przeznaczenie</translation>
    </message>
</context>
<context>
    <name>QDocTab</name>
    <message>
        <location filename="../src/document/qdoctab.cpp" line="77"/>
        <source>untitled</source>
        <translation>bez nazwy</translation>
    </message>
    <message>
        <location filename="../src/document/qdoctab.cpp" line="620"/>
        <source>The clipboard doesn&apos;t contain an data</source>
        <translation>Schowek nie zawiera żadnych danych</translation>
    </message>
</context>
<context>
    <name>QHttp</name>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="370"/>
        <source>HTTPS connection requested but SSL support not compiled in</source>
        <translation>Zażądano połączenie HTTPS, ale obługa SSL nie jest wkompilowana</translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="1579"/>
        <location filename="../src/qhttp/qhttp.cpp" line="2375"/>
        <source>Unknown error</source>
        <translation>Nieznany błąd</translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="1830"/>
        <source>Request aborted</source>
        <translation>Żądanie przerwane</translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2386"/>
        <source>No server set to connect to</source>
        <translation>Brak serwera do połączenia</translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2550"/>
        <source>Wrong content length</source>
        <translation>Zła długość treści</translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2554"/>
        <source>Server closed connection unexpectedly</source>
        <translation>Serwer nieoczekiwanie zamknął połączenie</translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2609"/>
        <source>Connection refused (or timed out)</source>
        <translation>Połączenie odrzucone (lub przekroczono limit czasu)</translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2612"/>
        <source>Host %1 not found</source>
        <translation>Host %1 nie znaleziony</translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2632"/>
        <source>HTTP request failed</source>
        <translation>Żądanie HTTP nie powiodło się</translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2726"/>
        <source>Invalid HTTP response header</source>
        <translation>Nieprawidłowy nagłówek odpowiedzi HTTP</translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2770"/>
        <source>Unknown authentication method</source>
        <translation>Nieznana metoda uwierzytelniania</translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2780"/>
        <source>Proxy authentication required</source>
        <translation>Wymagane uwierzytelnienie proxy</translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2784"/>
        <source>Authentication required</source>
        <translation>Wymagana autoryzacja</translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2867"/>
        <location filename="../src/qhttp/qhttp.cpp" line="2915"/>
        <source>Invalid HTTP chunked body</source>
        <translation>Nieprawidłowa treść fragmentaryczna HTTP</translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2953"/>
        <source>Error writing response to device</source>
        <translation>Błąd zapisu odpowiedzi dla urządzenia</translation>
    </message>
</context>
<context>
    <name>QPDFDocument</name>
    <message>
        <location filename="../src/document/qpdfdocument.cpp" line="1108"/>
        <source>Error!</source>
        <translation>Błąd!</translation>
    </message>
    <message>
        <location filename="../src/document/qpdfdocument.cpp" line="1527"/>
        <source>There was a problem with your form submission.</source>
        <translation>Pojawił się problem z przesłaniem formularza.</translation>
    </message>
    <message>
        <location filename="../src/document/qpdfdocument.cpp" line="1529"/>
        <source>Your form was successfully submitted!</source>
        <translation>Twój formularz został pomyślnie przesłany!</translation>
    </message>
</context>
<context>
    <name>QTabPage</name>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="73"/>
        <source>Pages</source>
        <translation>Strony</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="78"/>
        <source>Enlarge Page Thumbnails</source>
        <translation>Powiększ Miniatury Stron</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="81"/>
        <source>Reduce Page Thumbnails</source>
        <translation>Powiększ Miniatury Stron</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="86"/>
        <source>Delete Pages</source>
        <translation>Usuń Strony</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="99"/>
        <source>Bookmarks</source>
        <translation>Zakładki</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="112"/>
        <source>Attachment</source>
        <translation>Załącznik</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="119"/>
        <source>Search</source>
        <translation>Szukaj</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="134"/>
        <source>Object Inspector</source>
        <translation>Inspektor Obiektu</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="385"/>
        <source>This document contains interactive form fields</source>
        <translation>Dokument zawiera interaktywne pola formularza</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="386"/>
        <source>Highlight Fields</source>
        <translation>Wyróżnione Pola</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="404"/>
        <source>This document is protected. You do not have permissions to edit this document</source>
        <translation>Dokument jest chroniony. Nie posiadasz uprawneń do edytowania dokumentu</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="405"/>
        <source>Change</source>
        <translation>Zmień</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="742"/>
        <source>There was an error printing the document</source>
        <translation>Wystąpił błąd podczas drukowania dokumentu</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="1167"/>
        <source>Insert Blank Pages</source>
        <translation>Wstaw Puste Strony</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="1919"/>
        <source>Do you want to open?</source>
        <translation>Chcesz otworzyć?</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="2550"/>
        <source>Are you sure you want to set the destination of the selected bookmark to the current location?</source>
        <translation>Na pewno chcesz przypisać przeznaczenie zaznaczonej zakładki do bieżącej lokalizacji?</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="2615"/>
        <source>untitled</source>
        <translation>bez nazwy</translation>
    </message>
</context>
<context>
    <name>QtColorComboBox</name>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="131"/>
        <source>More...</source>
        <translation>Więcej...</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="263"/>
        <source>User color %1</source>
        <translation>Kolor użytkownika %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="314"/>
        <source>User Color 99</source>
        <translation>Kolor użytkownika 99</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="328"/>
        <source>Black</source>
        <translation>Czarny</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="329"/>
        <source>White</source>
        <translation>Biały</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="330"/>
        <source>Red</source>
        <translation>Czerwony</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="331"/>
        <source>Dark red</source>
        <translation>Ciemnoczerwony</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="332"/>
        <source>Green</source>
        <translation>Zielony</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="333"/>
        <source>Dark green</source>
        <translation>Ciemnozielony</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="334"/>
        <source>Blue</source>
        <translation>Niebieski</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="335"/>
        <source>Dark blue</source>
        <translation>Ciemnoniebieski</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="336"/>
        <source>Cyan</source>
        <translation>Turkusowy</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="337"/>
        <source>Dark cyan</source>
        <translation>Ciemnoturkusowy</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="338"/>
        <source>Magenta</source>
        <translation>Amarantowy</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="339"/>
        <source>Dark magenta</source>
        <translation>Ciemnoamarantowy</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="340"/>
        <source>Yellow</source>
        <translation>Żółty</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="341"/>
        <source>Dark yellow</source>
        <translation>Ciemnożółty</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="342"/>
        <source>Gray</source>
        <translation>Szary</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="343"/>
        <source>Dark gray</source>
        <translation>Ciemnoszary</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="344"/>
        <source>Light gray</source>
        <translation>Jasnoszary</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="346"/>
        <source>Transparent</source>
        <translation>Przezroczysty</translation>
    </message>
</context>
<context>
    <name>RegDialog</name>
    <message>
        <location filename="../src/regdialog.ui" line="14"/>
        <source>Registration Info</source>
        <translation>Informacja o Rejestracji</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="343"/>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="145"/>
        <source>After your order has been completed, 
you will automatically 
receive your Registration code via e-mail.</source>
        <translation>Po zakończeniu składania zamówienia, automatycznie otrzymasz kod Rejestracyjny na e-mail.</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="116"/>
        <source>Buy Online</source>
        <translation>Kup Online</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="39"/>
        <location filename="../src/regdialog.ui" line="242"/>
        <source>Registration Code</source>
        <translation>Kod Rejestracji</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="46"/>
        <location filename="../src/regdialog.ui" line="262"/>
        <source>Activate</source>
        <translation>Aktywuj</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="69"/>
        <source>Offline Activation</source>
        <translation>Aktywacja Offline</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="170"/>
        <source>Registered version</source>
        <translation>Zarejestrowana wersja</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="177"/>
        <source>If you want to register that license on another PC 
click &quot;Deactivate&quot; button. 

Then register it where you need.</source>
        <translation>Jeśli chcesz zarejestrować tę licencję na innym PC
kliknij przycisk &quot;Deaktywuj&quot;.

Następnie zarejestruj ją gdzie potrzebujesz.</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="203"/>
        <source>Deactivate</source>
        <translation>Deaktywuj</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="282"/>
        <source>Back</source>
        <translation>Powrót</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="252"/>
        <source>Activation Code</source>
        <translation>Kod Aktywacyjny</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="302"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please send the ID key and Registration code to: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Once you receive your code enter it into &amp;quot;Activation code&amp;quot; field&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Proszę wysłać klucz ID i kod Rejestracyjny na: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Po otrzymaniu kodu, wpisz go w pole &amp;quot;Kod aktywacyjny&amp;quot;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="309"/>
        <source>ID</source>
        <translation>ID</translation>
    </message>
</context>
<context>
    <name>RotatePagesDlg</name>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="14"/>
        <source>Rotate</source>
        <translation>Obróć</translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="20"/>
        <source>Page Range</source>
        <translation>Zakres Stron</translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="26"/>
        <source>Pages</source>
        <translation>Strony</translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="52"/>
        <source>Sample: 1,6-8,12</source>
        <translation>Przykład: 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="72"/>
        <source>Current Page</source>
        <translation>Bieżąca Strona</translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="82"/>
        <source>Pages from</source>
        <translation>Od strony</translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="108"/>
        <source>to:</source>
        <translation>do:</translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="134"/>
        <source>Direction</source>
        <translation>Kierunek</translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="141"/>
        <source>Clockwise 90 degrees</source>
        <translation>Zgodnie z zegarem 90 stopni</translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="146"/>
        <source>180 degrees</source>
        <translation>180 Stopni</translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="151"/>
        <source>Counterclockwise 90 degrees</source>
        <translation>Przeciwnie do zegara 90 stopni</translation>
    </message>
</context>
<context>
    <name>SaveImageDialog</name>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="14"/>
        <source>Export to Image</source>
        <translation>Eksportuj do Obrazu</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="20"/>
        <source>File Name</source>
        <translation>Nazwa Pliku</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="29"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="39"/>
        <source>Page Range</source>
        <translation>Zakres Stron</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="51"/>
        <source>All Pages</source>
        <translation>Wszystkie Strony</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="67"/>
        <source>Pages from</source>
        <translation>Od strony</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="84"/>
        <source>to:</source>
        <translation>do:</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="107"/>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="148"/>
        <location filename="../src/SaveImageDialog.ui" line="217"/>
        <source>JPEG</source>
        <translation>JPEG</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="113"/>
        <source>BMP</source>
        <translation>BMP</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="120"/>
        <source>PNG</source>
        <translation>PNG</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="158"/>
        <source>TIFF</source>
        <translation>TIFF</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="127"/>
        <source>JPEG Quality</source>
        <translation>Jakość JPEG</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="197"/>
        <source>LZW</source>
        <translation>LZW</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="202"/>
        <source>ZIP</source>
        <translation>ZIP</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="207"/>
        <source>CCITT FAX 3</source>
        <translation>CCITT FAX 3</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="212"/>
        <source>CCITT FAX 4</source>
        <translation>CCITT FAX 4</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="134"/>
        <source>TIFF Compression</source>
        <translation>Kompresja TIFF</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="141"/>
        <source>Transparent</source>
        <translation>Przezroczysty</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="225"/>
        <source>MultiPage</source>
        <translation>Wiele Stron</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="235"/>
        <source>Size</source>
        <translation>Rozmiar</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="241"/>
        <source>Width</source>
        <translation>Szerokość</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="267"/>
        <source>Height</source>
        <translation>Wysokość</translation>
    </message>
    <message>
        <source>72</source>
        <translation type="vanished">72</translation>
    </message>
    <message>
        <source>96</source>
        <translation type="vanished">96</translation>
    </message>
    <message>
        <source>120</source>
        <translation type="vanished">120</translation>
    </message>
    <message>
        <source>150</source>
        <translation type="vanished">150</translation>
    </message>
    <message>
        <source>200</source>
        <translation type="vanished">200</translation>
    </message>
    <message>
        <source>240</source>
        <translation type="vanished">240</translation>
    </message>
    <message>
        <source>300</source>
        <translation type="vanished">300</translation>
    </message>
    <message>
        <source>400</source>
        <translation type="vanished">400</translation>
    </message>
    <message>
        <source>500</source>
        <translation type="vanished">500</translation>
    </message>
    <message>
        <source>600</source>
        <translation type="vanished">600</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="331"/>
        <source>Antialiasing</source>
        <translation>Antyaliasing</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="293"/>
        <source>DPI</source>
        <translation>DPI</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="13"/>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="14"/>
        <source>Export</source>
        <translation>Eksportuj</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="76"/>
        <source>Can&apos;t save to the file:</source>
        <translation>Nie można zapisać do pliku:</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="76"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>Plik może być tylko do odczytu lub używany przez inną aplikację.</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="430"/>
        <source>Save As TIFF Image</source>
        <translation>Zapisz Jako Obraz TIFF</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="430"/>
        <source>TIFF Files (*.tif *.tiff)</source>
        <translation>Pliki TIFF (*.tif *.tiff)</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="449"/>
        <source>Save As Image</source>
        <translation>Zapisz Jako Obraz</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="449"/>
        <source>All Files (*)</source>
        <translation>Wszystkie Pliki (*)</translation>
    </message>
</context>
<context>
    <name>SaveOptimizedDialog</name>
    <message>
        <source>Master PDF Editor</source>
        <translation type="obsolete">Master PDF Editor</translation>
    </message>
    <message>
        <location filename="../src/SaveOptimizedDialog.ui" line="14"/>
        <source>Save Optimized As...</source>
        <translation>Zoptymalizowany plik PDF</translation>
    </message>
    <message>
        <location filename="../src/SaveOptimizedDialog.ui" line="39"/>
        <source>Remove unused elements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveOptimizedDialog.ui" line="49"/>
        <source>Flatten form fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveOptimizedDialog.ui" line="78"/>
        <source>Color and Grayscale Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveOptimizedDialog.ui" line="90"/>
        <location filename="../src/SaveOptimizedDialog.ui" line="233"/>
        <source>DPI</source>
        <translation type="unfinished">DPI</translation>
    </message>
    <message>
        <location filename="../src/SaveOptimizedDialog.ui" line="123"/>
        <location filename="../src/SaveOptimizedDialog.ui" line="266"/>
        <source>Compression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveOptimizedDialog.ui" line="143"/>
        <location filename="../src/SaveOptimizedDialog.ui" line="286"/>
        <source>ZIP</source>
        <translation type="unfinished">ZIP</translation>
    </message>
    <message>
        <location filename="../src/SaveOptimizedDialog.ui" line="148"/>
        <source>JPEG</source>
        <translation type="unfinished">JPEG</translation>
    </message>
    <message>
        <location filename="../src/SaveOptimizedDialog.ui" line="156"/>
        <source>Lossless</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveOptimizedDialog.ui" line="176"/>
        <source>JPEG Quality</source>
        <translation type="unfinished">Jakość JPEG</translation>
    </message>
    <message>
        <location filename="../src/SaveOptimizedDialog.ui" line="221"/>
        <source>Black and White Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveOptimizedDialog.ui" line="291"/>
        <source>CCITT Group 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveOptimizedDialog.ui" line="296"/>
        <source>JBIG2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchFormTab</name>
    <message>
        <source>Form</source>
        <translation type="vanished">Formularz</translation>
    </message>
    <message>
        <location filename="../src/leftTab/search/searchformtab.ui" line="14"/>
        <location filename="../src/leftTab/search/searchformtab.ui" line="20"/>
        <source>Search</source>
        <translation>Szukaj</translation>
    </message>
    <message>
        <location filename="../src/leftTab/search/searchformtab.ui" line="46"/>
        <source>0 result</source>
        <translation>brak wyników</translation>
    </message>
    <message>
        <location filename="../src/leftTab/search/searchformtab.cpp" line="11"/>
        <source>Case Sensitive</source>
        <translation>Uwzględnij Wielkość Liter</translation>
    </message>
    <message>
        <location filename="../src/leftTab/search/searchformtab.cpp" line="15"/>
        <source>Include Comments</source>
        <translation>Zawierać komentarze</translation>
    </message>
    <message>
        <location filename="../src/leftTab/search/searchformtab.cpp" line="57"/>
        <source> result</source>
        <translation> wynik</translation>
    </message>
    <message>
        <location filename="../src/leftTab/search/searchformtab.cpp" line="59"/>
        <source> result(s)</source>
        <translation> wynik(i)</translation>
    </message>
    <message>
        <location filename="../src/leftTab/search/searchformtab.cpp" line="61"/>
        <source> results</source>
        <translation>wyników</translation>
    </message>
</context>
<context>
    <name>SearchLineEdit</name>
    <message>
        <location filename="../src/leftTab/search/searchlineedit.cpp" line="75"/>
        <source>Case Sensitive</source>
        <translation type="unfinished">Uwzględnij Wielkość Liter</translation>
    </message>
    <message>
        <location filename="../src/leftTab/search/searchlineedit.cpp" line="76"/>
        <source>Include Comments</source>
        <translation type="unfinished">Zawierać komentarze</translation>
    </message>
</context>
<context>
    <name>SecurityDialog</name>
    <message>
        <location filename="../src/SecurityDialog.ui" line="14"/>
        <source>Security PDF</source>
        <translation>Zabezpieczony PDF</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="36"/>
        <source>Required a password to open the document</source>
        <translation>Wymagane hasło, aby otworzyć dokument</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="51"/>
        <source>Document Open Password</source>
        <translation>Hasło Otwarcia Dokumentu</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="71"/>
        <location filename="../src/SecurityDialog.ui" line="132"/>
        <source>Password Confirm</source>
        <translation>Potwierdzenie Hasła</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="94"/>
        <source>Permissions</source>
        <translation>Uprawnienia</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="122"/>
        <source>Commenting</source>
        <translation>Komentowanie</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="142"/>
        <source>Modifying document</source>
        <translation>Modyfikowanie dokumentu</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="155"/>
        <source>Content copying for accessibility</source>
        <translation>Kopiowanie treści dla ułatwienia dostępu</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="168"/>
        <source>Printing the document</source>
        <translation>Drukowanie dokumentu</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="181"/>
        <source>Extract the content of the document</source>
        <translation>Wyodrębnij treść dokumentu</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="194"/>
        <source>Print a high resolution version of the document</source>
        <translation>Drukuj wysokiej jakości wersję dokumentu</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="207"/>
        <source>Fill in existing form or signature fields</source>
        <translation>Wypełnij isniejące pola formularzy i podpisów</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="223"/>
        <source>Permissions Password</source>
        <translation>Hasło Uprawnień</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="233"/>
        <source>Manage Pages and bookmarks</source>
        <translation>Zarządzaj Stronami i zakładkami</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.cpp" line="84"/>
        <source>Document Open password does not match.</source>
        <translation>Hasła Otwarcia Dokumentu nie pasują.</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.cpp" line="96"/>
        <source>Document Permission password does not match.</source>
        <translation>Hasła Uprawnień Dokumentu nie pasują.</translation>
    </message>
</context>
<context>
    <name>SignatureDialog</name>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="14"/>
        <source>Signature Properties</source>
        <translation>Właściwości Podpisu</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="52"/>
        <location filename="../src/signature/SignatureDialog.cpp" line="20"/>
        <source>Signature is VALID</source>
        <translation>Podpis jest PRAWIDŁOWY</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="72"/>
        <source>Details</source>
        <translation>Szczegóły</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="129"/>
        <source>Signed by:</source>
        <translation>Podpisany przez:</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="78"/>
        <source>Reason:</source>
        <translation>Powód:</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="92"/>
        <source>Date:</source>
        <translation>Data:</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="115"/>
        <source>Location:</source>
        <translation>Lokalizacja:</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="169"/>
        <source>Validation Summary</source>
        <translation>Podsumowanie Weryfikacji</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="185"/>
        <source>Signer&apos;s Contact Information:</source>
        <translation>Informacje Kontaktowe Podpisującego:</translation>
    </message>
    <message>
        <source>Sing As</source>
        <translation type="vanished">Podpisz Jako</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="367"/>
        <source>Show Image</source>
        <translation>Pokaż Obraz</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="396"/>
        <source>Stretch Image</source>
        <translation>Rozciągnij Obraz</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="389"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="406"/>
        <source>Show Text</source>
        <translation>Pokaż Tekst</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="136"/>
        <location filename="../src/signature/SignatureDialog.ui" line="244"/>
        <source>Info</source>
        <translation>Informacja</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="224"/>
        <source>Sign As</source>
        <translation>Podpisz Jako</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="254"/>
        <source>Text For Signing</source>
        <translation>Tekst Do Podpisu</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="266"/>
        <source>Location</source>
        <translation>Lokalizacja</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="282"/>
        <source>Reason</source>
        <translation>Powód</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="299"/>
        <source>Lock document after signing</source>
        <translation>Zablokuj dokument po podpisaniu</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="325"/>
        <source>Signature Preview</source>
        <translation>Podgląd Podpisu</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="39"/>
        <source>I have reviewed this document</source>
        <translation>Przejrzałem ten dokument</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="40"/>
        <source>I am approving this document</source>
        <translation>Zatwierdzam ten dokument</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="41"/>
        <source>I attest to the accuracy and integrity of this document</source>
        <translation>Potwierdzam dokładność i integralność tego dokumentu</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="42"/>
        <source>I agree to specified parts of this document</source>
        <translation>Zgadzam się na określone części tego dokumentu</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="17"/>
        <source>The document has been altered or corrupted since the signatures was applied.</source>
        <translation>Dokument został zmieniony lub uszkodzony od czasu zastosowania podpisu.</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="18"/>
        <source>Document has not been changed since the signatures was applied.</source>
        <translation>Dokument nie został zmieniony od czasu zastosowania podpisu.</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="19"/>
        <source>Signature is INVALID</source>
        <translation>Podpis jest NIEPRAWIDŁOWY</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="21"/>
        <source>Signature validity is UNKNOWN</source>
        <translation>Ważność podpisu jest NIEZNANA</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="22"/>
        <source>This certificate is not trusted</source>
        <translation>Certyfikat jest niezaufany</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="23"/>
        <source>The signers identity is unknown because it has not been include in your list of trusted identities and none of its parent certificates is trust identities.</source>
        <translation>Tożsamość podpisującego jest nieznana, ponieważ nie znajduje się na liście zaufanych tożsamości i żadne jej nadrzędne certyfikaty nie są zaufane.</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="24"/>
        <source>Error during signature verification.</source>
        <translation>Błąd podczas weryfikacji podpisu.</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="25"/>
        <source>Details: The signature byte range is invalid</source>
        <translation>Szczegóły: Zakres bajtów podpisu jest nieprawidłowy</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="26"/>
        <source>I am the author of this document</source>
        <translation>Jestem autorem tego dokumentu</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="84"/>
        <source>Open Image</source>
        <translation>Otwórz Obraz</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="84"/>
        <source>Image Files (*.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation>Pliki Obrazu (*.tif *.png *.jpg *.jpeg *.bmp)</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="363"/>
        <source>Open File</source>
        <translation>Otwórz Plik</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="363"/>
        <source>p12 Files (*.p12)</source>
        <translation>Pliki p12 (*.p12)</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="348"/>
        <source>A error occurred during the signature verification!</source>
        <translation>Pojawił się błąd podczas weryfikacji sygnatury!</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="188"/>
        <source>Browse...</source>
        <translation>Przeglądaj...</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="265"/>
        <source>A password is required to open certificate:</source>
        <translation>Hasło jest wymagane, aby otworzyć certyfikat:</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="152"/>
        <source>Sign</source>
        <translation>Podpisz</translation>
    </message>
</context>
<context>
    <name>SignatureInfoDialog</name>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="14"/>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="34"/>
        <source>Info</source>
        <translation>Informacja</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="40"/>
        <source>Issuer</source>
        <translation>Wydawca</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="46"/>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="132"/>
        <source>Common Name (CN)</source>
        <translation>Powszechna Nazwa (PN)</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="60"/>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="139"/>
        <source>Organization (O)</source>
        <translation>Organizacja (O)</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="74"/>
        <source>Organizational Unit (OU)</source>
        <translation>Jednostka Organizacyjna (JO)</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="88"/>
        <source>Serial Number</source>
        <translation>Numer Seryjny</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="102"/>
        <source>Algorithm</source>
        <translation>Algorytm</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="119"/>
        <source>Subject</source>
        <translation>Temat</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="153"/>
        <source>Email</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="166"/>
        <source>Validity</source>
        <translation>Ważność</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="172"/>
        <source>Not Before</source>
        <translation>Nie Przed</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="179"/>
        <source>Not After</source>
        <translation>Nie Po</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="209"/>
        <source>SHA-1:</source>
        <translation>SHA-1:</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="229"/>
        <source>MD5</source>
        <translation>MD5</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="278"/>
        <source>Add to Trusted Identities</source>
        <translation>Dodaj do Zaufanych Tożsamości</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="286"/>
        <source>Data</source>
        <translation>Dane</translation>
    </message>
</context>
<context>
    <name>StickyNoteDlg</name>
    <message>
        <location filename="../src/forms/StickyNoteDlg.ui" line="17"/>
        <source>Form</source>
        <translation>Formularz</translation>
    </message>
</context>
</TS>
