<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>AboutDialog</name>
    <message>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Application</name>
    <message>
        <source>File</source>
        <translation type="obsolete">Fail</translation>
    </message>
    <message>
        <source>New</source>
        <translation type="obsolete">PDF-i loomine</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="obsolete">Ava</translation>
    </message>
    <message>
        <source>Recent Files</source>
        <translation type="obsolete">Recent Files</translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="obsolete">Abi</translation>
    </message>
    <message>
        <source>Register...</source>
        <translation type="obsolete">Registration</translation>
    </message>
    <message>
        <source>Check for Update</source>
        <translation type="obsolete">Kontrolli uuendusi</translation>
    </message>
    <message>
        <source>Help...</source>
        <translation type="obsolete">Abi...</translation>
    </message>
</context>
<context>
    <name>BookmarksDialogProp</name>
    <message>
        <source>Bookmark Properties</source>
        <translation type="unfinished">Järjehoidja omadused</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished">Sätted</translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="unfinished">Tekst</translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="unfinished">Stiil</translation>
    </message>
    <message>
        <source>Plain</source>
        <translation type="unfinished">Lihtne</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="unfinished">Kaldkiri</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="unfinished">Paks</translation>
    </message>
    <message>
        <source>Italic &amp; Bold</source>
        <translation type="unfinished">Paks Kaldkiri</translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="unfinished">Värvus</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation type="unfinished">Toimingud</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished">Kustuta</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished">Redigeerimine</translation>
    </message>
    <message>
        <source>Add an Action</source>
        <translation type="unfinished">Lisa tegevus</translation>
    </message>
    <message>
        <source>Trigger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mouse Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Goto a Page View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show/Hide fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Submit a form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Run a JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="unfinished">Lisa</translation>
    </message>
    <message>
        <source>Page Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set current position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type="unfinished">Välimus</translation>
    </message>
    <message>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to set the current position?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogDeletePages</name>
    <message>
        <source>The removed page(s) will never recovered, delete it anyway?</source>
        <translation type="obsolete">Do you want to delete these pages? The operation cannot be undone.</translation>
    </message>
    <message>
        <source>Delete Page(s)</source>
        <translation type="unfinished">Kustutatud leheküljed</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="unfinished">Select Page Range</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="unfinished">Praegune lehekülg</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="unfinished">Selected Pages</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="unfinished">kuni:</translation>
    </message>
    <message>
        <source>The removed page(s) cannot be recovered with undo operation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="unfinished">Leheküljed</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogFormFields</name>
    <message>
        <source>Button</source>
        <translation type="obsolete">Vajuta nuppu</translation>
    </message>
</context>
<context>
    <name>DialogNotes</name>
    <message>
        <source>Opacity</source>
        <translation type="vanished">Läbipaistmatus</translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="obsolete">Tekst</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type="obsolete">Välimus</translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="obsolete">Värvus</translation>
    </message>
    <message>
        <source>Author</source>
        <translation type="obsolete">Autor:</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation type="obsolete">Teema:</translation>
    </message>
    <message>
        <source>Locked</source>
        <translation type="obsolete">Lukustatud</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="obsolete">Sätted</translation>
    </message>
</context>
<context>
    <name>DialogRotatePage</name>
    <message>
        <source>Page Range</source>
        <translation type="obsolete">Select Page Range</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">kuni:</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="obsolete">Selected Pages</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="obsolete">Praegune lehekülg</translation>
    </message>
</context>
<context>
    <name>DocPage</name>
    <message>
        <source>Edit text</source>
        <translation type="vanished">Edit Text</translation>
    </message>
    <message>
        <source>Save Image to file</source>
        <translation type="vanished">Salvesta nimega</translation>
    </message>
    <message>
        <source>Object Properties...</source>
        <translation type="vanished">Omadused...</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="unfinished">Lõika</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="unfinished">Kopeeri</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="obsolete">Kustuta</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Võta tagasi</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation type="unfinished">Vali kõik</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="unfinished">Kleebi</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="obsolete">Salvesta nimega</translation>
    </message>
    <message>
        <source>Add Sticky Note</source>
        <translation type="unfinished">Märge</translation>
    </message>
    <message>
        <source>Highlight Text</source>
        <translation type="unfinished">Tõsta esile</translation>
    </message>
    <message>
        <source>Strikeout Text</source>
        <translation type="unfinished">LäbiKriipsutatud</translation>
    </message>
    <message>
        <source>Underline Text</source>
        <translation type="unfinished">Allajoonitud</translation>
    </message>
    <message>
        <source>Add Bookmark</source>
        <translation type="unfinished">Lisa järjehoidja</translation>
    </message>
</context>
<context>
    <name>DocPageBase</name>
    <message>
        <source>Copy</source>
        <translation type="unfinished">Kopeeri</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="unfinished">Lõika</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="unfinished">Kleebi</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation type="unfinished">Vali kõik</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished">Sätted</translation>
    </message>
    <message>
        <source>Edit text</source>
        <translation type="unfinished">Edit Text</translation>
    </message>
    <message>
        <source>Signature options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="unfinished">Võta tagasi</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished">Kustuta</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ERORR Load Image !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set Fit to Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Image to file</source>
        <translation type="unfinished">Salvesta nimega</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="unfinished">Salvesta nimega</translation>
    </message>
    <message>
        <source>PNG Images (*.png);;BMP Images (*.bmp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PNG Images (*.png)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditActionForm</name>
    <message>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Java script editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Goto a page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit a file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Deselect All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select All</source>
        <translation type="unfinished">Vali kõik</translation>
    </message>
    <message>
        <source>Format</source>
        <translation type="unfinished">Formaat</translation>
    </message>
    <message>
        <source>FDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HTML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>XFDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show/Hide Fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter a file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter a web site:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> px</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished">Sätted</translation>
    </message>
    <message>
        <source>Zoom Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inherit Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FitV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FitR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FitB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FitBH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FitBV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="unfinished">Sirvi...</translation>
    </message>
    <message>
        <source>Local file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HTTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use anonymous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Need user name and password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All Files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Field</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditActionSmallForm</name>
    <message>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter a file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="unfinished">Sirvi...</translation>
    </message>
    <message>
        <source>Goto a page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FitV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FitR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FitB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FitBH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FitBV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> px</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter a web site:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All Files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>XYZ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FitH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Named Action</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExportPageDialog</name>
    <message>
        <source>Extract pages as a single file</source>
        <translation>Extract Pages As A Single File</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Sirvi...</translation>
    </message>
    <message>
        <source>Extract Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File Name</source>
        <translation type="unfinished">Faili nimi</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="unfinished">Select Page Range</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="unfinished">Praegune lehekülg</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="obsolete">Selected Pages</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">kuni:</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save As PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PDF Files (*.pdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export Pages </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="unfinished">Kõik leheküljed</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="unfinished">Leheküljed</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileSettings</name>
    <message>
        <source>Document Properties</source>
        <translation>Dokumendi omadused</translation>
    </message>
    <message>
        <source>Document Info</source>
        <translation>Kirjeldus</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Pealkiri:</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Teema:</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor:</translation>
    </message>
    <message>
        <source>Keywords</source>
        <translation>Märksõnad:</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Looja:</translation>
    </message>
    <message>
        <source>Producer</source>
        <translation>Tootja:</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>Protect</translation>
    </message>
    <message>
        <source>Initial View</source>
        <translation>Initial View</translation>
    </message>
    <message>
        <source>Images</source>
        <translation type="vanished">Images</translation>
    </message>
    <message>
        <source>Fonts</source>
        <translation>Fondid</translation>
    </message>
    <message>
        <source>Fonts used in this document</source>
        <translation>Selles dokumendis kasutatavad fondid</translation>
    </message>
    <message>
        <source>Protection</source>
        <translation type="vanished">Dokumenditurve</translation>
    </message>
    <message>
        <source>User Password</source>
        <translation type="vanished">Kasutaja parool:</translation>
    </message>
    <message>
        <source>Owner Password</source>
        <translation type="vanished">Owner Password:</translation>
    </message>
    <message>
        <source>Password Encryption</source>
        <translation>Password Encryption</translation>
    </message>
    <message>
        <source>No Encryption</source>
        <translation>Krüpteerimata</translation>
    </message>
    <message>
        <source>Printing the document</source>
        <translation>Print Permission</translation>
    </message>
    <message>
        <source>Print a high resolution version of the document</source>
        <translation>Print with high resolution</translation>
    </message>
    <message>
        <source>Extract text and graphics</source>
        <translation type="vanished">Content Extraction Permission</translation>
    </message>
    <message>
        <source>Advanced extract text and graphics</source>
        <translation type="vanished">Extract the contents of the document</translation>
    </message>
    <message>
        <source>Modifying document</source>
        <translation>Modify document</translation>
    </message>
    <message>
        <source>Modify annotations or form fields</source>
        <translation type="vanished">Comment in the document</translation>
    </message>
    <message>
        <source>Fill in existing form or signature fields</source>
        <translation>Vormiväljade täitmine</translation>
    </message>
    <message>
        <source>Manage Pages and bookmarks</source>
        <translation>Manage pages and bookmarks</translation>
    </message>
    <message>
        <source>Open to Page:</source>
        <translation>Open to page:</translation>
    </message>
    <message>
        <source>of :</source>
        <translation>Older From: :</translation>
    </message>
    <message>
        <source>PDF Information</source>
        <translation>Info</translation>
    </message>
    <message>
        <source>Page Mode:</source>
        <translation>Vaade:</translation>
    </message>
    <message>
        <source>Page Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bookmarks Panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pages Panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attachments Panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Layers Panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Full Screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Permissions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extract the content of the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Content copying for accessibility</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Commenting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Run JavaScript on Document Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="unfinished">Lisa</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished">Redigeerimine</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished">Kustuta</translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The document is protected. Please enter a permissions password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Incorrect password. Please input the owner password.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormDialogProp</name>
    <message>
        <source>System</source>
        <translation type="obsolete">Üldine</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type="vanished">Välimus</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="vanished">Sätted</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation type="vanished">Toimingud</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="vanished">Kustuta</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">Sulguda</translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="obsolete">Stiil</translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="vanished">Värvus</translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="vanished">Lisa</translation>
    </message>
    <message>
        <source>Locked</source>
        <translation type="vanished">Lukustatud</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="vanished">Nimi</translation>
    </message>
    <message>
        <source>Borders and Colors</source>
        <translation type="vanished">Äärised ja värvused</translation>
    </message>
    <message>
        <source>Add an Action</source>
        <translation type="vanished">Lisa tegevus</translation>
    </message>
    <message>
        <source>ToolTip</source>
        <translation type="vanished">Hint:</translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation type="vanished">Orientation:</translation>
    </message>
    <message>
        <source>Line Style</source>
        <translation type="vanished">Line Style:</translation>
    </message>
    <message>
        <source>Line Thickness</source>
        <translation type="vanished">Paksus:</translation>
    </message>
    <message>
        <source>Fill Color</source>
        <translation type="vanished">Täidise värvus:</translation>
    </message>
    <message>
        <source>Border Color</source>
        <translation type="vanished">Piirjoone värvus:</translation>
    </message>
    <message>
        <source>Up</source>
        <translation type="vanished">Üles</translation>
    </message>
    <message>
        <source>Down</source>
        <translation type="vanished">Alla</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="obsolete">Dokumendi omadused</translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="obsolete">Tekst</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="obsolete">Maht</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation type="obsolete">Sisesta</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete">Redigeerimine</translation>
    </message>
</context>
<context>
    <name>ImportPageDialog</name>
    <message>
        <source>Insert Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="unfinished">Select Page Range</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="unfinished">Kõik leheküljed</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="obsolete">Selected Pages</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">kuni:</translation>
    </message>
    <message>
        <source>File Name</source>
        <translation type="unfinished">Faili nimi</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="unfinished">Sirvi...</translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>After last page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Before first page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PDF Files (*.pdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total pages :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error read: This PDF is protected.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Before page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>After page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="unfinished">Leheküljed</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file is protected. Please enter a Document Open Password:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>JavaScriptEditDialog</name>
    <message>
        <source>Java Script Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Function Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Java Script</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainOptionsDialog</name>
    <message>
        <source>System</source>
        <translation>Üldine</translation>
    </message>
    <message>
        <source>Forms</source>
        <translation>Vormid</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Keeled</translation>
    </message>
    <message>
        <source>Highlight color</source>
        <translation>Esiletõstuvärvus</translation>
    </message>
    <message>
        <source>Required field highlight color</source>
        <translation>Highlight Required Fields:</translation>
    </message>
    <message>
        <source>Please choose the interface language</source>
        <translation>Palun vali eelistatav liidese keel:</translation>
    </message>
    <message>
        <source>Check for Updates Automatically</source>
        <translation>Automaatselt kontrolli uuendusi:</translation>
    </message>
    <message>
        <source>Weekly</source>
        <translation>Iga nädal</translation>
    </message>
    <message>
        <source>Monthly</source>
        <translation>Iga kuu</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Never</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="obsolete">Sätted</translation>
    </message>
    <message>
        <source> ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Smooth text and images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time before a move or resize starts:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select item by hovering the mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Built-in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>toolBar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Catalan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chinese-Simplified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chinese-Traditional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Czech</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Danish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Estonian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>French</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Galician</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>German</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Greek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hebrew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Irish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Italian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Korean</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Latvian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lithuanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Norwegian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Norwegian-Nynorsk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Polish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese-Brazilian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Russian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slovenian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thai</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Valencian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vietnamese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Saving Documents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create backup file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choice destination for &quot;Save As&quot; documents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last used folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Original documents folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="obsolete">Sirvi...</translation>
    </message>
    <message>
        <source>Default font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Editing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="unfinished">Värvus</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="unfinished">Maht</translation>
    </message>
    <message>
        <source>Armenian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Restore last session when application start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Restore last view settings when reopening</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Always hide document message bar </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default Layout and Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default page layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Single Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Facing Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation type="unfinished">Suurendus</translation>
    </message>
    <message>
        <source>Actual Size</source>
        <translation type="unfinished">Tegelik suurus</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>25%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>50%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>75%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>100%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>125%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>150%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>200%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>300%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>400%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>600%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="unfinished">Tekst</translation>
    </message>
    <message>
        <source>Bitmap Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vector Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Replace Document Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="unfinished">Sätted</translation>
    </message>
    <message>
        <source> Always show Object Inspector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fusion Dark Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Automatically change font when editing text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>System PPI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Icons in menus</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainOptionsDlg</name>
    <message>
        <source>System</source>
        <translation type="obsolete">Üldine</translation>
    </message>
    <message>
        <source>Forms</source>
        <translation type="obsolete">Vormid</translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="obsolete">Keeled</translation>
    </message>
    <message>
        <source>Highlight color</source>
        <translation type="obsolete">Esiletõstuvärvus</translation>
    </message>
    <message>
        <source>Required field highlight color</source>
        <translation type="obsolete">Highlight Required Fields:</translation>
    </message>
    <message>
        <source>Please choose the interface language</source>
        <translation type="obsolete">Palun vali eelistatav liidese keel:</translation>
    </message>
    <message>
        <source>Check for Updates Automatically</source>
        <translation type="obsolete">Automaatselt kontrolli uuendusi:</translation>
    </message>
    <message>
        <source>Weekly</source>
        <translation type="obsolete">Iga nädal</translation>
    </message>
    <message>
        <source>Monthly</source>
        <translation type="obsolete">Iga kuu</translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="obsolete">Never</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="obsolete">Sätted</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="obsolete">Sirvi...</translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="obsolete">Stiil</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Delete Object</source>
        <translation type="vanished">Kustuta</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Fail</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Ava</translation>
    </message>
    <message>
        <source>New</source>
        <translation>PDF-i loomine</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Salvesta</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation>Salvesta nimega</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Prindi</translation>
    </message>
    <message>
        <source>Recent Files</source>
        <translation>Recent Files</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation>Lahkumine</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Lõika</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopeeri</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Kleebi</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Vali kõik</translation>
    </message>
    <message>
        <source>First Page</source>
        <translation>Esimene lehekülg</translation>
    </message>
    <message>
        <source>Previous Page</source>
        <translation>Eelmine lehekülg</translation>
    </message>
    <message>
        <source>Next Page</source>
        <translation>Järgmine lehekülg</translation>
    </message>
    <message>
        <source>Last Page</source>
        <translation>Viimane lehekülg</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>Suurendus</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation>Suurenda</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation>Vähenda</translation>
    </message>
    <message>
        <source>Actual Size</source>
        <translation>Tegelik suurus</translation>
    </message>
    <message>
        <source>Toolbars</source>
        <translation>Tööriistaribad</translation>
    </message>
    <message>
        <source>Statusbar</source>
        <translation>Näita olekuriba</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation>Tööriistad</translation>
    </message>
    <message>
        <source>Hand Tool</source>
        <translation>Käe tööriist</translation>
    </message>
    <message>
        <source>Register...</source>
        <translation>Registration</translation>
    </message>
    <message>
        <source>Check for Update</source>
        <translation>Kontrolli uuendusi</translation>
    </message>
    <message>
        <source>Export to</source>
        <translation>Ekspordi</translation>
    </message>
    <message>
        <source>Enlarge Page Thumbnails</source>
        <translation>Suurenda lehe pisipilte</translation>
    </message>
    <message>
        <source>Reduce Page Thumbnails</source>
        <translation>Vähenda lehe pisipilte</translation>
    </message>
    <message>
        <source>Insert Page(s) from PDF</source>
        <translation type="vanished">Insert Pages...</translation>
    </message>
    <message>
        <source>Extract Page(s) to PDF</source>
        <translation type="vanished">Extract Pages...</translation>
    </message>
    <message>
        <source>Highlight Fields</source>
        <translation>Too kõik väljad esile</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Tekst</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation>Dokumendi omadused</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="obsolete">Select Page Range</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="obsolete">Kõik leheküljed</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="obsolete">Praegune lehekülg</translation>
    </message>
    <message>
        <source>Plain</source>
        <translation type="obsolete">Lihtne</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">Kaldkiri</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">Paks</translation>
    </message>
    <message>
        <source>Italic &amp; Bold</source>
        <translation type="obsolete">Paks Kaldkiri</translation>
    </message>
    <message>
        <source>Bookmarks</source>
        <translation type="vanished">Järjehoidjad</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation>Sisesta</translation>
    </message>
    <message>
        <source>Highlight Text</source>
        <translation>Tõsta esile</translation>
    </message>
    <message>
        <source>Underline Text</source>
        <translation>Allajoonitud</translation>
    </message>
    <message>
        <source>Strikeout Text</source>
        <translation>LäbiKriipsutatud</translation>
    </message>
    <message>
        <source>Attachment</source>
        <translation type="vanished">Manused</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Sätted</translation>
    </message>
    <message>
        <source>Check box</source>
        <translation>Märkekastike</translation>
    </message>
    <message>
        <source>Radio button</source>
        <translation>Raadionupp</translation>
    </message>
    <message>
        <source>Button</source>
        <translation>Vajuta nuppu</translation>
    </message>
    <message>
        <source>List box</source>
        <translation>Loendikast</translation>
    </message>
    <message>
        <source>Combo box</source>
        <translation>Komboväli</translation>
    </message>
    <message>
        <source>Edit Box</source>
        <translation>Tekstiväli</translation>
    </message>
    <message>
        <source>Document</source>
        <translation>Dokument</translation>
    </message>
    <message>
        <source>The document %s has been modified. 
Do you want to save your changes?</source>
        <translation>Kas sa tahad enne sulgemist faili %s tehtud muudatused salvestada?</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Abi</translation>
    </message>
    <message>
        <source>Help...</source>
        <translation type="obsolete">Abi...</translation>
    </message>
    <message>
        <source>Cannot open file :
</source>
        <translation>Could not open the file; File not found.</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Vaade</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Redigeerimine</translation>
    </message>
    <message>
        <source>Your version already has the last update!</source>
        <translation>There are no updates available.</translation>
    </message>
    <message>
        <source>Edit Document</source>
        <translation>Edit the document</translation>
    </message>
    <message>
        <source>Link</source>
        <translation>Link</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation>Kommentaarid</translation>
    </message>
    <message>
        <source>Add Sticky Note</source>
        <translation>Märge</translation>
    </message>
    <message>
        <source>Add Sticky Notes</source>
        <translation type="obsolete">Märge</translation>
    </message>
    <message>
        <source>Image</source>
        <translation>Pilt</translation>
    </message>
    <message>
        <source>There was an error opening the document !</source>
        <translation>There was an error opening the document.The file is corrupted and could not be repaired.</translation>
    </message>
    <message>
        <source>Page layout</source>
        <translation>Page Format</translation>
    </message>
    <message>
        <source>Insert a blank page </source>
        <translation type="vanished">Insert Pages</translation>
    </message>
    <message>
        <source>Insert a Blank Page(s)</source>
        <translation type="vanished">Insert Pages</translation>
    </message>
    <message>
        <source>Delete Page(s)</source>
        <translation type="vanished">Kustutatud leheküljed</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Leheküljed</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Võta tagasi</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation>Korda</translation>
    </message>
    <message>
        <source>Create a new blank PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print (Ctrl+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished">Sulguda</translation>
    </message>
    <message>
        <source>Ctrl+T</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+I</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send to Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Send to Back&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send to Back selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Del</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+Del</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Main</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Images</source>
        <translation type="unfinished">Images</translation>
    </message>
    <message>
        <source>Ctrl+D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Home page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Undo (Ctrl+Z)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Undo the last action&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl++</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redo (Ctrl+Y)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Redo the previously undone action.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cut (Ctrl+X)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cut the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copy (Ctrl+C)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copy the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HTML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Empty recent files list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export completed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All Files (*.pdf *.xps);;PDF Files (*.pdf);;XPS Files (*.xps)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Document Properties</source>
        <translation type="obsolete">Dokumendi omadused</translation>
    </message>
    <message>
        <source>Contents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Find Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Version Is Available !
Do you want to Download Now?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close Without Saving</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished">Tühista</translation>
    </message>
    <message>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rotate Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Document Info</source>
        <translation type="obsolete">Kirjeldus</translation>
    </message>
    <message>
        <source>Object Inspector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The unregistered version will insert a watermark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ellipse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set Fit to Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A error occurred during the signature verification!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Paste (Ctrl+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Paste from the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Master PDF Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forms</source>
        <translation type="unfinished">Vormid</translation>
    </message>
    <message>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>End</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset Forms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Facing Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Forms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bring to Front</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Bring To Front&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Bring to Front selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extract Pages...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert Pages...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pencil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PDF Files (*.pdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open a PDF file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PgUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PgDown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished">Kustuta</translation>
    </message>
    <message>
        <source>Ctrl+L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Saving in XPS is temporarily not supported.
Choose PDF file name for saving.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Object Inspector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Crop Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+K</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Prev/Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+H</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+F11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert Blank Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift++</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FDF Files (*.fdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export Form Data...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import Form Data...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export Comments Data...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import Comments Data...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Open File (Ctrl+O)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Open a PDF or XPS file&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select text for copying and pasting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Save (Ctrl+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Save the document&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Save As PDF(Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Save the document with a new name&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save the document with a new name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Document (Alt+1)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select and edit text, images, annotations, form fields ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select and edit text, images, annotations, form fields ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select text for editing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Delete Object(s) (Del)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Delete the currently selected object(s)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete the currently selected object(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;New (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Create a new blank PDF&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cut the selection Object(s) and place on the Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy the selection Object(s) and place on the Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paste from the Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Undo the last action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Redo the previously undone action.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send to Back selected object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bring to Front selected object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Properties (Ctrl+D)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Open window with document properties&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open window with document properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Sticky Note&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Click the page to add a note at that position&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click the page to add a note at that position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Text (Ctrl+T)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new text to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert new text to current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Image (Ctrl+I)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new image to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert new image to current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Link (Ctrl+L)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new link to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert new link to current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text (Alt+5)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for copying and pasting&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+I</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Optimized As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Alt+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chacters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font Embedded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Width</source>
        <translation type="unfinished">Laius</translation>
    </message>
    <message>
        <source>Height</source>
        <translation type="unfinished">Kõrgus</translation>
    </message>
    <message>
        <source>Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t find :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font Not Embedded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Form (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select form and annotations for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Text Object(Alt+2)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use the hand tool for moving pages, open links and selecting text.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+6</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MovePagesDialog</name>
    <message>
        <source>Move Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="unfinished">Select Page Range</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="unfinished">Leheküljed</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="unfinished">Praegune lehekülg</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="unfinished">Selected Pages</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="unfinished">kuni:</translation>
    </message>
    <message>
        <source>Destination</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MovePagesDlg</name>
    <message>
        <source>Page Range</source>
        <translation type="obsolete">Select Page Range</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="obsolete">Praegune lehekülg</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">kuni:</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="obsolete">Selected Pages</translation>
    </message>
</context>
<context>
    <name>NewPageDialog</name>
    <message>
        <source>Page Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Width</source>
        <translation type="unfinished">Laius</translation>
    </message>
    <message>
        <source>Height</source>
        <translation type="unfinished">Kõrgus</translation>
    </message>
    <message>
        <source>A0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom page size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portrait</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Landscape</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contents Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Top margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bottom margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Before current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>After current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>After last page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Before first page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Number of pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Letter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tabloid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Statement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Executive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Folio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quarto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ANSI C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ANSI D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ANSI E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ANSI F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> px</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Units</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ObjectInspector</name>
    <message>
        <source>No Properties
There is no object selections.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="unfinished">Tekst</translation>
    </message>
    <message>
        <source>Property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font Family</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="unfinished">Maht</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fill Color</source>
        <translation type="unfinished">Täidise värvus:</translation>
    </message>
    <message>
        <source>Stroke Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opacity</source>
        <translation type="unfinished">Läbipaistmatus</translation>
    </message>
    <message>
        <source>Image</source>
        <translation type="unfinished">Pilt</translation>
    </message>
    <message>
        <source>Width</source>
        <translation type="unfinished">Laius</translation>
    </message>
    <message>
        <source>Height</source>
        <translation type="unfinished">Kõrgus</translation>
    </message>
    <message>
        <source>Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Form Field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished">Nimi</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">Paks</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">Kaldkiri</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Goto a Page View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show/Hide fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Submit a form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Run a JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add an Action</source>
        <translation type="unfinished">Lisa tegevus</translation>
    </message>
    <message>
        <source>Trigger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mouse Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mouse Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mouse Enter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mouse Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>On Receive Focus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>On Lose Focus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="unfinished">Lisa</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation type="unfinished">Toimingud</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished">Redigeerimine</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished">Kustuta</translation>
    </message>
    <message>
        <source>Up Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Behavior</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Push</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Outline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Down Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RollOver Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Up</source>
        <translation type="unfinished">Üles</translation>
    </message>
    <message>
        <source>Down</source>
        <translation type="unfinished">Alla</translation>
    </message>
    <message>
        <source>Sort Items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Commit selected value immediately</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Multiple selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Allow user to enter custom text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scrollable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check spelling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Limit to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>chars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Split into</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Allow Rich Text formatting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Multi-line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cells</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alignment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="unfinished">Stiil</translation>
    </message>
    <message>
        <source>Check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Circle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cross</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Diamond</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Square</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Star</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Checked by Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line Thickness</source>
        <translation type="unfinished">Paksus:</translation>
    </message>
    <message>
        <source>Border Color</source>
        <translation type="unfinished">Piirjoone värvus:</translation>
    </message>
    <message>
        <source>Line Style</source>
        <translation type="unfinished">Line Style:</translation>
    </message>
    <message>
        <source>Solid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dashed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Underline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Highlight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OutLine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert</source>
        <translation type="unfinished">Sisesta</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Signature.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;No available options&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Format</source>
        <translation type="unfinished">Formaat</translation>
    </message>
    <message>
        <source>Format category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Percentage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Special</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1,234.56</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1234.56</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1.234,56</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1234,56</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Currency Symbol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dollar ($)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Euro (€)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pound (£)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yen (¥)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ruble (Руб)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show parentheses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Decimal Places</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Separation Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use red text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Special Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Format Script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>KeyStroke Script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Validate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Validation Script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Calculate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Calculation Script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Full text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stroke Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Full and Stroke</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invisible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Full Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Character spacing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Word spacing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Coordinates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Absolute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Relative</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Matrix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cliping Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type="unfinished">Välimus</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished">Sätted</translation>
    </message>
    <message>
        <source>Full</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stroke</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="unfinished">Värvus</translation>
    </message>
    <message>
        <source>Borders and Colors</source>
        <translation type="unfinished">Äärised ja värvused</translation>
    </message>
    <message>
        <source>Thin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Medium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Beveled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ToolTip</source>
        <translation type="unfinished">Hint:</translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation type="unfinished">Orientation:</translation>
    </message>
    <message>
        <source>0 Degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>90 Degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>180 Degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>270 Degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Read Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Visible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hidden</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Visible but doesn&apos;t print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hidden but printable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Locked</source>
        <translation type="unfinished">Lukustatud</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the fill color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font Stroke color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the stroke color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subject</source>
        <translation type="unfinished">Teema:</translation>
    </message>
    <message>
        <source>Author</source>
        <translation type="unfinished">Autor:</translation>
    </message>
    <message>
        <source>Maintain aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zip Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zip Code+4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phone Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Social Security Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check Mark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="unfinished">Abi</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Paragraph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paragraph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right Pointer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Up Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Up Left Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Graph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paper Clip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attachment</source>
        <translation type="unfinished">Manused</translation>
    </message>
    <message>
        <source>Tag</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PageLayoutDialog</name>
    <message>
        <source>Page Layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contents Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Top margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bottom margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Width</source>
        <translation type="unfinished">Laius</translation>
    </message>
    <message>
        <source>Height</source>
        <translation type="unfinished">Kõrgus</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="unfinished">Select Page Range</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="unfinished">Selected Pages</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="unfinished">Praegune lehekülg</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="unfinished">Kõik leheküljed</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="unfinished">kuni:</translation>
    </message>
    <message>
        <source> px</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Even and Odd pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PasswordOpenDialog</name>
    <message>
        <source>Password:</source>
        <translation>Parool:</translation>
    </message>
    <message>
        <source>The file is protected. Please enter a Document Open Password</source>
        <translation>This file is password protected. Please enter a password to open this Document.</translation>
    </message>
    <message>
        <source>Enter Password</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlainTextEdit</name>
    <message>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrintDialog</name>
    <message>
        <source>Print Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Printer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="unfinished">Dokumendi omadused</translation>
    </message>
    <message>
        <source>Antialiasing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print as Grayscale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aspect Ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ignore aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keep aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keep aspect ratio by expanding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation type="unfinished">Orientation:</translation>
    </message>
    <message>
        <source>Portrait</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Landscape</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="unfinished">Select Page Range</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="unfinished">Kõik leheküljed</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="unfinished">Selected Pages</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="unfinished">Praegune lehekülg</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="unfinished">kuni:</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Collate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="unfinished">Prindi</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>of:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>of </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>72</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>150</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>300</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>600</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>900</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1200</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DPI</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QAttachment</name>
    <message>
        <source>Size</source>
        <translation>Maht</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Kirjeldus</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Kustuta</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation>Salvesta nimega</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished">Nimi</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation type="unfinished">Sisesta</translation>
    </message>
    <message>
        <source>Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attachment Tab</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QBookmarksTree</name>
    <message>
        <source>Add Bookmark</source>
        <translation>Lisa järjehoidja</translation>
    </message>
    <message>
        <source>Delete Bookmark</source>
        <translation>Delete Bookmark</translation>
    </message>
    <message>
        <source>Bookmark Properties</source>
        <translation>Järjehoidja omadused</translation>
    </message>
    <message>
        <source>Set Destination</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QDocTab</name>
    <message>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The clipboard doesn&apos;t contain an data</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QHTMLEditor</name>
    <message>
        <source>File</source>
        <translation type="obsolete">Fail</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete">Redigeerimine</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Võta tagasi</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">Korda</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">Kopeeri</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">Kleebi</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">Paks</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">Kaldkiri</translation>
    </message>
</context>
<context>
    <name>QHtmlFormEditor</name>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Võta tagasi</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">Korda</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">Kopeeri</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">Kleebi</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">Paks</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">Kaldkiri</translation>
    </message>
</context>
<context>
    <name>QHttp</name>
    <message>
        <source>HTTPS connection requested but SSL support not compiled in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Request aborted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No server set to connect to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wrong content length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Server closed connection unexpectedly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connection refused (or timed out)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Host %1 not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HTTP request failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid HTTP response header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unknown authentication method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Proxy authentication required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Authentication required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid HTTP chunked body</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error writing response to device</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QPDFDocument</name>
    <message>
        <source>Error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There was a problem with your form submission.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your form was successfully submitted!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QTabPage</name>
    <message>
        <source>Pages</source>
        <translation type="unfinished">Leheküljed</translation>
    </message>
    <message>
        <source>Enlarge Page Thumbnails</source>
        <translation type="unfinished">Suurenda lehe pisipilte</translation>
    </message>
    <message>
        <source>Reduce Page Thumbnails</source>
        <translation type="unfinished">Vähenda lehe pisipilte</translation>
    </message>
    <message>
        <source>Bookmarks</source>
        <translation type="unfinished">Järjehoidjad</translation>
    </message>
    <message>
        <source>Attachment</source>
        <translation type="unfinished">Manused</translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Object Inspector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This document contains interactive form fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Highlight Fields</source>
        <translation type="unfinished">Too kõik väljad esile</translation>
    </message>
    <message>
        <source>This document is protected. You do not have permissions to edit this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There was an error printing the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert a blank page </source>
        <translation type="obsolete">Insert Pages</translation>
    </message>
    <message>
        <source>Do you want to open?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to set the destination of the selected bookmark to the current location?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert Blank Pages</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtColorComboBox</name>
    <message>
        <source>More...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User color %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User Color 99</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Black</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>White</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Green</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark green</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cyan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark cyan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Magenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark magenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yellow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark yellow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Light gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transparent</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RegDialog</name>
    <message>
        <source>Registration Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>After your order has been completed, 
you will automatically 
receive your Registration code via e-mail.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Buy Online</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Registration Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Activate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Offline Activation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Registered version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you want to register that license on another PC 
click &quot;Deactivate&quot; button. 

Then register it where you need.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Deactivate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Activation Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please send the ID key and Registration code to: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Once you receive your code enter it into &amp;quot;Activation code&amp;quot; field&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RotatePagesDlg</name>
    <message>
        <source>Rotate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="unfinished">Select Page Range</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="unfinished">Leheküljed</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="unfinished">Praegune lehekülg</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="unfinished">Selected Pages</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="unfinished">kuni:</translation>
    </message>
    <message>
        <source>Direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clockwise 90 degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>180 degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Counterclockwise 90 degrees</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SaveImageDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Tühista</translation>
    </message>
    <message>
        <source>Width</source>
        <translation>Laius</translation>
    </message>
    <message>
        <source>Height</source>
        <translation>Kõrgus</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Formaat</translation>
    </message>
    <message>
        <source>File Name</source>
        <translation>Faili nimi</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation>Selected Pages</translation>
    </message>
    <message>
        <source>to:</source>
        <translation>kuni:</translation>
    </message>
    <message>
        <source>Export to Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="unfinished">Select Page Range</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="unfinished">Kõik leheküljed</translation>
    </message>
    <message>
        <source>JPEG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BMP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PNG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TIFF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>JPEG Quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LZW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ZIP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CCITT FAX 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CCITT FAX 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TIFF Compression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="unfinished">Maht</translation>
    </message>
    <message>
        <source>DPI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">Salvesta</translation>
    </message>
    <message>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save As Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MultiPage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save As TIFF Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TIFF Files (*.tif *.tiff)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transparent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Antialiasing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SaveOptimizedDialog</name>
    <message>
        <source>Remove unused elements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flatten form fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color and Grayscale Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DPI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ZIP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>JPEG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lossless</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>JPEG Quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Black and White Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CCITT Group 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>JBIG2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Optimized As...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchFormTab</name>
    <message>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0 result</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Case Sensitive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> result</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> result(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Include Comments</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchLineEdit</name>
    <message>
        <source>Case Sensitive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Include Comments</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SecurityDialog</name>
    <message>
        <source>Security PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Required a password to open the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Document Open Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Permissions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Commenting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modifying document</source>
        <translation type="unfinished">Modify document</translation>
    </message>
    <message>
        <source>Content copying for accessibility</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Printing the document</source>
        <translation type="unfinished">Print Permission</translation>
    </message>
    <message>
        <source>Extract the content of the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print a high resolution version of the document</source>
        <translation type="unfinished">Print with high resolution</translation>
    </message>
    <message>
        <source>Fill in existing form or signature fields</source>
        <translation type="unfinished">Vormiväljade täitmine</translation>
    </message>
    <message>
        <source>Permissions Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manage Pages and bookmarks</source>
        <translation type="unfinished">Manage pages and bookmarks</translation>
    </message>
    <message>
        <source>Document Open password does not match.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Document Permission password does not match.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SignatureDialog</name>
    <message>
        <source>Signature Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Signature is VALID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Signed by:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reason:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Location:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Validation Summary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Signer&apos;s Contact Information:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text For Signing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reason</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lock document after signing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Signature Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>I have reviewed this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>I am approving this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>I attest to the accuracy and integrity of this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>I agree to specified parts of this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="obsolete">Sirvi...</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>p12 Files (*.p12)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A password is required to open certificate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sign</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stretch Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A error occurred during the signature verification!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image Files (*.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The document has been altered or corrupted since the signatures was applied.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Document has not been changed since the signatures was applied.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Signature is INVALID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Signature validity is UNKNOWN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The signers identity is unknown because it has not been include in your list of trusted identities and none of its parent certificates is trust identities.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error during signature verification.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Details: The signature byte range is invalid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>I am the author of this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This certificate is not trusted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sign As</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SignatureInfoDialog</name>
    <message>
        <source>Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Issuer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Common Name (CN)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Organization (O)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Organizational Unit (OU)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Serial Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Algorithm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subject</source>
        <translation type="unfinished">Teema:</translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Validity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not Before</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not After</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SHA-1:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MD5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add to Trusted Identities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Data</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StickyNoteDlg</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="obsolete">Sätted</translation>
    </message>
</context>
<context>
    <name>TextDialog</name>
    <message>
        <source>Font:</source>
        <translation type="obsolete">Fondi nimi</translation>
    </message>
    <message>
        <source>Font size:</source>
        <translation type="obsolete">Kirja suurus</translation>
    </message>
    <message>
        <source>Font color:</source>
        <translation type="obsolete">Teksti värvus</translation>
    </message>
</context>
</TS>
