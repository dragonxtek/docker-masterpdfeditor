<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="it">
<context>
    <name>AboutDialog</name>
    <message>
        <source>About</source>
        <translation>Riferimenti</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>Application</name>
    <message>
        <source>File</source>
        <translation type="vanished">File</translation>
    </message>
    <message>
        <source>New</source>
        <translation type="vanished">Nuovo</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="vanished">Apri</translation>
    </message>
    <message>
        <source>Recent Files</source>
        <translation type="vanished">File recenti</translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="obsolete">Guida</translation>
    </message>
    <message>
        <source>Contents</source>
        <translation type="vanished">Contenuti</translation>
    </message>
    <message>
        <source>Suggestions...</source>
        <translation type="vanished">Suggerimenti...</translation>
    </message>
    <message>
        <source>Register...</source>
        <translation type="vanished">Registrazione...</translation>
    </message>
    <message>
        <source>Check for Update</source>
        <translation type="vanished">Controlla aggiornamenti</translation>
    </message>
    <message>
        <source>Empty recent files list</source>
        <translation type="vanished">Svuota lista files recenti</translation>
    </message>
    <message>
        <source>Help...</source>
        <translation type="vanished">Guida...</translation>
    </message>
</context>
<context>
    <name>BookmarksDialogProp</name>
    <message>
        <source>Bookmark Properties</source>
        <translation>Proprietà segnalibro</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Impostazioni</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Testo</translation>
    </message>
    <message>
        <source>Style</source>
        <translation>Stile</translation>
    </message>
    <message>
        <source>Plain</source>
        <translation>Semplice</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation>Corsivo</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation>Grassetto</translation>
    </message>
    <message>
        <source>Italic &amp; Bold</source>
        <translation>Grassetto corsivo</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>Colore</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation>Azioni</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Modifica</translation>
    </message>
    <message>
        <source>Add an Action</source>
        <translation>Aggiungi azione</translation>
    </message>
    <message>
        <source>Trigger</source>
        <translation>Azione</translation>
    </message>
    <message>
        <source>Action</source>
        <translation>Effetto</translation>
    </message>
    <message>
        <source>Mouse Up</source>
        <translation>Mouse su</translation>
    </message>
    <message>
        <source>Goto a Page View</source>
        <translation>Passa a Vista pagina</translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation>Apri/Esegui un file</translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation>Apri un collegamento web</translation>
    </message>
    <message>
        <source>Reset form</source>
        <translation>Reimposta modulo</translation>
    </message>
    <message>
        <source>Show/Hide fields</source>
        <translation>Mostra/Nascondi campi</translation>
    </message>
    <message>
        <source>Submit a form</source>
        <translation>Conferma un modulo</translation>
    </message>
    <message>
        <source>Run a JavaScript</source>
        <translation>Esegui un JavaScript</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Aggiungi</translation>
    </message>
    <message>
        <source>Page Number</source>
        <translation>Numero pagina</translation>
    </message>
    <message>
        <source>Set current position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Aspetto</translation>
    </message>
    <message>
        <source>untitled</source>
        <translation>senza titolo</translation>
    </message>
    <message>
        <source>Do you want to set the current position?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogDeletePages</name>
    <message>
        <source>The removed page(s) will never recovered, delete it anyway?</source>
        <translation type="obsolete">Do you want to delete these pages? The operation cannot be undone.</translation>
    </message>
    <message>
        <source>Delete Page(s)</source>
        <translation>Elimina Pagine</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>Seleziona intervallo pagine</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>Pagina corrente</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation>Pagine selezionate da</translation>
    </message>
    <message>
        <source>to:</source>
        <translation>a:</translation>
    </message>
    <message>
        <source>The removed page(s) cannot be recovered with undo operation.</source>
        <translation>Le pagine rimosse non saranno recuperabili.</translation>
    </message>
    <message>
        <source>Selected pages</source>
        <translation type="vanished">Pagine selezionate</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>Pagine</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation>Esempio: 1,6-8,12</translation>
    </message>
</context>
<context>
    <name>DialogFormFields</name>
    <message>
        <source>Button</source>
        <translation type="obsolete">Pulsanti</translation>
    </message>
</context>
<context>
    <name>DialogNotes</name>
    <message>
        <source>Opacity</source>
        <translation type="vanished">Opacità</translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="vanished">Testo</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type="vanished">Aspetto</translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="vanished">Colore</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="vanished">Generale</translation>
    </message>
    <message>
        <source>Author</source>
        <translation type="vanished">Autore</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation type="vanished">Soggetto</translation>
    </message>
    <message>
        <source>Locked</source>
        <translation type="vanished">Bloccato</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="vanished">Impostazioni</translation>
    </message>
</context>
<context>
    <name>DialogRotatePage</name>
    <message>
        <source>Rotate Pages</source>
        <translation type="vanished">Ruota pagine</translation>
    </message>
    <message>
        <source>Direction</source>
        <translation type="vanished">Direzione</translation>
    </message>
    <message>
        <source>Clockwise 90 degrees</source>
        <translation type="vanished">Rotazione oraria di 90 gradi</translation>
    </message>
    <message>
        <source>180 degrees</source>
        <translation type="vanished">180 gradi</translation>
    </message>
    <message>
        <source>Counterclockwise 90 degrees</source>
        <translation type="vanished">Rotazione antioraria di 90 gradi</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Seleziona intervallo pagine</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">a:</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Dalla pagina</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Pagina corrente</translation>
    </message>
</context>
<context>
    <name>DocPage</name>
    <message>
        <source>Edit text</source>
        <translation type="vanished">Modifica testo</translation>
    </message>
    <message>
        <source>Save Image to file</source>
        <translation type="vanished">Salva immagine come file</translation>
    </message>
    <message>
        <source>Object Properties...</source>
        <translation type="vanished">Proprietà oggetto...</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Taglia</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copia</translation>
    </message>
    <message>
        <source>Send To Back</source>
        <translation type="vanished">Posiziona dietro</translation>
    </message>
    <message>
        <source>Bring To Front</source>
        <translation type="vanished">In primo piano</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="vanished">Elimina</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="vanished">Annulla operazione</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Seleziona tutto</translation>
    </message>
    <message>
        <source>UnSelect</source>
        <translation type="vanished">Deseleziona</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Incolla </translation>
    </message>
    <message>
        <source>PNG Images (*.png);;BMP Images (*.bmp)</source>
        <translation type="vanished">Immagini PNG (*.png);;Immagini BMP (*.bmp)</translation>
    </message>
    <message>
        <source>PNG Images (*.png)</source>
        <translation type="vanished">Immagini PNG (*.png)</translation>
    </message>
    <message>
        <source>The clipboard doesn&apos;t contain an data</source>
        <translation type="vanished">Nessun dato negli appunti</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="vanished">Salva con nome...</translation>
    </message>
    <message>
        <source>Error loading default font</source>
        <translation type="vanished">Errore nel caricare il carattere predefinito</translation>
    </message>
    <message>
        <source>Set Fit to Page</source>
        <translation type="vanished">Imposta adattamento pagina</translation>
    </message>
    <message>
        <source>Add Sticky Note</source>
        <translation type="unfinished">Aggiungi annotazione</translation>
    </message>
    <message>
        <source>Highlight Text</source>
        <translation type="unfinished">Testo evidenziato</translation>
    </message>
    <message>
        <source>Strikeout Text</source>
        <translation type="unfinished">Testo barrato</translation>
    </message>
    <message>
        <source>Underline Text</source>
        <translation type="unfinished">Testo sottolineato</translation>
    </message>
    <message>
        <source>Add Bookmark</source>
        <translation type="unfinished">Aggiungi segnalibro</translation>
    </message>
</context>
<context>
    <name>DocPageBase</name>
    <message>
        <source>Copy</source>
        <translation type="unfinished">Copia</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="unfinished">Taglia</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="unfinished">Incolla </translation>
    </message>
    <message>
        <source>Select All</source>
        <translation type="unfinished">Seleziona tutto</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished">Impostazioni</translation>
    </message>
    <message>
        <source>Edit text</source>
        <translation type="unfinished">Modifica testo</translation>
    </message>
    <message>
        <source>Signature options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished">Elimina</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation type="unfinished">Apri immagine</translation>
    </message>
    <message>
        <source>Image Files (*.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation type="obsolete">File immagine (*.tif *.png *.jpg *.jpeg *.bmp)</translation>
    </message>
    <message>
        <source>ERORR Load Image !</source>
        <translation type="unfinished">ERRORE nel caricare l&apos;immagine!</translation>
    </message>
    <message>
        <source>Set Fit to Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Image to file</source>
        <translation type="unfinished">Salva immagine come file</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="unfinished">Salva con nome...</translation>
    </message>
    <message>
        <source>PNG Images (*.png);;BMP Images (*.bmp)</source>
        <translation type="unfinished">Immagini PNG (*.png);;Immagini BMP (*.bmp)</translation>
    </message>
    <message>
        <source>PNG Images (*.png)</source>
        <translation type="unfinished">Immagini PNG (*.png)</translation>
    </message>
    <message>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditActionForm</name>
    <message>
        <source>Action</source>
        <translation>Azione</translation>
    </message>
    <message>
        <source>Java script editor</source>
        <translation>Editor JavaScript</translation>
    </message>
    <message>
        <source>Goto a page</source>
        <translation>Vai alla pagina</translation>
    </message>
    <message>
        <source>auto</source>
        <translation>automatico</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>In cima</translation>
    </message>
    <message>
        <source>Left</source>
        <translation>A sinistra</translation>
    </message>
    <message>
        <source>Page Number</source>
        <translation>Numero pagina</translation>
    </message>
    <message>
        <source>Zoom (%)</source>
        <translation>Zoom (%)</translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation>Apri/Esegui un file</translation>
    </message>
    <message>
        <source>Edit a file</source>
        <translation>Modifica un file</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>Visualizza</translation>
    </message>
    <message>
        <source>Select Fields</source>
        <translation>Seleziona campi</translation>
    </message>
    <message>
        <source>Deselect All</source>
        <translation>Deseleziona tutto</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>Nascondi</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Seleziona tutto</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Formato</translation>
    </message>
    <message>
        <source>FDF</source>
        <translation>FDF</translation>
    </message>
    <message>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <source>XFDF</source>
        <translation>XFDF</translation>
    </message>
    <message>
        <source>PDF</source>
        <translation>PDF</translation>
    </message>
    <message>
        <source>Method</source>
        <translation>Metodo</translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation>Apri collegamento web</translation>
    </message>
    <message>
        <source>Show/Hide Fields</source>
        <translation>Mostra/Nascondi campi</translation>
    </message>
    <message>
        <source>Reset Form</source>
        <translation>Reimposta modulo</translation>
    </message>
    <message>
        <source>Enter a file:</source>
        <translation>Inserisci un file</translation>
    </message>
    <message>
        <source>Enter a web site:</source>
        <translation>Inserisci un sito web</translation>
    </message>
    <message>
        <source> px</source>
        <translation></translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished">Impostazioni</translation>
    </message>
    <message>
        <source>Zoom Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inherit Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation type="unfinished">Adatta pagina</translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation type="unfinished">Adatta larghezza</translation>
    </message>
    <message>
        <source>FitV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FitR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FitB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FitBH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FitBV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="unfinished">Sfoglia</translation>
    </message>
    <message>
        <source>Local file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HTTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use anonymous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Need user name and password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="unfinished">Password</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation type="unfinished">Apri file</translation>
    </message>
    <message>
        <source>All Files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Field</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditActionSmallForm</name>
    <message>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation type="unfinished">Apri/Esegui un file</translation>
    </message>
    <message>
        <source>Enter a file:</source>
        <translation>Inserisci un file:</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="unfinished">Sfoglia</translation>
    </message>
    <message>
        <source>Goto a page</source>
        <translation type="unfinished">Vai alla pagina</translation>
    </message>
    <message>
        <source>Page Number</source>
        <translation type="unfinished">Numero pagina</translation>
    </message>
    <message>
        <source>Zoom Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom (%)</source>
        <translation type="unfinished">Zoom (%)</translation>
    </message>
    <message>
        <source>X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FitV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FitR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FitB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FitBH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FitBV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>auto</source>
        <translation type="unfinished">automatico</translation>
    </message>
    <message>
        <source> px</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter a web site:</source>
        <translation>Inserisci un sito web:</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation type="unfinished">Apri file</translation>
    </message>
    <message>
        <source>All Files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>XYZ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FitH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Named Action</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExportPageDialog</name>
    <message>
        <source>Extract pages as a single file</source>
        <translation>Estrai pagine in un unico file</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Sfoglia</translation>
    </message>
    <message>
        <source>Extract Pages</source>
        <translation>Estrai pagine</translation>
    </message>
    <message>
        <source>File Name</source>
        <translation>Nome file</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>Seleziona intervallo pagine</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>Pagina corrente</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Pagine selezionate da</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">a:</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <source>Save As PDF</source>
        <translation>Salva come PDF</translation>
    </message>
    <message>
        <source>PDF Files (*.pdf)</source>
        <translation>File PDF (*.pdf)</translation>
    </message>
    <message>
        <source>Can&apos;t save to the file:</source>
        <translation>Impossibile salvare nel file:</translation>
    </message>
    <message>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
Il file è di sola lettura o utilizzato da altra applicazione</translation>
    </message>
    <message>
        <source>Export Pages</source>
        <translation>Esporta pagine</translation>
    </message>
    <message>
        <source>Export Pages </source>
        <translation>Esporta pagine </translation>
    </message>
    <message>
        <source>Export Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="unfinished">Tutte le pagine</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="unfinished">Pagine</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished">Esempio: 1,6-8,12</translation>
    </message>
</context>
<context>
    <name>FileSettings</name>
    <message>
        <source>Document Properties</source>
        <translation>Proprietà documento</translation>
    </message>
    <message>
        <source>Document Info</source>
        <translation>Informazioni documento</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Titolo</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Soggetto</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autore</translation>
    </message>
    <message>
        <source>Keywords</source>
        <translation>Parole chiave</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Ideatore</translation>
    </message>
    <message>
        <source>Producer</source>
        <translation>Produttore</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>Sicurezza</translation>
    </message>
    <message>
        <source>Initial View</source>
        <translation>Vista iniziale</translation>
    </message>
    <message>
        <source>Images</source>
        <translation type="vanished">Immagini</translation>
    </message>
    <message>
        <source>Fonts</source>
        <translation>Caratteri</translation>
    </message>
    <message>
        <source>Fonts used in this document</source>
        <translation>Caratteri usati nel documento</translation>
    </message>
    <message>
        <source>Protection</source>
        <translation type="vanished">Protezione</translation>
    </message>
    <message>
        <source>User Password</source>
        <translation type="vanished">Password utente</translation>
    </message>
    <message>
        <source>Owner Password</source>
        <translation type="vanished">Password proprietario</translation>
    </message>
    <message>
        <source>Password Encryption</source>
        <translation>Crittografia password</translation>
    </message>
    <message>
        <source>No Encryption</source>
        <translation>Nessuna crittografia</translation>
    </message>
    <message>
        <source>Printing the document</source>
        <translation>Documento in stampa</translation>
    </message>
    <message>
        <source>Print a high resolution version of the document</source>
        <translation>Stampa in alta risoluzione</translation>
    </message>
    <message>
        <source>Extract text and graphics</source>
        <translation type="vanished">Estrai testo e grafica</translation>
    </message>
    <message>
        <source>Advanced extract text and graphics</source>
        <translation type="vanished">Estrazione avanzata testo e grafica</translation>
    </message>
    <message>
        <source>Modifying document</source>
        <translation>Modifica documento</translation>
    </message>
    <message>
        <source>Modify annotations or form fields</source>
        <translation type="vanished">Modifica annotazioni o campi modulo</translation>
    </message>
    <message>
        <source>Fill in existing form or signature fields</source>
        <translation>Compila un modulo</translation>
    </message>
    <message>
        <source>Manage Pages and bookmarks</source>
        <translation>Gestione pagine e segnalibri</translation>
    </message>
    <message>
        <source>Open to Page:</source>
        <translation>Apri a pagina:</translation>
    </message>
    <message>
        <source>of :</source>
        <translation>di:</translation>
    </message>
    <message>
        <source>PDF Information</source>
        <translation>Informazioni PDF</translation>
    </message>
    <message>
        <source>Page Mode:</source>
        <translation>Modalità pagina:</translation>
    </message>
    <message>
        <source>Show chars</source>
        <translation type="vanished">Mostra caratteri</translation>
    </message>
    <message>
        <source>High Encryption Level (128 bits) </source>
        <translation type="vanished">Livello crittografia elevato (128 bit)</translation>
    </message>
    <message>
        <source>Page Only</source>
        <translation>Solo la pagina</translation>
    </message>
    <message>
        <source>Bookmarks Panel</source>
        <translation>Pannello segnalibri</translation>
    </message>
    <message>
        <source>Pages Panel</source>
        <translation>Pannello pagine</translation>
    </message>
    <message>
        <source>Attachments Panel</source>
        <translation>Pannello allegati</translation>
    </message>
    <message>
        <source>Layers Panel</source>
        <translation>Pannello livelli</translation>
    </message>
    <message>
        <source>Full Screen</source>
        <translation>Schermo intero</translation>
    </message>
    <message>
        <source>Color and Grayscale Images</source>
        <translation type="vanished">Immagini a colori e scala di grigi</translation>
    </message>
    <message>
        <source>JPEG</source>
        <translation type="vanished">JPEG</translation>
    </message>
    <message>
        <source>ZIP</source>
        <translation type="vanished">ZIP</translation>
    </message>
    <message>
        <source>Compression</source>
        <translation type="vanished">Compressione</translation>
    </message>
    <message>
        <source>Image Quality:</source>
        <translation type="vanished">Qualità immagine</translation>
    </message>
    <message>
        <source>Black and White Images</source>
        <translation type="vanished">Immagini bianco e nero</translation>
    </message>
    <message>
        <source>JBIG2</source>
        <translation type="vanished">JBIG2</translation>
    </message>
    <message>
        <source>JPEG 2000</source>
        <translation type="vanished">JPEG 2000</translation>
    </message>
    <message>
        <source>Lossless</source>
        <translation type="vanished">Senza perdita</translation>
    </message>
    <message>
        <source>Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Permissions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extract the content of the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Content copying for accessibility</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Commenting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Run JavaScript on Document Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="unfinished">Aggiungi</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished">Elimina</translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="unfinished">Password</translation>
    </message>
    <message>
        <source>The document is protected. Please enter a permissions password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Incorrect password. Please input the owner password.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormDialogProp</name>
    <message>
        <source>System</source>
        <translation type="obsolete">Sistema</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type="vanished">Aspetto</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="vanished">Impostazioni</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation type="vanished">Azioni impostate</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="vanished">Elimina</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">Chiudi</translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="vanished">Stile</translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="vanished">Colore</translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="vanished">Aggiungi</translation>
    </message>
    <message>
        <source>Locked</source>
        <translation type="vanished">Bloccato</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="vanished">Nome</translation>
    </message>
    <message>
        <source>Borders and Colors</source>
        <translation type="vanished">Bordi e Colori</translation>
    </message>
    <message>
        <source>Add an Action</source>
        <translation type="vanished">Aggiungi azione</translation>
    </message>
    <message>
        <source>ToolTip</source>
        <translation type="vanished">Descrizione</translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation type="vanished">Orientamento</translation>
    </message>
    <message>
        <source>Line Style</source>
        <translation type="vanished">Stile linea</translation>
    </message>
    <message>
        <source>Line Thickness</source>
        <translation type="vanished">Spessore</translation>
    </message>
    <message>
        <source>Fill Color</source>
        <translation type="vanished">Colore pieno</translation>
    </message>
    <message>
        <source>Border Color</source>
        <translation type="vanished">Colore bordi</translation>
    </message>
    <message>
        <source>Up</source>
        <translation type="vanished">Su</translation>
    </message>
    <message>
        <source>Down</source>
        <translation type="vanished">Giù</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="vanished">Proprietà</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="vanished">Generale</translation>
    </message>
    <message>
        <source>0 Degrees</source>
        <translation type="vanished">0 gradi</translation>
    </message>
    <message>
        <source>90 Degrees</source>
        <translation type="vanished">90 gradi</translation>
    </message>
    <message>
        <source>180 Degrees</source>
        <translation type="vanished">180 gradi</translation>
    </message>
    <message>
        <source>270 Degrees</source>
        <translation type="vanished">270 gradi</translation>
    </message>
    <message>
        <source>Visible</source>
        <translation type="vanished">Visibile</translation>
    </message>
    <message>
        <source>Printable</source>
        <translation type="vanished">Stampabile</translation>
    </message>
    <message>
        <source>Read Only</source>
        <translation type="vanished">Sola lettura</translation>
    </message>
    <message>
        <source>Required</source>
        <translation type="vanished">Necessario</translation>
    </message>
    <message>
        <source>Solid</source>
        <translation type="vanished">Uniforme</translation>
    </message>
    <message>
        <source>Dashed</source>
        <translation type="vanished">Tratteggiato</translation>
    </message>
    <message>
        <source>Underline</source>
        <translation type="vanished">Sottolineato</translation>
    </message>
    <message>
        <source>Beveled</source>
        <translation type="vanished">Smussato</translation>
    </message>
    <message>
        <source>Inset</source>
        <translation type="vanished">Inserto</translation>
    </message>
    <message>
        <source>Thin</source>
        <translation type="vanished">Sottile</translation>
    </message>
    <message>
        <source>Medium</source>
        <translation type="vanished">Medio</translation>
    </message>
    <message>
        <source>Thick</source>
        <translation type="vanished">Spesso</translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="vanished">Testo</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="vanished">Dimensione</translation>
    </message>
    <message>
        <source>Font</source>
        <translation type="vanished">Carattere</translation>
    </message>
    <message>
        <source>Behavior</source>
        <translation type="obsolete">Comportamento</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="obsolete">Nessuno</translation>
    </message>
    <message>
        <source>Push</source>
        <translation type="obsolete">Premi</translation>
    </message>
    <message>
        <source>Outline</source>
        <translation type="obsolete">Cornice</translation>
    </message>
    <message>
        <source>Invert</source>
        <translation type="obsolete">Invertito</translation>
    </message>
    <message>
        <source>RollOver Label</source>
        <translation type="obsolete">Etichetta arrotolata</translation>
    </message>
    <message>
        <source>Up Label</source>
        <translation type="obsolete">Etichetta sopra</translation>
    </message>
    <message>
        <source>Down Label</source>
        <translation type="obsolete">Etichetta sotto</translation>
    </message>
    <message>
        <source>Sort Items</source>
        <translation type="obsolete">Disposizione voci</translation>
    </message>
    <message>
        <source>Multiple selection</source>
        <translation type="obsolete">Selezione multipla</translation>
    </message>
    <message>
        <source>Commit selected value immediately</source>
        <translation type="obsolete">Accetta immediatamente il valore selezionato</translation>
    </message>
    <message>
        <source>Item</source>
        <translation type="obsolete">Voce</translation>
    </message>
    <message>
        <source>Export Value</source>
        <translation type="obsolete">Esporta valore</translation>
    </message>
    <message>
        <source>Allow user to enter custom text</source>
        <translation type="obsolete">Consenti l&apos;inserimento di testo personalizzato</translation>
    </message>
    <message>
        <source>Alignment</source>
        <translation type="obsolete">Allineamento</translation>
    </message>
    <message>
        <source>Left</source>
        <translation type="obsolete">A sinistra</translation>
    </message>
    <message>
        <source>Center</source>
        <translation type="obsolete">Al centro</translation>
    </message>
    <message>
        <source>Right</source>
        <translation type="obsolete">A destra</translation>
    </message>
    <message>
        <source>Default Value</source>
        <translation type="obsolete">Valore predefinito</translation>
    </message>
    <message>
        <source>Multi-line</source>
        <translation type="obsolete">Multi-linea</translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="obsolete">Password</translation>
    </message>
    <message>
        <source>Scrollable</source>
        <translation type="obsolete">Scorrevole</translation>
    </message>
    <message>
        <source>Check spelling</source>
        <translation type="obsolete">Controllo ortografico</translation>
    </message>
    <message>
        <source>Limit to</source>
        <translation type="obsolete">Limita a</translation>
    </message>
    <message>
        <source>Allow Rich Text formatting</source>
        <translation type="obsolete">Consenti formattazione Rich Text</translation>
    </message>
    <message>
        <source>Split into</source>
        <translation type="obsolete">Suddividi in</translation>
    </message>
    <message>
        <source>cells</source>
        <translation type="obsolete">celle</translation>
    </message>
    <message>
        <source>chars</source>
        <translation type="obsolete">caratteri</translation>
    </message>
    <message>
        <source>Checked by Default</source>
        <translation type="obsolete">Verifica per impostazione predifinita</translation>
    </message>
    <message>
        <source>Check</source>
        <translation type="obsolete">Verifica</translation>
    </message>
    <message>
        <source>Circle</source>
        <translation type="obsolete">Cerchio</translation>
    </message>
    <message>
        <source>Cross</source>
        <translation type="obsolete">Croce</translation>
    </message>
    <message>
        <source>Diamond</source>
        <translation type="obsolete">Diamante</translation>
    </message>
    <message>
        <source>Square</source>
        <translation type="obsolete">Quadrato</translation>
    </message>
    <message>
        <source>Star</source>
        <translation type="obsolete">Stella</translation>
    </message>
    <message>
        <source>Highlight</source>
        <translation type="obsolete">Evidenziato</translation>
    </message>
    <message>
        <source>OutLine</source>
        <translation type="obsolete">Bordato</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation type="obsolete">menu Inserisci</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Signature.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;No available options&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Firma.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Nessuna opzione disponibile&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Trigger</source>
        <translation type="obsolete">Azione</translation>
    </message>
    <message>
        <source>Action</source>
        <translation type="obsolete">Effetto</translation>
    </message>
    <message>
        <source>Mouse Up</source>
        <translation type="obsolete">Mouse su</translation>
    </message>
    <message>
        <source>Mouse Down</source>
        <translation type="obsolete">Mouse giù</translation>
    </message>
    <message>
        <source>Mouse Enter</source>
        <translation type="obsolete">Inserimento mouse</translation>
    </message>
    <message>
        <source>Mouse Exit</source>
        <translation type="obsolete">Uscita mouse</translation>
    </message>
    <message>
        <source>On Receive Focus</source>
        <translation type="obsolete">Attivando</translation>
    </message>
    <message>
        <source>On Lose Focus</source>
        <translation type="obsolete">Disattivando</translation>
    </message>
    <message>
        <source>Goto a Page View</source>
        <translation type="vanished">Vai a pagina...</translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation type="obsolete">Apri/Esegui un file</translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation type="obsolete">Apri un collegamento web</translation>
    </message>
    <message>
        <source>Reset form</source>
        <translation type="obsolete">Reimposta modulo</translation>
    </message>
    <message>
        <source>Show/Hide fields</source>
        <translation type="obsolete">Mostra/Nascondi campi</translation>
    </message>
    <message>
        <source>Submit a form</source>
        <translation type="obsolete">Conferma un modulo</translation>
    </message>
    <message>
        <source>Run a JavaScript</source>
        <translation type="obsolete">Esegui un JavaScript</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete">Modifica </translation>
    </message>
    <message>
        <source>Link Properties</source>
        <translation type="obsolete">Proprietà collegamento</translation>
    </message>
    <message>
        <source>TextField Properties</source>
        <translation type="obsolete">Proprietà casella di testo</translation>
    </message>
    <message>
        <source>PushButton Properties</source>
        <translation type="obsolete">Proprietà pulsante</translation>
    </message>
    <message>
        <source>CheckBox Properties</source>
        <translation type="obsolete">Proprietà casella di controllo</translation>
    </message>
    <message>
        <source>RadioButton Properties</source>
        <translation type="obsolete">Proprietà casella di scelta</translation>
    </message>
    <message>
        <source>ComboBox Properties</source>
        <translation type="obsolete">Proprietà casella combinata</translation>
    </message>
    <message>
        <source>ListBox Properties</source>
        <translation type="obsolete">Proprietà casella di riepilogo</translation>
    </message>
    <message>
        <source>Signature Properties</source>
        <translation type="obsolete">Proprietà firma</translation>
    </message>
</context>
<context>
    <name>ImportPageDialog</name>
    <message>
        <source>Insert Pages</source>
        <translation>Inserisci pagine</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>Seleziona intervallo pagine</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation>Tutte le pagine</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Pagine selezionate</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">a:</translation>
    </message>
    <message>
        <source>File Name</source>
        <translation>Nome file</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Sfoglia</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Posizione</translation>
    </message>
    <message>
        <source>Before current page</source>
        <translation type="vanished">Prima della pagina corrente</translation>
    </message>
    <message>
        <source>After current page</source>
        <translation type="vanished">Dopo la pagina corrente</translation>
    </message>
    <message>
        <source>After last page</source>
        <translation>Dopo l&apos;ultima pagina</translation>
    </message>
    <message>
        <source>Before first page</source>
        <translation>Prima della pagina iniziale</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>Apri file</translation>
    </message>
    <message>
        <source>PDF Files (*.pdf)</source>
        <translation>File PDF (*.pdf)</translation>
    </message>
    <message>
        <source>Total pages :</source>
        <translation>Totale pagine:</translation>
    </message>
    <message>
        <source>Error read: This PDF is protected.</source>
        <translation>Errore di lettura: questo PDF è protetto</translation>
    </message>
    <message>
        <source>Before page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>After page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="unfinished">Pagine</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished">Esempio: 1,6-8,12</translation>
    </message>
    <message>
        <source>Import Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="unfinished">Password</translation>
    </message>
    <message>
        <source>The file is protected. Please enter a Document Open Password:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>JavaScriptEditDialog</name>
    <message>
        <source>Java Script Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Function Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Java Script</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainOptionsDialog</name>
    <message>
        <source>System</source>
        <translation>Sistema</translation>
    </message>
    <message>
        <source>Forms</source>
        <translation>Moduli</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Lingue</translation>
    </message>
    <message>
        <source>Highlight color</source>
        <translation>Colore evidenziazione</translation>
    </message>
    <message>
        <source>Required field highlight color</source>
        <translation>Evidenzia i campi richiesti</translation>
    </message>
    <message>
        <source>Please choose the interface language</source>
        <translation>Scegli la lingua preferita per l&apos;interfaccia</translation>
    </message>
    <message>
        <source>Check for Updates Automatically</source>
        <translation>Cerca automaticamente aggiornamenti</translation>
    </message>
    <message>
        <source>Weekly</source>
        <translation>Ogni settimana</translation>
    </message>
    <message>
        <source>Monthly</source>
        <translation>Ogni mese</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Mai</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="vanished">Impostazioni</translation>
    </message>
    <message>
        <source> ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Smooth text and images</source>
        <translation type="unfinished">Ammorbidisci testo e immagini</translation>
    </message>
    <message>
        <source>Time before a move or resize starts:</source>
        <translation>Ritardo prima di spostare o ridimensionare</translation>
    </message>
    <message>
        <source>Open saved file with the default viewer after saving</source>
        <translation type="obsolete">Apri il file con il visualizzatore predefinito dopo il salvataggio</translation>
    </message>
    <message>
        <source>Select item by hovering the mouse</source>
        <translation type="unfinished">Seleziona voci al passaggio del mouse</translation>
    </message>
    <message>
        <source>Built-in</source>
        <translation>Preinstallato</translation>
    </message>
    <message>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation>È necessario riavviare il programma per rendere effettive le modifiche</translation>
    </message>
    <message>
        <source>toolBar</source>
        <translation>Barra strumenti</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Aggiorna</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Catalan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chinese-Simplified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chinese-Traditional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Czech</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Danish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Estonian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>French</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Galician</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>German</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Greek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hebrew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Irish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Italiano</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Korean</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Latvian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lithuanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Norwegian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Norwegian-Nynorsk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Polish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese-Brazilian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Russian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slovenian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thai</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Valencian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vietnamese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save PDF file in PDF/A mode.</source>
        <translation type="vanished">Salva file PDF in modalità PDF/A</translation>
    </message>
    <message>
        <source>Saving Documents</source>
        <translation type="unfinished">Salvataggio documenti</translation>
    </message>
    <message>
        <source>Create backup file</source>
        <translation type="unfinished">Crea un file di backup</translation>
    </message>
    <message>
        <source>Choice destination for &quot;Save As&quot; documents</source>
        <translation type="unfinished">Destinazione documenti utilizzando &quot;Salva con nuovo nome&quot;</translation>
    </message>
    <message>
        <source>Last used folder</source>
        <translation>Ultima cartella utilizzata</translation>
    </message>
    <message>
        <source>Original documents folder</source>
        <translation type="unfinished">Cartella di origine dei documenti</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="obsolete">Sfoglia</translation>
    </message>
    <message>
        <source>Default font</source>
        <translation>Carattere predefinito</translation>
    </message>
    <message>
        <source>Editing</source>
        <translation type="unfinished">Modifica</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show</source>
        <translation type="vanished">Visualizza</translation>
    </message>
    <message>
        <source>Crop Box</source>
        <translation type="obsolete">Casella Ritaglia</translation>
    </message>
    <message>
        <source>Media Box</source>
        <translation type="obsolete">Casella Media</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>Colore</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Dimensioni</translation>
    </message>
    <message>
        <source>Armenian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Restore last session when application start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Restore last view settings when reopening</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Always hide document message bar </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default Layout and Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default page layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Single Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Facing Pages</source>
        <translation type="unfinished">Pagine affiancate</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation type="unfinished">Zoom</translation>
    </message>
    <message>
        <source>Actual Size</source>
        <translation type="unfinished">Dimensioni reali</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation type="unfinished">Adatta pagina</translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation type="unfinished">Adatta larghezza</translation>
    </message>
    <message>
        <source>25%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>50%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>75%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>100%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>125%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>150%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>200%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>300%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>400%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>600%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="unfinished">Testo</translation>
    </message>
    <message>
        <source>Bitmap Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vector Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Replace Document Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="unfinished">Impostazioni</translation>
    </message>
    <message>
        <source> Always show Object Inspector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fusion Dark Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Automatically change font when editing text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>System PPI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Icons in menus</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainOptionsDlg</name>
    <message>
        <source>System</source>
        <translation type="obsolete">Generale</translation>
    </message>
    <message>
        <source>Forms</source>
        <translation type="obsolete">Moduli</translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="obsolete">Lingue</translation>
    </message>
    <message>
        <source>Highlight color</source>
        <translation type="obsolete">Colore evidenziazione</translation>
    </message>
    <message>
        <source>Required field highlight color</source>
        <translation type="obsolete">Colore evidenziazione Campi Richiesti</translation>
    </message>
    <message>
        <source>Please choose the interface language</source>
        <translation type="obsolete">Scegli la lingua preferita per l&apos;interfaccia</translation>
    </message>
    <message>
        <source>Check for Updates Automatically</source>
        <translation type="obsolete">Cerca automaticamente aggiornamenti</translation>
    </message>
    <message>
        <source>Weekly</source>
        <translation type="obsolete">Ogni settimana</translation>
    </message>
    <message>
        <source>Monthly</source>
        <translation type="obsolete">Ogni mese</translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="obsolete">Mai</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="obsolete">Impostazioni</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="obsolete">Sfoglia</translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="obsolete">Stile</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Delete Object</source>
        <translation type="vanished">Elimina oggetto</translation>
    </message>
    <message>
        <source>File</source>
        <translation>File</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Apri</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nuovo</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Salva</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation>Salva con nome...</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Stampa</translation>
    </message>
    <message>
        <source>Recent Files</source>
        <translation>File recenti</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation>Esci</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Taglia</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copia</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Incolla </translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Seleziona tutto</translation>
    </message>
    <message>
        <source>First Page</source>
        <translation>Pagina iniziale</translation>
    </message>
    <message>
        <source>Previous Page</source>
        <translation>Pagina precedente</translation>
    </message>
    <message>
        <source>Next Page</source>
        <translation>Pagina successiva</translation>
    </message>
    <message>
        <source>Last Page</source>
        <translation>Ultima pagina</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation>Ingrandisci</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation>Riduci</translation>
    </message>
    <message>
        <source>Actual Size</source>
        <translation>Dimensioni reali</translation>
    </message>
    <message>
        <source>Toolbars</source>
        <translation>Barre degli strumenti</translation>
    </message>
    <message>
        <source>Statusbar</source>
        <translation>Mostra barra di stato</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation>Strumenti</translation>
    </message>
    <message>
        <source>Hand Tool</source>
        <translation>Strumento mano</translation>
    </message>
    <message>
        <source>Register...</source>
        <translation>Registrazione...</translation>
    </message>
    <message>
        <source>Check for Update</source>
        <translation>Controlla aggiornamenti</translation>
    </message>
    <message>
        <source>Export to</source>
        <translation>Esporta</translation>
    </message>
    <message>
        <source>Enlarge Page Thumbnails</source>
        <translation>Ingrandisci miniature</translation>
    </message>
    <message>
        <source>Reduce Page Thumbnails</source>
        <translation>Riduci miniature</translation>
    </message>
    <message>
        <source>Insert Page(s) from PDF</source>
        <translation type="vanished">Inserisci pagine da PDF...</translation>
    </message>
    <message>
        <source>Extract Page(s) to PDF</source>
        <translation type="vanished">Estrai pagine in PDF...</translation>
    </message>
    <message>
        <source>Highlight Fields</source>
        <translation>Evidenzia tutti</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Testo</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation>Proprietà</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="obsolete">Seleziona intervallo pagine</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="obsolete">Tutte le pagine</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="obsolete">Pagina corrente</translation>
    </message>
    <message>
        <source>Plain</source>
        <translation type="obsolete">Semplice</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">Corsivo</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">Grassetto</translation>
    </message>
    <message>
        <source>Italic &amp; Bold</source>
        <translation type="obsolete">Grassetto corsivo</translation>
    </message>
    <message>
        <source>Bookmarks</source>
        <translation type="vanished">Segnalibri</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation>Inserisci</translation>
    </message>
    <message>
        <source>Highlight Text</source>
        <translation>Testo evidenziato</translation>
    </message>
    <message>
        <source>Underline Text</source>
        <translation>Testo sottolineato</translation>
    </message>
    <message>
        <source>Strikeout Text</source>
        <translation>Testo barrato</translation>
    </message>
    <message>
        <source>Attachment</source>
        <translation type="vanished">Allegati</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Impostazioni</translation>
    </message>
    <message>
        <source>Check box</source>
        <translation>Casella di controllo</translation>
    </message>
    <message>
        <source>Radio button</source>
        <translation>Pulsante di scelta</translation>
    </message>
    <message>
        <source>Button</source>
        <translation>Pulsanti</translation>
    </message>
    <message>
        <source>List box</source>
        <translation>Casella di riepilogo</translation>
    </message>
    <message>
        <source>Combo box</source>
        <translation>Casella combinata</translation>
    </message>
    <message>
        <source>Edit Box</source>
        <translation>Casella di testo</translation>
    </message>
    <message>
        <source>Document</source>
        <translation>Documento</translation>
    </message>
    <message>
        <source>The document %s has been modified. 
Do you want to save your changes?</source>
        <translation>Il documento %s è stato modificato.
Vuoi salvare le modifiche prima di chiudere?</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Guida</translation>
    </message>
    <message>
        <source>Help...</source>
        <translation type="obsolete">Guida...</translation>
    </message>
    <message>
        <source>Cannot open file :
</source>
        <translation>Impossibile aprire il file:
</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Visualizza</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Modifica </translation>
    </message>
    <message>
        <source>Your version already has the last update!</source>
        <translation>Nessun aggiornamento disponibile!</translation>
    </message>
    <message>
        <source>Edit Document</source>
        <translation>Modifica il documento</translation>
    </message>
    <message>
        <source>Link</source>
        <translation>Collegamento</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation>Commenti</translation>
    </message>
    <message>
        <source>Add Sticky Note</source>
        <translation>Aggiungi annotazione</translation>
    </message>
    <message>
        <source>Add Sticky Notes</source>
        <translation type="obsolete">Aggiungi annotazioni</translation>
    </message>
    <message>
        <source>Image</source>
        <translation>Immagine</translation>
    </message>
    <message>
        <source>There was an error opening the document !</source>
        <translation>There was an error opening the document.The file is corrupted and could not be repaired !</translation>
    </message>
    <message>
        <source>Page layout</source>
        <translation>Cambia la dimensione di pagina</translation>
    </message>
    <message>
        <source>Insert a blank page </source>
        <translation type="vanished">Inserisci pagina vuota</translation>
    </message>
    <message>
        <source>Insert a Blank Page(s)</source>
        <translation type="vanished">Inserisci pagine vuote</translation>
    </message>
    <message>
        <source>Delete Page(s)</source>
        <translation type="vanished">Elimina pagine</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Pagine</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation>Ripeti</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;New (Ctrl+N)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Create a new blank PDF&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Nuovo PDF (Ctrl+N)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Crea nuovo file PDF vuoto&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Create a new blank PDF</source>
        <translation>Crea un nuovo documento PDF vuoto</translation>
    </message>
    <message>
        <source>Ctrl+N</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Open File (Ctrl+O)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Open a PDF or XPS file&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Apri file (Ctrl+O)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Apre un file PDF o XPS esistente&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Open a PDF or XPS file</source>
        <translation type="obsolete">Apre un file PDF o XPS esistente</translation>
    </message>
    <message>
        <source>Ctrl+O</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Save (Ctrl+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Save the document&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Salva (Ctrl+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Salva il documento modificato&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Save the document</source>
        <translation type="unfinished">Salva il documento corrente</translation>
    </message>
    <message>
        <source>Ctrl+S</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Save As PDF(Ctrl+Alt+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Save the document with a new name&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Salva come PDF (Ctrl+Alt+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Salva il documento con un nuovo nome&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Save the document with a new name</source>
        <translation type="unfinished">Salva il documento con un nuovo nome</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print (Ctrl+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Stampa (Ctrl+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Stampa il documento corrente&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Ctrl+P</source>
        <translation></translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Text (Ctrl+T)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new text to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Inserisci testo (Ctrl+T)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Inserisce nuovo testo nella pagina corrente&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Insert new text to current page</source>
        <translation type="unfinished">Inserisce nuovo testo nella pagina corrente</translation>
    </message>
    <message>
        <source>Ctrl+T</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Image (Ctrl+I)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new image to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Inserisci immagine (Ctrl+I)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Inserisce una nuova immagine nella pagina corrente&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Insert new image to current page</source>
        <translation type="unfinished">Inserisce una nuova immagine nella pagina corrente</translation>
    </message>
    <message>
        <source>Ctrl+I</source>
        <translation></translation>
    </message>
    <message>
        <source>Send to Back</source>
        <translation>Sposta dietro</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Send to Back&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send to Back selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Secondo piano&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Sposta l&apos;oggetto selezionato in secondo piano&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Send to Background</source>
        <translation type="vanished">Usa come sfondo </translation>
    </message>
    <message>
        <source>Bring To Front</source>
        <translation type="vanished">Porta in primo piano</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Bring To Front&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Bring To Front selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Primo piano&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Porta l&apos;oggetto selezionato in primo piano&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Delete Object(s) (Del)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Delete the currently selected object(s)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Elimina oggetti (Del)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Elimina gli oggetti attualmente selezionati&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Delete the currently selected object</source>
        <translation type="obsolete">Elimina gli oggetti attualmente selezionati</translation>
    </message>
    <message>
        <source>Del</source>
        <translation></translation>
    </message>
    <message>
        <source>Goto first page</source>
        <translation type="obsolete">Vai alla prima pagina</translation>
    </message>
    <message>
        <source>Goto previous page</source>
        <translation type="obsolete">Vai alla pagina precedente</translation>
    </message>
    <message>
        <source>Goto next page</source>
        <translation type="obsolete">Vai alla pagina successiva</translation>
    </message>
    <message>
        <source>Goto last page</source>
        <translation type="obsolete">Vai all&apos;ultima pagina</translation>
    </message>
    <message>
        <source>Go to Page</source>
        <translation type="obsolete">Vai alla pagina</translation>
    </message>
    <message>
        <source>Add a blank page</source>
        <translation type="obsolete">Aggiungi una pagina vuota</translation>
    </message>
    <message>
        <source>Delete the current page</source>
        <translation type="obsolete">Elimina la pagina corrente</translation>
    </message>
    <message>
        <source>Alt+Del</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Insert Check Box&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Insert new Check Box to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Inserisci casella di spunta&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Inserisce una nuova casella di spunta nella pagina corrente&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Insert new Check Box to current page</source>
        <translation type="obsolete">Inserisce una nuova casella di spunta nella pagina corrente</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Insert Edit Box&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Insert new Edit Box to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Inserisci casella di modifica&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Inserisce una nuova casella di modifica nella pagina corrente&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Insert new Edit Box to current page</source>
        <translation type="obsolete">Inserisce una nuova casella di modifica nella pagina corrente</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Insert Radio Box&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Insert new Radio Box to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Inserisci casella di scelta&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Inserisce una nuova casella di scelta nella pagina corrente&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Insert new Radio Box to current page</source>
        <translation type="obsolete">Inserisce una nuova casella di scelta nella pagina corrente</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Insert List Box&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Insert new List Box to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Inserisci casella di riepilogo&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Inserisce una nuova casella di riepilogo nella pagina corrente&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Insert new List Box to current page</source>
        <translation type="obsolete">Inserisce una nuova casella di riepilogo nella pagina corrente</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Insert Combo Box&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Insert new Combo Box to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Inserisci casella combinata&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Inserisce una nuova casella combinata nella pagina corrente&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Insert new Combo Box to current page</source>
        <translation type="obsolete">Inserisce una nuova casella combinata nella pagina corrente</translation>
    </message>
    <message>
        <source>Main</source>
        <translation>Principale</translation>
    </message>
    <message>
        <source>Images</source>
        <translation>Immagini</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Export to Image&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Save the document to Image&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Esporta immagine&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Salva il documento immagine&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Export the document to Image</source>
        <translation type="obsolete">Esporta il documento come immagine</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Properties (Ctrl+D)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Open window with document properties&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Proprietà (Ctrl+D)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Apre una finestra di visualizzazione delle proprietà del documento&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Open window with document properties</source>
        <translation type="unfinished">Visualizza le proprietà del documento</translation>
    </message>
    <message>
        <source>Ctrl+D</source>
        <translation></translation>
    </message>
    <message>
        <source>Home page</source>
        <translation></translation>
    </message>
    <message>
        <source>&amp;About...</source>
        <translation type="vanished">Riferimenti...</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Undo (Ctrl+Z)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Undo the last action&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Annulla (Ctrl+Z)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Annulla l&apos;ultima operazione&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Ctrl+Z</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Button&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new Button to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Inserisci pulsante&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Inserisce un nuovo pulsante nella pagina corrente&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Add Button</source>
        <translation type="obsolete">Aggiunge un pulsante</translation>
    </message>
    <message>
        <source>Ctrl++</source>
        <translation></translation>
    </message>
    <message>
        <source>Ctrl+-</source>
        <translation></translation>
    </message>
    <message>
        <source>Contents</source>
        <translation>Contenuti</translation>
    </message>
    <message>
        <source>Highlight existing fields</source>
        <translation type="obsolete">Evidenzia i campi esistenti</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redo (Ctrl+Y)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Redo the previously undone action.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Ripeti (Ctrl+Y)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Ripristina l&apos;ultima operazione annullata&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Ctrl+Y</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cut (Ctrl+X)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cut the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Taglia (Ctrl+X)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Taglia gli oggetti selezionati e li memorizza negli appunti&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Ctrl+X</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copy (Ctrl+C)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copy the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copia (Ctrl+C)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copia gli oggetti selezionati e li memorizza negli appunti&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Ctrl+C</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Paste (Ctrl+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Paste the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Incolla (Ctrl+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Incolla gli oggetti memorizzati negli appunti&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Ctrl+V</source>
        <translation></translation>
    </message>
    <message>
        <source>Ctrl+A</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Document (Alt+1)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select and edit text, images, annotations, form fields ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Modifica documento (Alt+1)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Seleziona e modifica testo, immagini, annotazioni, formato campi...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Alt+1</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Link (Ctrl+L)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new link to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Inserisci collegamento (Ctrl+L)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Inserisce un nuovo collegamento nella pagina corrente&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Insert new Link to current page</source>
        <translation type="vanished">Inserisce un nuovo collegamento nella pagina corrente</translation>
    </message>
    <message>
        <source>Add Stamp</source>
        <translation type="obsolete">Aggiungi timbratura oraria</translation>
    </message>
    <message>
        <source>Suggestions...</source>
        <translation type="vanished">Suggerimenti...</translation>
    </message>
    <message>
        <source>Suggestions</source>
        <translation type="vanished">Suggerimenti</translation>
    </message>
    <message>
        <source>Select Text</source>
        <translation>Seleziona testo</translation>
    </message>
    <message>
        <source>Alt+3</source>
        <translation></translation>
    </message>
    <message>
        <source>Form Fields</source>
        <translation type="vanished">Campi modulo</translation>
    </message>
    <message>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <source>Open failed</source>
        <translation>Apri non riusciti</translation>
    </message>
    <message>
        <source>Empty recent files list</source>
        <translation>Svuota elenco file recenti</translation>
    </message>
    <message>
        <source>&quot;untitled&quot;</source>
        <translation type="obsolete">senza titolo</translation>
    </message>
    <message>
        <source>Error import from :
</source>
        <translation type="obsolete">Errore nell&apos;importare da:</translation>
    </message>
    <message>
        <source>Export completed</source>
        <translation>Esportazione completata</translation>
    </message>
    <message>
        <source>Save As Docx</source>
        <translation type="obsolete">Salva come docx</translation>
    </message>
    <message>
        <source>Save failed</source>
        <translation>Salvataggio non riuscito</translation>
    </message>
    <message>
        <source>Can&apos;t save to the file:</source>
        <translation>Impossibile salvare il file:</translation>
    </message>
    <message>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
Il file è di sola lettura o usato da altra applicazione</translation>
    </message>
    <message>
        <source>Postscript Name: </source>
        <translation type="obsolete">Nome postilla:</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation type="vanished">Apri immagine</translation>
    </message>
    <message>
        <source>Image Files (*.tif *.png *.jpg *.bmp)</source>
        <translation type="obsolete">File immagine (*.tif *.png *.jpg *.bmp)</translation>
    </message>
    <message>
        <source>ERORR Load Image !</source>
        <translation type="obsolete">ERRORE nel caricare l&apos;immagine!</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>Apri file</translation>
    </message>
    <message>
        <source>All Files (*.pdf *.xps);;PDF Files (*.pdf);;XPS Files (*.xps)</source>
        <translation>Tutti i file (*.pdf *.xps);;File PDF (*.pdf);;File XPS (*.xps)</translation>
    </message>
    <message>
        <source>This document does not contain any form fields.</source>
        <translation type="obsolete">Questo documento non contiene campi modulo.</translation>
    </message>
    <message>
        <source>Page :</source>
        <translation>Pagina:</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Sticky Note&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Click the page to add a note at that position&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Nota post-it&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cliccare sulla pagina per aggiungere una nota in quella posizione&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Highlight Text&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Evidenzia testo&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Strikeout Text&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Testo barrato&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Underline Text&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Testo sottolineato&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Document Properties</source>
        <translation type="obsolete">Proprietà del documento</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Trova</translation>
    </message>
    <message>
        <source>Find Next (F3)</source>
        <translation type="vanished">Trova successivo (F3)</translation>
    </message>
    <message>
        <source>Find Next</source>
        <translation>Trova successivo</translation>
    </message>
    <message>
        <source>Can&apos;t find :</source>
        <translation>Impossibile trovare:</translation>
    </message>
    <message>
        <source>New Version Is Available !
Do you want to Download Now?</source>
        <translation>È disponibile una nuova versione!
Vuoi scaricarla adesso?</translation>
    </message>
    <message>
        <source>Export to HTML</source>
        <translation type="vanished">Esporta in HTML</translation>
    </message>
    <message>
        <source>Close Without Saving</source>
        <translation>Chiudi senza salvare</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <source>Save As HTML</source>
        <translation type="vanished">Salva come HTML</translation>
    </message>
    <message>
        <source>Ctrl+W</source>
        <translation></translation>
    </message>
    <message>
        <source>Rotate Pages</source>
        <translation>Ruota pagine</translation>
    </message>
    <message>
        <source>Move Pages</source>
        <translation>Sposta le pagine</translation>
    </message>
    <message>
        <source>This operation has no effect </source>
        <translation type="vanished">Questa operazione non produce effetti</translation>
    </message>
    <message>
        <source>Add Formatted Text</source>
        <translation type="vanished">Aggiungi testo formattato</translation>
    </message>
    <message>
        <source>Alt+4</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Move pages.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Strumento mano (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Sposta le pagine&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for copying and pasting&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Seleziona testo (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Seleziona testo da copiare e incollare&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Edit Text</source>
        <translation>Modifica testo</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text Object(Alt+2)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Seleziona testo come oggetto (Alt+2)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Seleziona testo da modificare&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Document Info</source>
        <translation type="vanished">Informazioni documento</translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="vanished">Ricerche</translation>
    </message>
    <message>
        <source>    This document contains interactive form fields</source>
        <translation type="vanished">Questo documento contiene campi modulo interattivi</translation>
    </message>
    <message>
        <source>Object Inspector</source>
        <translation>Gestore oggetti</translation>
    </message>
    <message>
        <source>untitled</source>
        <translation>senza titolo</translation>
    </message>
    <message>
        <source>The unregistered version will insert a watermark</source>
        <translation>Verrà inserita una filigrana se la versione non è registrata</translation>
    </message>
    <message>
        <source>Align Objects</source>
        <translation>Allinea oggetti</translation>
    </message>
    <message>
        <source>Line</source>
        <translation>Linea</translation>
    </message>
    <message>
        <source>Add Line</source>
        <translation type="vanished">Aggiungi linea</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation>Rettangolo</translation>
    </message>
    <message>
        <source>Add Rectangle</source>
        <translation type="vanished">Aggiungi rettangolo</translation>
    </message>
    <message>
        <source>Ellipse</source>
        <translation>Ellisse</translation>
    </message>
    <message>
        <source>Add Ellipse</source>
        <translation type="vanished">Aggiungi ellisse</translation>
    </message>
    <message>
        <source>Polygon</source>
        <translation type="vanished">Poligono</translation>
    </message>
    <message>
        <source>Add Polygon</source>
        <translation type="vanished">Aggiungi poligono</translation>
    </message>
    <message>
        <source>Print Preview</source>
        <translation>Anteprima di stampa</translation>
    </message>
    <message>
        <source>Align Left</source>
        <translation>Allinea a sinistra</translation>
    </message>
    <message>
        <source>Align Right</source>
        <translation>Allinea a destra</translation>
    </message>
    <message>
        <source>Align Top</source>
        <translation>Allinea in alto</translation>
    </message>
    <message>
        <source>Align Bottom</source>
        <translation>Allinea in basso</translation>
    </message>
    <message>
        <source>
The may be read-only or used by another application.</source>
        <translation type="vanished">
Potrebbe essere di sola lettura o utilizzato da altra applicazione</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>Firma</translation>
    </message>
    <message>
        <source>Crop Pages</source>
        <translation>Ritaglia pagine</translation>
    </message>
    <message>
        <source>Font attributes</source>
        <translation type="vanished">Attributi dei caratteri</translation>
    </message>
    <message>
        <source>Font Attributes</source>
        <translation type="vanished">Attributi dei caratteri</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Famiglia caratteri&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cambia il tipo di carattere&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Colore carattere&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cambia il colore dei caratteri&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Font Italic</source>
        <translation type="vanished">Carattere corsivo</translation>
    </message>
    <message>
        <source>Font Bold</source>
        <translation type="vanished">Carattere grassetto</translation>
    </message>
    <message>
        <source>Do you want to open?</source>
        <translation type="obsolete">Vuoi aprire?</translation>
    </message>
    <message>
        <source>Set Fit to Page</source>
        <translation>Adatta alla pagina</translation>
    </message>
    <message>
        <source>Prev/Next</source>
        <translation>Precedente/Successivo</translation>
    </message>
    <message>
        <source>Edit Tools</source>
        <translation>Strumenti di modifica</translation>
    </message>
    <message>
        <source>Can&apos;t create temp file:
</source>
        <translation type="obsolete">Impossibile creare il file temporaneo:</translation>
    </message>
    <message>
        <source>Image Files (*.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation type="obsolete">File immagine (*.tif *.png *.jpg *.jpeg *.bmp)</translation>
    </message>
    <message>
        <source>A error occurred during the signature verification!</source>
        <translation>Si è verificato un errorre durante la verifica della firma!</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Paste (Ctrl+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Paste from the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Incolla (Ctrl+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Incolla gli oggetti memorizzati negli appunti&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Master PDF Editor</source>
        <translation></translation>
    </message>
    <message>
        <source>Forms</source>
        <translation>Moduli</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Riferimenti</translation>
    </message>
    <message>
        <source>Home</source>
        <translation></translation>
    </message>
    <message>
        <source>End</source>
        <translation></translation>
    </message>
    <message>
        <source>Reset Forms</source>
        <translation>Reimposta modulo</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation>Adatta pagina</translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation>Adatta larghezza</translation>
    </message>
    <message>
        <source>Ctrl+Q</source>
        <translation></translation>
    </message>
    <message>
        <source>Facing Pages</source>
        <translation>Pagine affiancate</translation>
    </message>
    <message>
        <source>Delete Pages</source>
        <translation>Elimina pagine</translation>
    </message>
    <message>
        <source>Edit Forms</source>
        <translation>Modifica Forms</translation>
    </message>
    <message>
        <source>Bring to Front</source>
        <translation>In primo piano</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Bring To Front&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Bring to Front selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Primo piano&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Porta l&apos;oggetto selezionato in primo piano&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Insert a Blank Pages</source>
        <translation type="vanished">Inserisci pagina vuota</translation>
    </message>
    <message>
        <source>Extract Pages...</source>
        <translation>Estrai pagine</translation>
    </message>
    <message>
        <source>Insert Pages...</source>
        <translation>Inserisci pagine</translation>
    </message>
    <message>
        <source>Pencil</source>
        <translation>Matita</translation>
    </message>
    <message>
        <source>PDF Files (*.pdf)</source>
        <translation>File PDF (*.pdf)</translation>
    </message>
    <message>
        <source>Open a PDF file</source>
        <translation>Apre un file PDF o XPS esistente</translation>
    </message>
    <message>
        <source>PgUp</source>
        <translation></translation>
    </message>
    <message>
        <source>PgDown</source>
        <translation></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <source>Ctrl+L</source>
        <translation></translation>
    </message>
    <message>
        <source>Ctrl+E</source>
        <translation></translation>
    </message>
    <message>
        <source>Saving in XPS is temporarily not supported.
Choose PDF file name for saving.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+R</source>
        <translation></translation>
    </message>
    <message>
        <source>Open Object Inspector</source>
        <translation>Gestore oggetti</translation>
    </message>
    <message>
        <source>Ctrl+K</source>
        <translation></translation>
    </message>
    <message>
        <source>Alt+5</source>
        <translation></translation>
    </message>
    <message>
        <source>Ctrl+H</source>
        <translation></translation>
    </message>
    <message>
        <source>Ctrl+Shift+P</source>
        <translation></translation>
    </message>
    <message>
        <source>Ctrl+F11</source>
        <translation></translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <translation></translation>
    </message>
    <message>
        <source>Insert Blank Pages</source>
        <translation>Inserisci pagina vuota</translation>
    </message>
    <message>
        <source>Ctrl+Shift++</source>
        <translation></translation>
    </message>
    <message>
        <source>Ctrl+Shift+-</source>
        <translation></translation>
    </message>
    <message>
        <source>Ctrl+Shift+L</source>
        <translation></translation>
    </message>
    <message>
        <source>Alt+2</source>
        <translation></translation>
    </message>
    <message>
        <source>Rotate 90 degrees Clockwise</source>
        <translation>Ruota di 90 gradi in senso orario</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation>Ruota di 90 gradi in senso antiorario</translation>
    </message>
    <message>
        <source>FDF</source>
        <translation type="vanished">FDF</translation>
    </message>
    <message>
        <source>Export Data...</source>
        <translation type="vanished">Esporta dati...</translation>
    </message>
    <message>
        <source>Import Data...</source>
        <translation type="vanished">Importa dati...</translation>
    </message>
    <message>
        <source>FDF Files (*.fdf)</source>
        <translation>File FDF (*.fdf)</translation>
    </message>
    <message>
        <source>Export Form Data...</source>
        <translation type="unfinished">Esporta dati...</translation>
    </message>
    <message>
        <source>Import Form Data...</source>
        <translation type="unfinished">Importa dati...</translation>
    </message>
    <message>
        <source>Export Comments Data...</source>
        <translation type="unfinished">Esporta dati...</translation>
    </message>
    <message>
        <source>Import Comments Data...</source>
        <translation type="unfinished">Importa dati...</translation>
    </message>
    <message>
        <source>Select text for copying and pasting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Save As PDF(Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Save the document with a new name&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Salva come PDF (Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Salva il documento con un nuovo nome&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Print the document</source>
        <translation type="unfinished">Documento in stampa</translation>
    </message>
    <message>
        <source>Select and edit text, images, annotations, form fields ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select text for editing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete the currently selected object(s)</source>
        <translation type="unfinished">Elimina gli oggetti attualmente selezionati</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;New (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Create a new blank PDF&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Nuovo PDF (Ctrl+N)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Crea nuovo file PDF vuoto&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Cut the selection Object(s) and place on the Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy the selection Object(s) and place on the Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paste from the Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Undo the last action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Redo the previously undone action.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send to Back selected object.</source>
        <translation>Usa come sfondo </translation>
    </message>
    <message>
        <source>Bring to Front selected object.</source>
        <translation>Porta in primo piano</translation>
    </message>
    <message>
        <source>Click the page to add a note at that position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert new link to current page</source>
        <translation type="unfinished">Inserisce un nuovo collegamento nella pagina corrente</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text (Alt+5)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for copying and pasting&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Seleziona testo (Alt+5)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Seleziona testo da copiare e incollare&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool (Alt+4)&lt;/span&gt;&lt;/p&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Strumento mano (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Sposta le pagine&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Ctrl+Shift+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+I</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Optimized As...</source>
        <translation>PDF ottimizzato</translation>
    </message>
    <message>
        <source>Ctrl+Alt+S</source>
        <translation></translation>
    </message>
    <message>
        <source>Chacters</source>
        <translation>Caratteri</translation>
    </message>
    <message>
        <source>Font type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font Embedded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Width</source>
        <translation type="unfinished">Larghezza</translation>
    </message>
    <message>
        <source>Height</source>
        <translation type="unfinished">Altezza</translation>
    </message>
    <message>
        <source>Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Path</source>
        <translation type="unfinished">Percorso</translation>
    </message>
    <message>
        <source>Shading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page</source>
        <translation type="unfinished">Pagina</translation>
    </message>
    <message>
        <source>Selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font Not Embedded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Form (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select form and annotations for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Modifica Forms (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Seleziona e modifica annotazioni, formato campi...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Text Object(Alt+2)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Seleziona testo come oggetto (Alt+2)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Seleziona testo da modificare&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use the hand tool for moving pages, open links and selecting text.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Strumento mano (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Sposta le pagine&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Ctrl+0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+6</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MovePagesDialog</name>
    <message>
        <source>Move Pages</source>
        <translation type="unfinished">Sposta le pagine</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="unfinished">Seleziona intervallo pagine</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="unfinished">Pagine</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished">Esempio: 1,6-8,12</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="unfinished">Pagina corrente</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="unfinished">a:</translation>
    </message>
    <message>
        <source>Destination</source>
        <translation type="unfinished">Destinazione</translation>
    </message>
    <message>
        <source>To:</source>
        <translation type="unfinished">A:</translation>
    </message>
    <message>
        <source>Page</source>
        <translation type="unfinished">Pagina</translation>
    </message>
    <message>
        <source>First</source>
        <translation type="unfinished">Prima</translation>
    </message>
    <message>
        <source>Last</source>
        <translation type="unfinished">Ultima</translation>
    </message>
</context>
<context>
    <name>MovePagesDlg</name>
    <message>
        <source>Move Pages</source>
        <translation type="vanished">Sposta le pagine</translation>
    </message>
    <message>
        <source>Destination</source>
        <translation type="vanished">Destinazione</translation>
    </message>
    <message>
        <source>To:</source>
        <translation type="vanished">A:</translation>
    </message>
    <message>
        <source>Page</source>
        <translation type="vanished">Pagina</translation>
    </message>
    <message>
        <source>First</source>
        <translation type="vanished">Prima</translation>
    </message>
    <message>
        <source>Last</source>
        <translation type="vanished">Ultima</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Seleziona intervallo pagine</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Pagina corrente</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">a:</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Pagine selezionate</translation>
    </message>
</context>
<context>
    <name>NewPageDialog</name>
    <message>
        <source>Page Size</source>
        <translation type="unfinished">Dimensioni pagina</translation>
    </message>
    <message>
        <source>Width</source>
        <translation type="unfinished">Larghezza</translation>
    </message>
    <message>
        <source>Height</source>
        <translation type="unfinished">Altezza</translation>
    </message>
    <message>
        <source>A0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom page size</source>
        <translation type="unfinished">Formato pagina personalizzato</translation>
    </message>
    <message>
        <source>Portrait</source>
        <translation type="unfinished">Portaritratti</translation>
    </message>
    <message>
        <source>Landscape</source>
        <translation type="unfinished">Panorame</translation>
    </message>
    <message>
        <source>Contents Size</source>
        <translation type="unfinished">Adatta al contenuto</translation>
    </message>
    <message>
        <source>Left margin</source>
        <translation>Margine sinistro</translation>
    </message>
    <message>
        <source>Top margin</source>
        <translation>Margine superiore</translation>
    </message>
    <message>
        <source>Right margin</source>
        <translation>Margine destro</translation>
    </message>
    <message>
        <source>Bottom margin</source>
        <translation>Margine inferiore</translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="unfinished">Posizione</translation>
    </message>
    <message>
        <source>Before current page</source>
        <translation type="unfinished">Prima della pagina corrente</translation>
    </message>
    <message>
        <source>After current page</source>
        <translation type="unfinished">Dopo la pagina corrente</translation>
    </message>
    <message>
        <source>After last page</source>
        <translation type="unfinished">Dopo l&apos;ultima pagina</translation>
    </message>
    <message>
        <source>Before first page</source>
        <translation type="unfinished">Come prima pagina</translation>
    </message>
    <message>
        <source>Number of pages</source>
        <translation type="unfinished">Numero di pagine</translation>
    </message>
    <message>
        <source>Page(s)</source>
        <translation type="unfinished">Pagina(e)</translation>
    </message>
    <message>
        <source>Create</source>
        <translation type="unfinished">Crea</translation>
    </message>
    <message>
        <source>Letter</source>
        <translation type="unfinished">Lettera</translation>
    </message>
    <message>
        <source>Tabloid</source>
        <translation type="unfinished">Tabloid</translation>
    </message>
    <message>
        <source>B0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Statement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Executive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Folio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quarto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ANSI C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ANSI D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ANSI E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ANSI F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>points</source>
        <translation type="unfinished">punti</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="unfinished">pollici</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="unfinished">millimetri</translation>
    </message>
    <message>
        <source> px</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Units</source>
        <translation type="unfinished">Unità</translation>
    </message>
</context>
<context>
    <name>ObjectInspector</name>
    <message>
        <source>No Properties
There is no object selections.</source>
        <translation>Nessuna proprietà.
Nessun oggetto selezionato.</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Testo</translation>
    </message>
    <message>
        <source>Property</source>
        <translation>Proprietà</translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished">Valore</translation>
    </message>
    <message>
        <source>Left</source>
        <translation type="unfinished">Sinistra</translation>
    </message>
    <message>
        <source>Top</source>
        <translation type="unfinished">In cima</translation>
    </message>
    <message>
        <source>Font Family</source>
        <translation type="unfinished">Famiglia caratteri</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Dimensioni</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <source>Fill Color</source>
        <translation>Colore pieno</translation>
    </message>
    <message>
        <source>Stroke Color</source>
        <translation type="unfinished">Colore del tratto</translation>
    </message>
    <message>
        <source>Line width</source>
        <translation type="obsolete">Spessore linea</translation>
    </message>
    <message>
        <source>Opacity</source>
        <translation>Opacità</translation>
    </message>
    <message>
        <source>Clipping path</source>
        <translation type="obsolete">Percorso del ritaglio</translation>
    </message>
    <message>
        <source>Image</source>
        <translation>Immagine</translation>
    </message>
    <message>
        <source>Width</source>
        <translation>Larghezza</translation>
    </message>
    <message>
        <source>Height</source>
        <translation>Altezza</translation>
    </message>
    <message>
        <source>Path</source>
        <translation type="unfinished">Percorso</translation>
    </message>
    <message>
        <source>Full Color</source>
        <translation type="unfinished">Colore pieno</translation>
    </message>
    <message>
        <source>Form Field</source>
        <translation type="unfinished">Campo modulo</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished">Nome</translation>
    </message>
    <message>
        <source>Export Item</source>
        <translation type="obsolete">Esporta voce</translation>
    </message>
    <message>
        <source>Action type</source>
        <translation type="obsolete">Tipo azione</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">Grassetto</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">Corsivo</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Famiglia caratteri&lt;/span&gt;&lt;/p&gt;&lt;p&gt;cambia il tipo di carattere&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Text Mode&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the text mode&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Modalità testo&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cambia la modalità testo&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Colore caratteri&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cambia il colore dei caratteri&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font Stroke color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font stroke color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Colore tratto caratteri&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cambia il colore del tratto dei caratteri&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished">Rimuovi</translation>
    </message>
    <message>
        <source>Goto a Page View</source>
        <translation>Vai a pagina...</translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation type="unfinished">Apri/Esegui un file</translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation type="unfinished">Apri un collegamento web</translation>
    </message>
    <message>
        <source>Reset form</source>
        <translation type="unfinished">Reimposta modello</translation>
    </message>
    <message>
        <source>Show/Hide fields</source>
        <translation type="unfinished">Mostra/Nascondi campi</translation>
    </message>
    <message>
        <source>Submit a form</source>
        <translation type="unfinished">Conferma un modello</translation>
    </message>
    <message>
        <source>Run a JavaScript</source>
        <translation type="unfinished">Esegui un JavaScript</translation>
    </message>
    <message>
        <source>CheckBox Properties</source>
        <translation type="obsolete">Proprietà casella di controllo</translation>
    </message>
    <message>
        <source>Link Properties</source>
        <translation type="obsolete">Proprietà collegamento</translation>
    </message>
    <message>
        <source>RadioButton Properties</source>
        <translation type="obsolete">Proprietà casella di scelta</translation>
    </message>
    <message>
        <source>TextField Properties</source>
        <translation type="obsolete">Proprietà casella di testo</translation>
    </message>
    <message>
        <source>ListBox Properties</source>
        <translation type="obsolete">Proprietà casella elenco</translation>
    </message>
    <message>
        <source>PushButton Properties</source>
        <translation type="obsolete">Proprietà pulsante</translation>
    </message>
    <message>
        <source>ComboBox Properties</source>
        <translation type="obsolete">Proprietà casella combinata</translation>
    </message>
    <message>
        <source>Signature Properties</source>
        <translation type="obsolete">Proprietà firma</translation>
    </message>
    <message>
        <source>Full Opacity</source>
        <translation type="obsolete">Completamente opaco</translation>
    </message>
    <message>
        <source>Stroke Opacity</source>
        <translation type="obsolete">Opacità del tratto</translation>
    </message>
    <message>
        <source>Add an Action</source>
        <translation type="unfinished">Aggiungi azione</translation>
    </message>
    <message>
        <source>Trigger</source>
        <translation type="unfinished">Azione</translation>
    </message>
    <message>
        <source>Mouse Up</source>
        <translation type="unfinished">Mouse su</translation>
    </message>
    <message>
        <source>Mouse Down</source>
        <translation type="unfinished">Mouse giù</translation>
    </message>
    <message>
        <source>Mouse Enter</source>
        <translation type="unfinished">Inserimento mouse</translation>
    </message>
    <message>
        <source>Mouse Exit</source>
        <translation type="unfinished">Uscita mouse</translation>
    </message>
    <message>
        <source>On Receive Focus</source>
        <translation type="unfinished">Attivando</translation>
    </message>
    <message>
        <source>On Lose Focus</source>
        <translation type="unfinished">Disattivando</translation>
    </message>
    <message>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="unfinished">Aggiungi</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished">Elimina</translation>
    </message>
    <message>
        <source>Up Label</source>
        <translation type="unfinished">Etichetta sopra</translation>
    </message>
    <message>
        <source>Behavior</source>
        <translation type="unfinished">Comportamento</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished">Nessuno</translation>
    </message>
    <message>
        <source>Push</source>
        <translation type="unfinished">Premi</translation>
    </message>
    <message>
        <source>Outline</source>
        <translation type="unfinished">Cornice</translation>
    </message>
    <message>
        <source>Invert</source>
        <translation type="unfinished">Invertito</translation>
    </message>
    <message>
        <source>Down Label</source>
        <translation type="unfinished">Etichetta sotto</translation>
    </message>
    <message>
        <source>RollOver Label</source>
        <translation type="unfinished">Etichetta arrotolata</translation>
    </message>
    <message>
        <source>Item</source>
        <translation type="unfinished">Voce</translation>
    </message>
    <message>
        <source>Export Value</source>
        <translation type="unfinished">Esporta valore</translation>
    </message>
    <message>
        <source>Up</source>
        <translation type="unfinished">Su</translation>
    </message>
    <message>
        <source>Down</source>
        <translation type="unfinished">Giù</translation>
    </message>
    <message>
        <source>Sort Items</source>
        <translation type="unfinished">Disposizione voci</translation>
    </message>
    <message>
        <source>Commit selected value immediately</source>
        <translation type="unfinished">Accetta immediatamente il valore selezionato</translation>
    </message>
    <message>
        <source>Multiple selection</source>
        <translation type="unfinished">Selezione multipla</translation>
    </message>
    <message>
        <source>Allow user to enter custom text</source>
        <translation type="unfinished">Consenti l&apos;inserimento di testo personalizzato</translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="unfinished">Password</translation>
    </message>
    <message>
        <source>Scrollable</source>
        <translation type="unfinished">Scorrevole</translation>
    </message>
    <message>
        <source>Check spelling</source>
        <translation type="unfinished">Controllo ortografico</translation>
    </message>
    <message>
        <source>Limit to</source>
        <translation type="unfinished">Limita a</translation>
    </message>
    <message>
        <source>chars</source>
        <translation type="unfinished">caratteri</translation>
    </message>
    <message>
        <source>Split into</source>
        <translation type="unfinished">Suddividi in</translation>
    </message>
    <message>
        <source>Allow Rich Text formatting</source>
        <translation type="unfinished">Consenti formattazione Rich Text</translation>
    </message>
    <message>
        <source>Multi-line</source>
        <translation type="unfinished">Multi-linea</translation>
    </message>
    <message>
        <source>cells</source>
        <translation type="unfinished">celle</translation>
    </message>
    <message>
        <source>Center</source>
        <translation type="unfinished">Al centro</translation>
    </message>
    <message>
        <source>Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default Value</source>
        <translation type="unfinished">Valore predefinito</translation>
    </message>
    <message>
        <source>Alignment</source>
        <translation type="unfinished">Allineamento</translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="unfinished">Stile</translation>
    </message>
    <message>
        <source>Check</source>
        <translation type="unfinished">Verifica</translation>
    </message>
    <message>
        <source>Circle</source>
        <translation type="unfinished">Cerchio</translation>
    </message>
    <message>
        <source>Cross</source>
        <translation type="unfinished">Croce</translation>
    </message>
    <message>
        <source>Diamond</source>
        <translation type="unfinished">Diamante</translation>
    </message>
    <message>
        <source>Square</source>
        <translation type="unfinished">Quadrato</translation>
    </message>
    <message>
        <source>Star</source>
        <translation type="unfinished">Stella</translation>
    </message>
    <message>
        <source>Checked by Default</source>
        <translation type="unfinished">Verifica per impostazione predifinita</translation>
    </message>
    <message>
        <source>Line Thickness</source>
        <translation type="unfinished">Spessore</translation>
    </message>
    <message>
        <source>Border Color</source>
        <translation type="unfinished">Colore bordi</translation>
    </message>
    <message>
        <source>Line Style</source>
        <translation type="unfinished">Stile linea</translation>
    </message>
    <message>
        <source>Solid</source>
        <translation type="unfinished">Uniforme</translation>
    </message>
    <message>
        <source>Dashed</source>
        <translation type="unfinished">Tratteggiato</translation>
    </message>
    <message>
        <source>Underline</source>
        <translation type="unfinished">Sottolineato</translation>
    </message>
    <message>
        <source>Highlight</source>
        <translation type="unfinished">Evidenziato</translation>
    </message>
    <message>
        <source>OutLine</source>
        <translation type="unfinished">Bordato</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Signature.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;No available options&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Firma.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Nessuna opzione disponibile&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Format</source>
        <translation type="unfinished">Formato</translation>
    </message>
    <message>
        <source>Format category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Percentage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Special</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1,234.56</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1234.56</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1.234,56</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1234,56</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Currency Symbol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dollar ($)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Euro (€)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pound (£)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yen (¥)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ruble (Руб)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show parentheses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Decimal Places</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Separation Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use red text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Special Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Format Script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>KeyStroke Script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Validate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Validation Script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Calculate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Calculation Script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Full text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stroke Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Full and Stroke</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invisible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Character spacing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Word spacing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Coordinates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Absolute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Relative</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font</source>
        <translation type="unfinished">Carattere</translation>
    </message>
    <message>
        <source>Matrix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cliping Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>General</source>
        <translation type="unfinished">Generale</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type="unfinished">Aspetto</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished">Impostazioni</translation>
    </message>
    <message>
        <source>Full</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stroke</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="unfinished">Colore</translation>
    </message>
    <message>
        <source>Borders and Colors</source>
        <translation type="unfinished">Bordi e Colori</translation>
    </message>
    <message>
        <source>Thin</source>
        <translation type="unfinished">Sottile</translation>
    </message>
    <message>
        <source>Medium</source>
        <translation type="unfinished">Medio</translation>
    </message>
    <message>
        <source>Thick</source>
        <translation type="unfinished">Spesso</translation>
    </message>
    <message>
        <source>Beveled</source>
        <translation type="unfinished">Smussato</translation>
    </message>
    <message>
        <source>Inset</source>
        <translation type="unfinished">Inserto</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ToolTip</source>
        <translation type="unfinished">Descrizione</translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation type="unfinished">Orientamento</translation>
    </message>
    <message>
        <source>0 Degrees</source>
        <translation type="unfinished">0 gradi</translation>
    </message>
    <message>
        <source>90 Degrees</source>
        <translation type="unfinished">90 gradi</translation>
    </message>
    <message>
        <source>180 Degrees</source>
        <translation type="unfinished">180 gradi</translation>
    </message>
    <message>
        <source>270 Degrees</source>
        <translation type="unfinished">270 gradi</translation>
    </message>
    <message>
        <source>Read Only</source>
        <translation type="unfinished">Sola lettura</translation>
    </message>
    <message>
        <source>Visible</source>
        <translation type="unfinished">Visibile</translation>
    </message>
    <message>
        <source>Hidden</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Visible but doesn&apos;t print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hidden but printable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Required</source>
        <translation type="unfinished">Necessario</translation>
    </message>
    <message>
        <source>Locked</source>
        <translation type="unfinished">Bloccato</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the fill color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font Stroke color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the stroke color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subject</source>
        <translation type="unfinished">Soggetto</translation>
    </message>
    <message>
        <source>Author</source>
        <translation type="unfinished">Autore</translation>
    </message>
    <message>
        <source>Maintain aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zip Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zip Code+4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phone Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Social Security Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check Mark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="unfinished">Guida</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Paragraph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paragraph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right Pointer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Up Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Up Left Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Graph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paper Clip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attachment</source>
        <translation type="unfinished">Allegati</translation>
    </message>
    <message>
        <source>Tag</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PageLayoutDialog</name>
    <message>
        <source>Page Layout</source>
        <translation>Layout pagina</translation>
    </message>
    <message>
        <source>Contents Size</source>
        <translation>Dimensioni del contenuto</translation>
    </message>
    <message>
        <source>Left margin</source>
        <translation>Margine sinistro</translation>
    </message>
    <message>
        <source>Top margin</source>
        <translation>Margine superiore</translation>
    </message>
    <message>
        <source>Right margin</source>
        <translation>Margine destro</translation>
    </message>
    <message>
        <source>Bottom margin</source>
        <translation>Margine inferiore</translation>
    </message>
    <message>
        <source>Page Size</source>
        <translation>Dimensioni pagina</translation>
    </message>
    <message>
        <source>Width</source>
        <translation>Larghezza</translation>
    </message>
    <message>
        <source>Height</source>
        <translation>Altezza</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>Seleziona intervallo pagine</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation>Pagine selezionate</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>Pagina corrente</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation>Tutte le pagine</translation>
    </message>
    <message>
        <source>to:</source>
        <translation>a:</translation>
    </message>
    <message>
        <source> px</source>
        <translation></translation>
    </message>
    <message>
        <source>Units</source>
        <translation>Unità</translation>
    </message>
    <message>
        <source>points</source>
        <translation>punti</translation>
    </message>
    <message>
        <source>inch</source>
        <translation>pollici</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation>millimetri</translation>
    </message>
    <message>
        <source> in</source>
        <translation></translation>
    </message>
    <message>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Even and Odd pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PasswordOpenDialog</name>
    <message>
        <source>Password:</source>
        <translation>Password:</translation>
    </message>
    <message>
        <source>The file is protected. Please enter a Document Open Password</source>
        <translation>File protetto da password. Inserire una password per aprire questo Documento</translation>
    </message>
    <message>
        <source>Enter Password</source>
        <translation>Inserire password</translation>
    </message>
</context>
<context>
    <name>PlainTextEdit</name>
    <message>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation>Questi caratteri non sono disponibili.
Riprovare scegliendo un altro tipo di carattere.</translation>
    </message>
</context>
<context>
    <name>PrintDialog</name>
    <message>
        <source>Print Preview</source>
        <translation type="unfinished">Anteprima di stampa</translation>
    </message>
    <message>
        <source>Printer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="unfinished">Proprietà</translation>
    </message>
    <message>
        <source>Antialiasing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Center</source>
        <translation type="unfinished">Al centro</translation>
    </message>
    <message>
        <source>Print as Grayscale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aspect Ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ignore aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keep aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keep aspect ratio by expanding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation type="unfinished">Orientamento</translation>
    </message>
    <message>
        <source>Portrait</source>
        <translation type="unfinished">Portaritratti</translation>
    </message>
    <message>
        <source>Landscape</source>
        <translation type="unfinished">Panorame</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="unfinished">Seleziona intervallo pagine</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="unfinished">Tutte le pagine</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="unfinished">Pagina corrente</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="unfinished">a:</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Collate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="unfinished">Stampa</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page</source>
        <translation type="unfinished">Pagina</translation>
    </message>
    <message>
        <source>of:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>of </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>72</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>150</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>300</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>600</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>900</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1200</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DPI</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QAttachment</name>
    <message>
        <source>Size</source>
        <translation>Dimensione</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descrizione</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation>Salva con nome...</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation type="unfinished">menu Inserisci</translation>
    </message>
    <message>
        <source>Location</source>
        <translation type="unfinished">Posizione</translation>
    </message>
    <message>
        <source>Page </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attachment Tab</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QBookmarksTree</name>
    <message>
        <source>Add Bookmark</source>
        <translation>Aggiungi segnalibro</translation>
    </message>
    <message>
        <source>Delete Bookmark</source>
        <translation>Cancella segnalibro</translation>
    </message>
    <message>
        <source>Bookmark Properties</source>
        <translation>Proprietà segnalibro</translation>
    </message>
    <message>
        <source>Set Destination</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QDocTab</name>
    <message>
        <source>untitled</source>
        <translation type="unfinished">senza titolo</translation>
    </message>
    <message>
        <source>The clipboard doesn&apos;t contain an data</source>
        <translation type="unfinished">Nessun dato negli appunti</translation>
    </message>
</context>
<context>
    <name>QHTMLEditor</name>
    <message>
        <source>File</source>
        <translation type="obsolete">File</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete">Modifica </translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Annulla l&apos;ultima operazione</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">Ripristina l&apos;ultima operazione annullata</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">Copia</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">Incolla </translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">Grassetto</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">Corsivo</translation>
    </message>
</context>
<context>
    <name>QHTMLFormEditor</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Modulo</translation>
    </message>
</context>
<context>
    <name>QHtmlFormEditor</name>
    <message>
        <source>File Actions</source>
        <translation type="obsolete">Azioni file</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="vanished">Applica</translation>
    </message>
    <message>
        <source>Open...</source>
        <translation type="vanished">Apri...</translation>
    </message>
    <message>
        <source>Save &amp;As...</source>
        <translation type="obsolete">S&amp;alva con nome...</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="vanished">Annulla</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="vanished">Ripeti</translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation type="obsolete">&amp;Taglia</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="vanished">Copia</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="vanished">Incolla </translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">Grassetto</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="vanished">Corsivo</translation>
    </message>
    <message>
        <source>Underline</source>
        <translation type="vanished">Sottolineato</translation>
    </message>
    <message>
        <source>Left</source>
        <translation type="vanished">Sinistra</translation>
    </message>
    <message>
        <source>C&amp;enter</source>
        <translation type="obsolete">C&amp;entrato</translation>
    </message>
    <message>
        <source>Right</source>
        <translation type="vanished">Destra</translation>
    </message>
    <message>
        <source>Justify</source>
        <translation type="vanished">Giustificato</translation>
    </message>
    <message>
        <source>Color...</source>
        <translation type="obsolete">Colore...</translation>
    </message>
    <message>
        <source>Format Actions</source>
        <translation type="obsolete">Definisci azioni</translation>
    </message>
    <message>
        <source>Bullet List (Disc)</source>
        <translation type="obsolete">Elenco puntato (punto)</translation>
    </message>
    <message>
        <source>Bullet List (Circle)</source>
        <translation type="obsolete">Elenco puntato (cerchio)</translation>
    </message>
    <message>
        <source>Bullet List (Square)</source>
        <translation type="obsolete">Elenco puntato (quadrato)</translation>
    </message>
    <message>
        <source>Ordered List (Decimal)</source>
        <translation type="obsolete">Elenco ordinato (n.ri decimali)</translation>
    </message>
    <message>
        <source>Ordered List (Alpha lower)</source>
        <translation type="obsolete">Elenco ordinato (alfabeto dal basso)</translation>
    </message>
    <message>
        <source>Ordered List (Alpha upper)</source>
        <translation type="obsolete">Elenco ordinato (alfabeto dall&apos;alto)</translation>
    </message>
    <message>
        <source>Ordered List (Roman lower)</source>
        <translation type="obsolete">Elenco ordinato (n.ri romani dall&apos;alto)</translation>
    </message>
    <message>
        <source>Ordered List (Roman upper)</source>
        <translation type="obsolete">Elenco ordinato (n.ri romani dall&apos;alto)</translation>
    </message>
    <message>
        <source>View current PDF</source>
        <translation type="vanished">Visualizza PDF corrente</translation>
    </message>
    <message>
        <source>Open File...</source>
        <translation type="vanished">Apri file...</translation>
    </message>
    <message>
        <source>HTML-Files (*.htm *.html);;All Files (*)</source>
        <translation type="obsolete">File HTML (*.htm *.html);;Tutti i file (*)</translation>
    </message>
    <message>
        <source>The document has been modified.
Do you want to apply your changes?</source>
        <translation type="obsolete">Il documento è stato modificato.
Vuoi applicare le modifiche?</translation>
    </message>
    <message>
        <source>Save as...</source>
        <translation type="vanished">Salva come...</translation>
    </message>
</context>
<context>
    <name>QHttp</name>
    <message>
        <source>HTTPS connection requested but SSL support not compiled in</source>
        <translation type="unfinished">Connessione HTTPS richiesta ma il supporto SSL non è compilato</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="unfinished">Errore sconosciuto</translation>
    </message>
    <message>
        <source>Request aborted</source>
        <translation type="unfinished">Richiesta interrotta</translation>
    </message>
    <message>
        <source>No server set to connect to</source>
        <translation type="unfinished">Nessun server impostato per la connessione</translation>
    </message>
    <message>
        <source>Wrong content length</source>
        <translation type="unfinished">Lunghezza del contenuto errato</translation>
    </message>
    <message>
        <source>Server closed connection unexpectedly</source>
        <translation type="unfinished">Il server ha chiuso la connessione inaspettatamente</translation>
    </message>
    <message>
        <source>Connection refused (or timed out)</source>
        <translation type="unfinished">Connessione rifiutata (o tempo limite superato)</translation>
    </message>
    <message>
        <source>Host %1 not found</source>
        <translation type="unfinished">Host %1 non trovato</translation>
    </message>
    <message>
        <source>HTTP request failed</source>
        <translation type="unfinished">Richiesta HTTP non riuscita</translation>
    </message>
    <message>
        <source>Invalid HTTP response header</source>
        <translation type="unfinished">Intestazione risposta HTTP non valida</translation>
    </message>
    <message>
        <source>Unknown authentication method</source>
        <translation type="unfinished">Metodo di autenticazione sconosciuto</translation>
    </message>
    <message>
        <source>Proxy authentication required</source>
        <translation type="unfinished">Richiesta autenticazione proxy</translation>
    </message>
    <message>
        <source>Authentication required</source>
        <translation type="unfinished">Richiesta autenticazione</translation>
    </message>
    <message>
        <source>Invalid HTTP chunked body</source>
        <translation type="unfinished">Parte del corpo HTTP non valido</translation>
    </message>
    <message>
        <source>Error writing response to device</source>
        <translation type="unfinished">Errore in scrittura della risposta al dispositivo</translation>
    </message>
</context>
<context>
    <name>QPDFDocument</name>
    <message>
        <source>Error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There was a problem with your form submission.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your form was successfully submitted!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QPDFPlainTextEdit</name>
    <message>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation type="obsolete">Questi caratteri non sono disponibili.
Riprovare scegliendo un altro tipo di carattere.</translation>
    </message>
</context>
<context>
    <name>QTabPage</name>
    <message>
        <source>Pages</source>
        <translation type="unfinished">Pagine</translation>
    </message>
    <message>
        <source>Enlarge Page Thumbnails</source>
        <translation type="unfinished">Ingrandisci miniature</translation>
    </message>
    <message>
        <source>Reduce Page Thumbnails</source>
        <translation type="unfinished">Riduci miniature</translation>
    </message>
    <message>
        <source>Bookmarks</source>
        <translation type="unfinished">Segnalibri</translation>
    </message>
    <message>
        <source>Attachment</source>
        <translation type="unfinished">Allegati</translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Object Inspector</source>
        <translation type="unfinished">Gestore oggetti</translation>
    </message>
    <message>
        <source>This document contains interactive form fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Highlight Fields</source>
        <translation type="unfinished">Evidenzia tutti</translation>
    </message>
    <message>
        <source>This document is protected. You do not have permissions to edit this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There was an error printing the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert a blank page </source>
        <translation type="obsolete">Inserisci pagina vuota</translation>
    </message>
    <message>
        <source>Do you want to open?</source>
        <translation type="unfinished">Vuoi aprire?</translation>
    </message>
    <message>
        <source>Are you sure you want to set the destination of the selected bookmark to the current location?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>untitled</source>
        <translation type="unfinished">senza titolo</translation>
    </message>
    <message>
        <source>Delete Pages</source>
        <translation type="unfinished">Elimina pagine</translation>
    </message>
    <message>
        <source>Insert Blank Pages</source>
        <translation>Inserisci pagina vuota</translation>
    </message>
</context>
<context>
    <name>QtColorComboBox</name>
    <message>
        <source>More...</source>
        <translation>Altro</translation>
    </message>
    <message>
        <source>User color %1</source>
        <translation>Usa colore %1</translation>
    </message>
    <message>
        <source>User Color 99</source>
        <translation>Colore utente 99</translation>
    </message>
    <message>
        <source>Black</source>
        <translation>Nero</translation>
    </message>
    <message>
        <source>White</source>
        <translation>Bianco</translation>
    </message>
    <message>
        <source>Red</source>
        <translation>Rosso</translation>
    </message>
    <message>
        <source>Dark red</source>
        <translation type="unfinished">Rosso scuro</translation>
    </message>
    <message>
        <source>Green</source>
        <translation>Verde</translation>
    </message>
    <message>
        <source>Dark green</source>
        <translation type="unfinished">Verde scuro</translation>
    </message>
    <message>
        <source>Blue</source>
        <translation>Blu</translation>
    </message>
    <message>
        <source>Dark blue</source>
        <translation type="unfinished">Blu scuro</translation>
    </message>
    <message>
        <source>Cyan</source>
        <translation type="unfinished">Ciano</translation>
    </message>
    <message>
        <source>Dark cyan</source>
        <translation type="unfinished">Ciano scuro</translation>
    </message>
    <message>
        <source>Magenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark magenta</source>
        <translation type="unfinished">Magenta scuro</translation>
    </message>
    <message>
        <source>Yellow</source>
        <translation>Giallo</translation>
    </message>
    <message>
        <source>Dark yellow</source>
        <translation type="unfinished">Giallo scuro</translation>
    </message>
    <message>
        <source>Gray</source>
        <translation>Grigio</translation>
    </message>
    <message>
        <source>Dark gray</source>
        <translation type="unfinished">Grigio scuro</translation>
    </message>
    <message>
        <source>Light gray</source>
        <translation type="unfinished">Grigio chiaro</translation>
    </message>
    <message>
        <source>Transparent</source>
        <translation type="unfinished">Trasparente</translation>
    </message>
</context>
<context>
    <name>RegDialog</name>
    <message>
        <source>Registration Info</source>
        <translation type="unfinished">Informazioni sulla registrazione</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished">Ok</translation>
    </message>
    <message>
        <source>After your order has been completed, 
you will automatically 
receive your Registration code via e-mail.</source>
        <translation type="unfinished">Dopo aver completato l&apos;ordine,
riceverete automaticamente
il codice di registrazione tramite e-mail.</translation>
    </message>
    <message>
        <source>Buy Online</source>
        <translation type="unfinished">Acquista online</translation>
    </message>
    <message>
        <source>Registration Code</source>
        <translation type="unfinished">Codice registrazione</translation>
    </message>
    <message>
        <source>Activate</source>
        <translation type="unfinished">Attiva</translation>
    </message>
    <message>
        <source>Offline Activation</source>
        <translation type="unfinished">Attivazione offline</translation>
    </message>
    <message>
        <source>Registered version</source>
        <translation type="unfinished">Versione registrata</translation>
    </message>
    <message>
        <source>If you want to register that license on another PC 
click &quot;Deactivate&quot; button. 

Then register it where you need.</source>
        <translation type="unfinished">Se si desidera registrare tale licenza su un altro PC
premere il pulsante &quot;Disattiva&quot;.

Quindi effettuare la registrazione dove occorre.</translation>
    </message>
    <message>
        <source>Deactivate</source>
        <translation type="unfinished">Disattiva</translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished">Indietro</translation>
    </message>
    <message>
        <source>Activation Code</source>
        <translation type="unfinished">Codice attivazione</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please send the ID key and Registration code to: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Once you receive your code enter it into &amp;quot;Activation code&amp;quot; field&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Inviare chiave ID e codice di registrazione a: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Una volta ricevuto il codice, inserirlo nel campo &amp;quot;Codice attivazione&amp;quot; &lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RotatePagesDlg</name>
    <message>
        <source>Rotate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="unfinished">Seleziona intervallo pagine</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="unfinished">Pagine</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished">Esempio: 1,6-8,12</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="unfinished">Pagina corrente</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="unfinished">a:</translation>
    </message>
    <message>
        <source>Direction</source>
        <translation type="unfinished">Direzione</translation>
    </message>
    <message>
        <source>Clockwise 90 degrees</source>
        <translation type="unfinished">Rotazione oraria di 90 gradi</translation>
    </message>
    <message>
        <source>180 degrees</source>
        <translation type="unfinished">180 gradi</translation>
    </message>
    <message>
        <source>Counterclockwise 90 degrees</source>
        <translation type="unfinished">Rotazione antioraria di 90 gradi</translation>
    </message>
</context>
<context>
    <name>SaveImageDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <source>Width</source>
        <translation>Larghezza</translation>
    </message>
    <message>
        <source>Height</source>
        <translation>Altezza</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Formato</translation>
    </message>
    <message>
        <source>File Name</source>
        <translation>Nome file</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation>Pagine selezionate</translation>
    </message>
    <message>
        <source>to:</source>
        <translation>a:</translation>
    </message>
    <message>
        <source>Export to Image</source>
        <translation>Esporta immagine</translation>
    </message>
    <message>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>Seleziona intervallo pagine</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation>Tutte le pagine</translation>
    </message>
    <message>
        <source>JPEG</source>
        <translation>JPEG</translation>
    </message>
    <message>
        <source>BMP</source>
        <translation></translation>
    </message>
    <message>
        <source>PNG</source>
        <translation></translation>
    </message>
    <message>
        <source>TIFF</source>
        <translation></translation>
    </message>
    <message>
        <source>JPEG Quality</source>
        <translation>Qualità JPEG</translation>
    </message>
    <message>
        <source>LZW</source>
        <translation></translation>
    </message>
    <message>
        <source>ZIP</source>
        <translation>ZIP</translation>
    </message>
    <message>
        <source>CCITT FAX 3</source>
        <translation></translation>
    </message>
    <message>
        <source>CCITT FAX 4</source>
        <translation></translation>
    </message>
    <message>
        <source>TIFF Compression</source>
        <translation type="unfinished">Compressione TIFF</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Dimensioni</translation>
    </message>
    <message>
        <source>DPI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="vanished">Salva</translation>
    </message>
    <message>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished">Impossibile salvare il file:</translation>
    </message>
    <message>
        <source>
The file may be read-only or used by another application.</source>
        <translation>Il file è di sola lettura o utilizzato da altra applicazione</translation>
    </message>
    <message>
        <source>Save As Image</source>
        <translation>Salva come immagine</translation>
    </message>
    <message>
        <source>All Files (*)</source>
        <translation>Tutti i file (*)</translation>
    </message>
    <message>
        <source>MultiPage</source>
        <translation>Pagine multiple</translation>
    </message>
    <message>
        <source>Save As TIFF Image</source>
        <translation>Salva come immagine TIFF</translation>
    </message>
    <message>
        <source>TIFF Files (*.tif *.tiff)</source>
        <translation>File TIFF (*.tif *.tiff)</translation>
    </message>
    <message>
        <source>Transparent</source>
        <translation>Trasparente</translation>
    </message>
    <message>
        <source>Antialiasing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SaveOptimizedDialog</name>
    <message>
        <source>Remove unused elements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flatten form fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color and Grayscale Images</source>
        <translation type="unfinished">Immagini a colori e scala di grigi</translation>
    </message>
    <message>
        <source>DPI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compression</source>
        <translation type="unfinished">Compressione</translation>
    </message>
    <message>
        <source>ZIP</source>
        <translation type="unfinished">ZIP</translation>
    </message>
    <message>
        <source>JPEG</source>
        <translation type="unfinished">JPEG</translation>
    </message>
    <message>
        <source>Lossless</source>
        <translation type="unfinished">Senza perdita</translation>
    </message>
    <message>
        <source>JPEG Quality</source>
        <translation type="unfinished">Qualità JPEG</translation>
    </message>
    <message>
        <source>Black and White Images</source>
        <translation type="unfinished">Immagini bianco e nero</translation>
    </message>
    <message>
        <source>CCITT Group 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>JBIG2</source>
        <translation type="unfinished">JBIG2</translation>
    </message>
    <message>
        <source>Save Optimized As...</source>
        <translation>PDF ottimizzato</translation>
    </message>
</context>
<context>
    <name>SearchFormTab</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Modulo</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Cerca</translation>
    </message>
    <message>
        <source>0 result</source>
        <translation>Nessun risultato</translation>
    </message>
    <message>
        <source>Case Sensitive</source>
        <translation>MAIUSCOLE/minuscole</translation>
    </message>
    <message>
        <source> result</source>
        <translation> risultato</translation>
    </message>
    <message>
        <source> results</source>
        <translation> risultati</translation>
    </message>
    <message>
        <source> result(s)</source>
        <translation> risultati</translation>
    </message>
    <message>
        <source>Include Comments</source>
        <translation>Includere Commenti</translation>
    </message>
</context>
<context>
    <name>SearchLineEdit</name>
    <message>
        <source>Case Sensitive</source>
        <translation type="unfinished">MAIUSCOLE/minuscole</translation>
    </message>
    <message>
        <source>Include Comments</source>
        <translation type="unfinished">Includere Commenti</translation>
    </message>
</context>
<context>
    <name>SecurityDialog</name>
    <message>
        <source>Security PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Required a password to open the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Document Open Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Permissions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Commenting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modifying document</source>
        <translation type="unfinished">Modifica documento</translation>
    </message>
    <message>
        <source>Content copying for accessibility</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Printing the document</source>
        <translation type="unfinished">Documento in stampa</translation>
    </message>
    <message>
        <source>Extract the content of the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print a high resolution version of the document</source>
        <translation type="unfinished">Stampa in alta risoluzione</translation>
    </message>
    <message>
        <source>Fill in existing form or signature fields</source>
        <translation type="unfinished">Compila un modulo</translation>
    </message>
    <message>
        <source>Permissions Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manage Pages and bookmarks</source>
        <translation type="unfinished">Gestione pagine e segnalibri</translation>
    </message>
    <message>
        <source>Document Open password does not match.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Document Permission password does not match.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SignatureDialog</name>
    <message>
        <source>Signature Properties</source>
        <translation>Proprietà firma</translation>
    </message>
    <message>
        <source>Signature is VALID</source>
        <translation>La firma è VALIDA</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>Dettagli</translation>
    </message>
    <message>
        <source>Signed by:</source>
        <translation>Firmato da:</translation>
    </message>
    <message>
        <source>Reason:</source>
        <translation>Motivo:</translation>
    </message>
    <message>
        <source>Date:</source>
        <translation>Data:</translation>
    </message>
    <message>
        <source>Location:</source>
        <translation>Posizione:</translation>
    </message>
    <message>
        <source>Validation Summary</source>
        <translation>Sintesi convalida</translation>
    </message>
    <message>
        <source>Signer&apos;s Contact Information:</source>
        <translation>Contatti firmatario:</translation>
    </message>
    <message>
        <source>Sing As</source>
        <translation type="vanished">Firma come</translation>
    </message>
    <message>
        <source>Info</source>
        <translation>Informazioni</translation>
    </message>
    <message>
        <source>Text For Signing</source>
        <translation>Testo per la firma</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Posizione</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>Motivo</translation>
    </message>
    <message>
        <source>Lock document after signing</source>
        <translation>Blocca il documento dopo la firma</translation>
    </message>
    <message>
        <source>Signature Preview</source>
        <translation>Anteprima firma</translation>
    </message>
    <message>
        <source>I have reviewed this document</source>
        <translation>Ho ricontrollato questo documento</translation>
    </message>
    <message>
        <source>I am approving this document</source>
        <translation>Ho approvato questo documento</translation>
    </message>
    <message>
        <source>I attest to the accuracy and integrity of this document</source>
        <translation>Attesto l&apos;accuratezza e integrità di questo documento</translation>
    </message>
    <message>
        <source>I agree to specified parts of this document</source>
        <translation>Approvo le parti specificate di questo documento</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="obsolete">Sfoglia</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>Apri file</translation>
    </message>
    <message>
        <source>p12 Files (*.p12)</source>
        <translation>File p12</translation>
    </message>
    <message>
        <source>A password is required to open certificate:</source>
        <translation>Occorre una password per aprire il certificato:</translation>
    </message>
    <message>
        <source>Sign</source>
        <translation>Firmare</translation>
    </message>
    <message>
        <source>Show Image</source>
        <translation>Mostra immagine</translation>
    </message>
    <message>
        <source>Stretch Image</source>
        <translation>Immagine estesa</translation>
    </message>
    <message>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <source>Show Text</source>
        <translation>Mostra testo</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>Apri immagine</translation>
    </message>
    <message>
        <source>Image Files (*.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation>File immagine (*.tif *.png *.jpg *.jpeg *.bmp)</translation>
    </message>
    <message>
        <source>A error occurred during the signature verification!</source>
        <translation>Si è verificato un errorre durante la verifica della firma!</translation>
    </message>
    <message>
        <source>The document has been altered or corrupted since the signatures was applied.</source>
        <translation>Il documento è stato modificato o alterato dopo l&apos;apposizione della firma</translation>
    </message>
    <message>
        <source>Document has not been changed since the signatures was applied.</source>
        <translation>Il documento non è stato modificato dopo l&apos;apposizione della firma</translation>
    </message>
    <message>
        <source>Signature is INVALID</source>
        <translation>La firma NON è valida</translation>
    </message>
    <message>
        <source>Signature validity is UNKNOWN</source>
        <translation>Validità SCONOSCIUTA della firma</translation>
    </message>
    <message>
        <source>The signers identity is unknown because it has not been include in your list of trusted identities and none of its parent certificates is trust identities.</source>
        <translation>L&apos;identità dei firmatari è sconosciuta, perché non inclusa nell&apos;elenco delle identità affidabili e nessuno dei certificati padre corrisponde a identità di fiducia.</translation>
    </message>
    <message>
        <source>Error during signature verification.</source>
        <translation>Errore durante la verifica della firma.</translation>
    </message>
    <message>
        <source>Details: The signature byte range is invalid</source>
        <translation>Dettagli: l&apos;intervallo di byte della firma non è valido</translation>
    </message>
    <message>
        <source>I am the author of this document</source>
        <translation>Sono l&apos;autore di questo documento</translation>
    </message>
    <message>
        <source>This certificate is not trusted</source>
        <translation>Questo certificato non è attendibile</translation>
    </message>
    <message>
        <source>Browse...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sign As</source>
        <translation>Firma come</translation>
    </message>
</context>
<context>
    <name>SignatureInfoDialog</name>
    <message>
        <source>Info</source>
        <translation type="unfinished">Informazioni</translation>
    </message>
    <message>
        <source>Issuer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Common Name (CN)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Organization (O)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Organizational Unit (OU)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Serial Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Algorithm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subject</source>
        <translation type="unfinished">Soggetto</translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Validity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not Before</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not After</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SHA-1:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MD5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add to Trusted Identities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Data</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StickyNoteDlg</name>
    <message>
        <source>Form</source>
        <translation>Modulo</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="vanished">Impostazioni</translation>
    </message>
</context>
<context>
    <name>TextDialog</name>
    <message>
        <source>Font:</source>
        <translation type="obsolete">Tipo di carattere:</translation>
    </message>
    <message>
        <source>Font size:</source>
        <translation type="obsolete">Dimensione carattere:</translation>
    </message>
    <message>
        <source>Font color:</source>
        <translation type="obsolete">Colore testo:</translation>
    </message>
</context>
</TS>
