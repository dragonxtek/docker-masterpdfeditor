<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru_RU">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../src/aboutdialog.ui" line="14"/>
        <source>About</source>
        <translation>О Программе</translation>
    </message>
    <message>
        <location filename="../src/aboutdialog.ui" line="60"/>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
</context>
<context>
    <name>Application</name>
    <message>
        <source>File</source>
        <translation type="vanished">Файл</translation>
    </message>
    <message>
        <source>New</source>
        <translation type="vanished">Новый</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="vanished">Открыть</translation>
    </message>
    <message>
        <source>Recent Files</source>
        <translation type="vanished">Недавние файлы</translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="obsolete">Справка</translation>
    </message>
    <message>
        <source>Help...</source>
        <translation type="vanished">Справка...</translation>
    </message>
    <message>
        <source>Contents</source>
        <translation type="vanished">Содержание</translation>
    </message>
    <message>
        <source>Home page</source>
        <translation type="vanished">Домашняя страница</translation>
    </message>
    <message>
        <source>Suggestions...</source>
        <translation type="vanished">Предложения...</translation>
    </message>
    <message>
        <source>Register...</source>
        <translation type="vanished">Зарегистрировать...</translation>
    </message>
    <message>
        <source>Check for Update</source>
        <translation type="vanished">Проверить обновления</translation>
    </message>
    <message>
        <source>Empty recent files list</source>
        <translation type="vanished">Очистить список последних файлов</translation>
    </message>
</context>
<context>
    <name>BookmarksDialogProp</name>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="14"/>
        <source>Bookmark Properties</source>
        <translation>Свойства Закладки</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="24"/>
        <source>Options</source>
        <translation>Параметры</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="48"/>
        <source>Text</source>
        <translation>Текст</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="83"/>
        <source>Set current position</source>
        <translation>Установить текущую позицию</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="93"/>
        <source>Appearance</source>
        <translation>Внешний вид</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="112"/>
        <source>Style</source>
        <translation>Стиль</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="126"/>
        <source>Plain</source>
        <translation>Нормальный</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="131"/>
        <source>Italic</source>
        <translation>Курсив</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="136"/>
        <source>Bold</source>
        <translation>Жирный</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="141"/>
        <source>Italic &amp; Bold</source>
        <translation>Курсив и Жирный</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="162"/>
        <source>Color</source>
        <translation>Цвет</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="69"/>
        <source>Page Number</source>
        <translation>Номер страницы</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="176"/>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="276"/>
        <source>Actions</source>
        <translation>Действия</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="323"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="310"/>
        <source>Edit</source>
        <translation>Редактировать</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="182"/>
        <source>Add an Action</source>
        <translation>Добавить действие</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="188"/>
        <source>Trigger</source>
        <translation>Триггер</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="217"/>
        <source>Action</source>
        <translation>Действие</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="196"/>
        <source>Mouse Up</source>
        <translation>Mouse Up</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="60"/>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="225"/>
        <source>Goto a Page View</source>
        <translation>Открыть страницу</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="230"/>
        <source>Open/execute a File</source>
        <translation>Открыть файл</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="235"/>
        <source>Open a web link</source>
        <translation>Открыть Web ссылку</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="240"/>
        <source>Reset form</source>
        <translation>Сбросить формы</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="245"/>
        <source>Show/Hide fields</source>
        <translation>Показать/скрыть формы</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="250"/>
        <source>Submit a form</source>
        <translation>Отправить формы</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="255"/>
        <source>Run a JavaScript</source>
        <translation>Запуск JavaScript</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="263"/>
        <source>Add</source>
        <translation>Добавить</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="65"/>
        <source>untitled</source>
        <translation>Без названия</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="207"/>
        <source>Do you want to set the current position?</source>
        <translation>Вы хотите установить текущую позицию?</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="209"/>
        <source>Custom</source>
        <translation>Настроить</translation>
    </message>
</context>
<context>
    <name>DialogDeletePages</name>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="14"/>
        <source>Delete Page(s)</source>
        <translation>Удалить страницы</translation>
    </message>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="26"/>
        <source>Page Range</source>
        <translation>Диапазон страниц</translation>
    </message>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="32"/>
        <source>Pages</source>
        <translation>Страницы</translation>
    </message>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="58"/>
        <source>Sample: 1,6-8,12</source>
        <translation>Пример: 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="78"/>
        <source>Current Page</source>
        <translation>Текущая страница</translation>
    </message>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="88"/>
        <source>Pages from</source>
        <translation>Страницы   От</translation>
    </message>
    <message>
        <source>Selected pages</source>
        <translation type="vanished">Выбранные страницы</translation>
    </message>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="140"/>
        <source>The removed page(s) cannot be recovered with undo operation.</source>
        <translation>Вы не сможете восстановить удаленые страницы.</translation>
    </message>
    <message>
        <source>Pages from:</source>
        <translation type="obsolete">Страницы:</translation>
    </message>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="114"/>
        <source>to:</source>
        <translation>До:</translation>
    </message>
    <message>
        <source>The removed page(s) will never recovered, delete it anyway?</source>
        <translation type="obsolete">Вы не сможете отменить эту операцию. Удалить ?</translation>
    </message>
</context>
<context>
    <name>DialogFormFields</name>
    <message>
        <source>Form Fields</source>
        <translation type="obsolete">Формы</translation>
    </message>
    <message>
        <source>Radio Box</source>
        <translation type="obsolete">Переключатель</translation>
    </message>
    <message>
        <source>Combo Box</source>
        <translation type="obsolete">Поле со списком</translation>
    </message>
    <message>
        <source>List Box</source>
        <translation type="obsolete">Список</translation>
    </message>
    <message>
        <source>Button</source>
        <translation type="obsolete">Кнопка</translation>
    </message>
    <message>
        <source>Check Box</source>
        <translation type="obsolete">Флажок</translation>
    </message>
    <message>
        <source>Text Field</source>
        <translation type="obsolete">Текстовое поле</translation>
    </message>
</context>
<context>
    <name>DialogNotes</name>
    <message>
        <source>Sticky Note Options</source>
        <translation type="obsolete">Параметры</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="vanished">Параметры</translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="vanished">Текст</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type="vanished">Внешний вид</translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="vanished">Цвет</translation>
    </message>
    <message>
        <source>Opacity</source>
        <translation type="vanished">Непрозрачность</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="vanished">Общие</translation>
    </message>
    <message>
        <source>Author</source>
        <translation type="vanished">Автор</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation type="vanished">Тема</translation>
    </message>
    <message>
        <source>Locked</source>
        <translation type="vanished">Заблокированный</translation>
    </message>
</context>
<context>
    <name>DialogRotatePage</name>
    <message>
        <source>Rotate Pages</source>
        <translation type="vanished">Поворот страницы</translation>
    </message>
    <message>
        <source>Direction</source>
        <translation type="vanished">Направление</translation>
    </message>
    <message>
        <source>Clockwise 90 degrees</source>
        <translation type="vanished">По часовой стрелке на 90 градусов</translation>
    </message>
    <message>
        <source>180 degrees</source>
        <translation type="vanished">180 градусов</translation>
    </message>
    <message>
        <source>Counterclockwise 90 degrees</source>
        <translation type="vanished">Против часовой стрелки на 90 градусов </translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Диапазон страниц</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">до:</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Страницы  от</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Текущая страница</translation>
    </message>
</context>
<context>
    <name>DocPage</name>
    <message>
        <source>Save Image to file</source>
        <translation type="vanished">Сохранить изображение в файл</translation>
    </message>
    <message>
        <source>Edit text</source>
        <translation type="vanished">Редактировать текст</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage.cpp" line="17"/>
        <source>Cut</source>
        <translation>Вырезать</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage.cpp" line="18"/>
        <source>Copy</source>
        <translation>Копировать</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage.cpp" line="27"/>
        <source>Add Sticky Note</source>
        <translation>Добавить заметку</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage.cpp" line="28"/>
        <source>Highlight Text</source>
        <translation>Подсветка текста</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage.cpp" line="29"/>
        <source>Strikeout Text</source>
        <translation>Зачеркивание текста</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage.cpp" line="30"/>
        <source>Underline Text</source>
        <translation>Подчеркивание текста</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage.cpp" line="31"/>
        <source>Add Bookmark</source>
        <translation>Добавить закладку</translation>
    </message>
    <message>
        <source>Send To Back</source>
        <translation type="vanished">На задний план</translation>
    </message>
    <message>
        <source>Bring To Front</source>
        <translation type="vanished">На передний план</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="vanished">Удалить</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="vanished">Отменить</translation>
    </message>
    <message>
        <source>Object Properties...</source>
        <translation type="vanished">Свойства объекта...</translation>
    </message>
    <message>
        <source>Set Fit to Page</source>
        <translation type="vanished">Установить по размерам страницы</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="vanished">Сохранить как...</translation>
    </message>
    <message>
        <source>Error loading default font</source>
        <translation type="vanished">Ошибка загрузки шрифта по умолчанию</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="obsolete">Свойства</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage.cpp" line="20"/>
        <source>Select All</source>
        <translation>Выделить все</translation>
    </message>
    <message>
        <source>UnSelect</source>
        <translation type="vanished">Сбросить выделение</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage.cpp" line="19"/>
        <source>Paste</source>
        <translation>Вставить</translation>
    </message>
    <message>
        <source>Save File</source>
        <translation type="obsolete">Сохранить файл</translation>
    </message>
    <message>
        <source>PNG Images (*.png);;BMP Images (*.bmp)</source>
        <translation type="vanished">PNG Формат (*.png);;BMP Формат (*.bmp)</translation>
    </message>
    <message>
        <source>PNG Images (*.png)</source>
        <translation type="vanished">PNG формат (*.png)</translation>
    </message>
    <message>
        <source>The clipboard doesn&apos;t contain an data</source>
        <translation type="vanished">Буфер обмена не содержит данных</translation>
    </message>
</context>
<context>
    <name>DocPageBase</name>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="78"/>
        <source>Copy</source>
        <translation>Копировать</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="79"/>
        <source>Cut</source>
        <translation>Вырезать</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="80"/>
        <source>Paste</source>
        <translation>Вставить</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="81"/>
        <source>Select All</source>
        <translation>Выделить все</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="82"/>
        <source>Options</source>
        <translation>Параметры</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="83"/>
        <source>Edit text</source>
        <translation>Редактировать текст</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="84"/>
        <source>Signature options</source>
        <translation>Свойства подписи</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="85"/>
        <source>Undo</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="86"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="87"/>
        <source>Set Fit to Page</source>
        <translation>Установить по размерам страницы</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="88"/>
        <source>Save Image to file</source>
        <translation>Сохранить изображение в файл</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="731"/>
        <source>Save As...</source>
        <translation>Сохранить как...</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="733"/>
        <source>PNG Images (*.png);;BMP Images (*.bmp)</source>
        <translation>PNG Формат (*.png);;BMP Формат (*.bmp)</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="743"/>
        <source>PNG Images (*.png)</source>
        <translation>PNG формат (*.png)</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="1470"/>
        <source>Open Image</source>
        <translation>Открыть изображение</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="1470"/>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation>Файлы изображений (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp)</translation>
    </message>
    <message>
        <source>Image Files (*.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation type="vanished">Файлы изображений (*.tif *.png *.jpg *.jpeg *.bmp)</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="1503"/>
        <source>ERORR Load Image !</source>
        <translation>Ошибка загрузки изображения!</translation>
    </message>
</context>
<context>
    <name>Document</name>
    <message>
        <source>Do you want to open?</source>
        <translation type="obsolete">Вы хотите открыть?</translation>
    </message>
    <message>
        <source>There was an error printing the document</source>
        <translation type="vanished">Произошла ошибка при печати документа</translation>
    </message>
</context>
<context>
    <name>EditActionForm</name>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="14"/>
        <source>Action</source>
        <translation>Действие</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="49"/>
        <source>Java script editor</source>
        <translation>Редактор Java</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="80"/>
        <source>Goto a page</source>
        <translation>Перейти к странице</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="99"/>
        <location filename="../src/forms/EditActionForm.ui" line="154"/>
        <location filename="../src/forms/EditActionForm.ui" line="243"/>
        <source>auto</source>
        <translation>auto</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="272"/>
        <source>Top</source>
        <translation>Верх</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="236"/>
        <source>Left</source>
        <translation>Слева</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="92"/>
        <source>Page Number</source>
        <translation>Номер страницы</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="279"/>
        <source>Zoom (%)</source>
        <translation>Масштаб(%)</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="319"/>
        <location filename="../src/forms/EditActionForm.cpp" line="153"/>
        <source>Open/execute a File</source>
        <translation>Открыть файл</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="325"/>
        <source>Edit a file</source>
        <translation>Редактировать файл</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="450"/>
        <source>Show</source>
        <translation>Показать</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="362"/>
        <location filename="../src/forms/EditActionForm.ui" line="368"/>
        <location filename="../src/forms/EditActionForm.ui" line="517"/>
        <source>Select Fields</source>
        <translation>Выбрать поля</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="411"/>
        <location filename="../src/forms/EditActionForm.ui" line="543"/>
        <source>Deselect All</source>
        <translation>Снять</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="437"/>
        <source>Hide</source>
        <translation>Скрыть</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="398"/>
        <location filename="../src/forms/EditActionForm.ui" line="523"/>
        <source>Select All</source>
        <translation>Выделить все</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="86"/>
        <source>Options</source>
        <translation>Параметры</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="157"/>
        <location filename="../src/forms/EditActionForm.ui" line="246"/>
        <source> px</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="229"/>
        <source>Zoom Mode</source>
        <translation>Режим масштабирования</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="181"/>
        <source>Custom</source>
        <translation>Другой</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="186"/>
        <source>Inherit Zoom</source>
        <translation>Автоматически</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="191"/>
        <source>Fit Page</source>
        <translation>По размеру страницы</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="196"/>
        <source>Fit Width</source>
        <translation>По ширине страницы</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="201"/>
        <source>FitV</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="206"/>
        <source>FitR</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="211"/>
        <source>FitB</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="216"/>
        <source>FitBH</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="221"/>
        <source>FitBV</source>
        <translation></translation>
    </message>
    <message>
        <source>Set current position</source>
        <translation type="vanished">Установите текущую позицию</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="335"/>
        <location filename="../src/forms/EditActionForm.ui" line="608"/>
        <source>Browse</source>
        <translation>Обзор</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="464"/>
        <source>Format</source>
        <translation>Формат</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="470"/>
        <source>FDF</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="480"/>
        <source>HTML</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="487"/>
        <source>XFDF</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="494"/>
        <source>PDF</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="556"/>
        <source>Method</source>
        <translation>Метод</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="563"/>
        <source>Local file</source>
        <translation>Локальный файл</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="568"/>
        <source>E-mail</source>
        <translation>Емаил</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="573"/>
        <source>FTP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="578"/>
        <source>HTTP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="621"/>
        <source>Use anonymous</source>
        <translation>Анонимный</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="628"/>
        <source>Need user name and password</source>
        <translation>Требуется  имя пользователя и пароль</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="638"/>
        <source>User name</source>
        <translation>Имя пользователя</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="661"/>
        <source>Password</source>
        <translation>Пароль</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="112"/>
        <location filename="../src/forms/EditActionForm.cpp" line="126"/>
        <source>Open File</source>
        <translation>Открыть файл</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="114"/>
        <location filename="../src/forms/EditActionForm.cpp" line="128"/>
        <source>All Files (*.*)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="154"/>
        <source>Enter a file:</source>
        <translation>Введите имя файла:</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="161"/>
        <source>Open a web link</source>
        <translation>Открыть Web ссылку</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="163"/>
        <source>Enter a web site:</source>
        <translation>Введите ссылку:</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="214"/>
        <source>Show/Hide Fields</source>
        <translation>Показать/скрыть формы</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="218"/>
        <source>Select Field</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="247"/>
        <source>Reset Form</source>
        <translation>Сбросить формы</translation>
    </message>
</context>
<context>
    <name>EditActionSmallForm</name>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="14"/>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="116"/>
        <source>Action</source>
        <translation>Действие</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="27"/>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="99"/>
        <source>Open/execute a File</source>
        <translation>Открыть файл</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="36"/>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="100"/>
        <source>Enter a file:</source>
        <translation>Введите имя файла:</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="49"/>
        <source>Browse</source>
        <translation>Обзор</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="76"/>
        <source>Goto a page</source>
        <translation>Перейти к странице</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="82"/>
        <source>Page Number</source>
        <translation>Номер страницы</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="89"/>
        <source>Zoom Mode</source>
        <translation>Режим масштабирования</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="96"/>
        <source>Zoom (%)</source>
        <translation>Масштаб(%)</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="103"/>
        <source>X</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="110"/>
        <source>Y</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="134"/>
        <source>XYZ</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="139"/>
        <source>Fit</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="144"/>
        <source>FitH</source>
        <translation></translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="vanished">Другой</translation>
    </message>
    <message>
        <source>Inherit Zoom</source>
        <translation type="vanished">Автоматически</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation type="vanished">По размеру страницы</translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation type="vanished">По ширине страницы</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="149"/>
        <source>FitV</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="154"/>
        <source>FitR</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="159"/>
        <source>FitB</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="164"/>
        <source>FitBH</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="169"/>
        <source>FitBV</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="177"/>
        <location filename="../src/forms/EditActionSmallForm.ui" line="193"/>
        <location filename="../src/forms/EditActionSmallForm.ui" line="209"/>
        <source>auto</source>
        <translation>auto</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="196"/>
        <location filename="../src/forms/EditActionSmallForm.ui" line="212"/>
        <source> px</source>
        <translation></translation>
    </message>
    <message>
        <source>Set current position</source>
        <translation type="vanished">Установить текущую позицию</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="107"/>
        <source>Open a web link</source>
        <translation>Открыть Web ссылку</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="108"/>
        <source>Enter a web site:</source>
        <translation>Введите ссылку:</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="115"/>
        <source>Named Action</source>
        <translation>Выполнить команду меню</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="165"/>
        <source>Open File</source>
        <translation>Открыть файл</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="167"/>
        <source>All Files (*.*)</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>ExportPageDialog</name>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="14"/>
        <source>Extract Pages</source>
        <translation>Извлечь страницы</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="26"/>
        <source>File Name</source>
        <translation>Имя файла</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="54"/>
        <source>Browse</source>
        <translation>Обзор</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="67"/>
        <source>Page Range</source>
        <translation>Диапазон страниц</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="73"/>
        <source>Current Page</source>
        <translation>Текущая страница</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="83"/>
        <source>All Pages</source>
        <translation>Все страницы</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="93"/>
        <source>Pages</source>
        <translation>Страницы</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="123"/>
        <source>Sample: 1,6-8,12</source>
        <translation>Пример: 1,6-8,12</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Страницы от</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">до:</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="133"/>
        <source>Extract pages as a single file</source>
        <translation>Извлечь все страницы в один файл</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="143"/>
        <source>Export Bookmarks</source>
        <translation>Экспорт закладок</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.cpp" line="10"/>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.cpp" line="36"/>
        <source>Export Pages</source>
        <translation>Экспорт страниц</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.cpp" line="74"/>
        <source>Export Pages </source>
        <translation>Экспорт страниц</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.cpp" line="113"/>
        <source>Save As PDF</source>
        <translation>Сохранить как PDF</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.cpp" line="115"/>
        <source>PDF Files (*.pdf)</source>
        <translation>PDF Файлы (*.pdf)</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.cpp" line="146"/>
        <location filename="../src/ExportPageDialog.cpp" line="173"/>
        <source>Can&apos;t save to the file:</source>
        <translation>Невозможно создать файл:
</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.cpp" line="146"/>
        <location filename="../src/ExportPageDialog.cpp" line="173"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
Файл может быть только для чтения или используется другим приложением.</translation>
    </message>
    <message>
        <source>Cannot save file :
</source>
        <translation type="obsolete">Невозможно создать файл:
</translation>
    </message>
</context>
<context>
    <name>FT_TextEdit</name>
    <message>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation type="obsolete">Этот шрифт не содержит эти символы.
Попробуйте выбрать другой шрифт.</translation>
    </message>
</context>
<context>
    <name>FileSettings</name>
    <message>
        <location filename="../src/FileSettings.ui" line="14"/>
        <source>Document Properties</source>
        <translation>Свойства документа</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="37"/>
        <source>Document Info</source>
        <translation>Сведения о документе</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="43"/>
        <source>PDF Information</source>
        <translation>Информация</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="49"/>
        <source>Title</source>
        <translation>Название</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="59"/>
        <source>Subject</source>
        <translation>Тема</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="69"/>
        <source>Author</source>
        <translation>Автор</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="99"/>
        <source>Keywords</source>
        <translation>Ключевые слова</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="79"/>
        <source>Creator</source>
        <translation>Приложение</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="89"/>
        <source>Producer</source>
        <translation>Производитель</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="113"/>
        <source>Security</source>
        <translation>Безопасность</translation>
    </message>
    <message>
        <source>Protection</source>
        <translation type="vanished">Защита</translation>
    </message>
    <message>
        <source>User Password</source>
        <translation type="vanished">Пароль пользователя</translation>
    </message>
    <message>
        <source>Owner Password</source>
        <translation type="vanished">Пароль владельца</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="225"/>
        <source>Printing the document</source>
        <translation>Разрешить печать документа</translation>
    </message>
    <message>
        <source>Show chars</source>
        <translation type="vanished">Показать символы</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="212"/>
        <source>Print a high resolution version of the document</source>
        <translation>Печать с высоким разрешением</translation>
    </message>
    <message>
        <source>Extract text and graphics</source>
        <translation type="vanished">Извлечение текста и графики</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="290"/>
        <source>Modifying document</source>
        <translation>Изменение документа</translation>
    </message>
    <message>
        <source>Modify annotations or form fields</source>
        <translation type="vanished">Изменение аннотаций и полей форм</translation>
    </message>
    <message>
        <source>Advanced extract text and graphics</source>
        <translation type="vanished">Разрешить улучшеное изменение документа</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="238"/>
        <source>Fill in existing form or signature fields</source>
        <translation>Заполнять существующие формы или подписывать</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="303"/>
        <source>Manage Pages and bookmarks</source>
        <translation>Управление страницами и закладками</translation>
    </message>
    <message>
        <source>High Encryption Level (128 bits) </source>
        <translation type="vanished">Высокий уровень шифрования (128 бит)</translation>
    </message>
    <message>
        <source>Lossless</source>
        <translation type="vanished">Без потерь</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="145"/>
        <source>No Encryption</source>
        <translation>Без шифрования</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="150"/>
        <source>Password Encryption</source>
        <translation>Защита с паролем</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="158"/>
        <source>Change</source>
        <translation>Изменить</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="184"/>
        <source>Permissions</source>
        <translation>Разрешения</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="199"/>
        <source>Extract the content of the document</source>
        <translation>Извлечение содержимого документа</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="251"/>
        <source>Content copying for accessibility</source>
        <translation>Копирование содержимого для расширенного доступа </translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="277"/>
        <source>Commenting</source>
        <translation>Комментирование</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="320"/>
        <source>Initial View</source>
        <translation>Начальный вид</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="342"/>
        <source>Page Mode:</source>
        <translation>Режим страницы:</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="350"/>
        <source>Page Only</source>
        <translation>Только страница</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="355"/>
        <source>Bookmarks Panel</source>
        <translation>Панель закладок</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="360"/>
        <source>Pages Panel</source>
        <translation>Панель «страницы»</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="375"/>
        <source>Attachments Panel</source>
        <translation>Панель вложений</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="417"/>
        <source>Run JavaScript on Document Open</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="442"/>
        <source>Add</source>
        <translation>Добавить</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="449"/>
        <source>Edit</source>
        <translation>Изменить</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="456"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="370"/>
        <source>Layers Panel</source>
        <translation>Панель «Слои»</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="365"/>
        <source>Full Screen</source>
        <translation>Полный экран</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="396"/>
        <source>Open to Page:</source>
        <translation>Открыть страницу:</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="410"/>
        <source>of :</source>
        <translation>от :</translation>
    </message>
    <message>
        <source>Black and White Images</source>
        <translation type="vanished">Черно-белые изображения</translation>
    </message>
    <message>
        <source>of 0</source>
        <translation type="obsolete">из </translation>
    </message>
    <message>
        <source>Images</source>
        <translation type="vanished">Изображения</translation>
    </message>
    <message>
        <source>Color and Grayscale Images</source>
        <translation type="vanished">Цветные изображения</translation>
    </message>
    <message>
        <source>Compression</source>
        <translation type="vanished">Сжатие</translation>
    </message>
    <message>
        <source>Image Quality:</source>
        <translation type="vanished">Качество изображения:</translation>
    </message>
    <message>
        <source>Monochrome Images</source>
        <translation type="obsolete">Монохромные изображения</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="483"/>
        <source>Fonts</source>
        <translation>Шрифты</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="499"/>
        <source>Fonts used in this document</source>
        <translation>Шрифты используемые в этом документе</translation>
    </message>
    <message>
        <source>of  </source>
        <translation type="obsolete">из </translation>
    </message>
    <message>
        <location filename="../src/FileSettings.cpp" line="420"/>
        <source>Password</source>
        <translation>Пароль</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.cpp" line="421"/>
        <source>The document is protected. Please enter a permissions password:</source>
        <translation>Документ защищен. Пожалуйста, введите пароль владельца:</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.cpp" line="438"/>
        <source>Incorrect password. Please input the owner password.</source>
        <translation>Неверный пароль. Пожалуйста, введите пароль владельца.</translation>
    </message>
</context>
<context>
    <name>FormDialogProp</name>
    <message>
        <source>Properties</source>
        <translation type="vanished">Свойства</translation>
    </message>
    <message>
        <source>Locked</source>
        <translation type="vanished">Заблокированный</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">Закрыть</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="vanished">Общие</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="vanished">Имя</translation>
    </message>
    <message>
        <source>ToolTip</source>
        <translation type="vanished">Подсказка</translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation type="vanished">Ориентация</translation>
    </message>
    <message>
        <source>0 Degrees</source>
        <translation type="vanished">0 Градусов</translation>
    </message>
    <message>
        <source>90 Degrees</source>
        <translation type="vanished">90 Градусов</translation>
    </message>
    <message>
        <source>180 Degrees</source>
        <translation type="vanished">180 Градусов</translation>
    </message>
    <message>
        <source>270 Degrees</source>
        <translation type="vanished">270 Градусов</translation>
    </message>
    <message>
        <source>Visible</source>
        <translation type="vanished">Видимый</translation>
    </message>
    <message>
        <source>Printable</source>
        <translation type="vanished">Печатаемый</translation>
    </message>
    <message>
        <source>Read Only</source>
        <translation type="vanished">Только для чтения</translation>
    </message>
    <message>
        <source>Required</source>
        <translation type="vanished">Требуемый</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type="vanished">Внешний вид</translation>
    </message>
    <message>
        <source>Borders and Colors</source>
        <translation type="vanished">Границы и цвета</translation>
    </message>
    <message>
        <source>Line Style</source>
        <translation type="vanished">Стиль линии</translation>
    </message>
    <message>
        <source>Line Thickness</source>
        <translation type="vanished">Толщина линии</translation>
    </message>
    <message>
        <source>Fill Color</source>
        <translation type="vanished">Цвет заливки</translation>
    </message>
    <message>
        <source>Border Color</source>
        <translation type="vanished">Цвет границы</translation>
    </message>
    <message>
        <source>Solid</source>
        <translation type="vanished">Сплошной</translation>
    </message>
    <message>
        <source>Dashed</source>
        <translation type="vanished">Штриховая</translation>
    </message>
    <message>
        <source>Underline</source>
        <translation type="vanished">Подчеркивание</translation>
    </message>
    <message>
        <source>Beveled</source>
        <translation type="vanished">Выпуклый</translation>
    </message>
    <message>
        <source>Inset</source>
        <translation type="vanished">Вставка</translation>
    </message>
    <message>
        <source>Thin</source>
        <translation type="vanished">Тонкая</translation>
    </message>
    <message>
        <source>Medium</source>
        <translation type="vanished">Средняя</translation>
    </message>
    <message>
        <source>Thick</source>
        <translation type="vanished">Толстая</translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="vanished">Текст</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="vanished">Размер</translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="vanished">Цвет</translation>
    </message>
    <message>
        <source>Font</source>
        <translation type="vanished">Шрифт</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="vanished">Параметры</translation>
    </message>
    <message>
        <source>Behavior</source>
        <translation type="vanished">Поведение</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="vanished">Нет</translation>
    </message>
    <message>
        <source>Push</source>
        <translation type="vanished">Нажимать</translation>
    </message>
    <message>
        <source>Outline</source>
        <translation type="vanished">Очерчивать</translation>
    </message>
    <message>
        <source>Invert</source>
        <translation type="vanished">Инвертировать</translation>
    </message>
    <message>
        <source>Sort Items</source>
        <translation type="vanished">Сортировать</translation>
    </message>
    <message>
        <source>Multiple selection</source>
        <translation type="vanished">Множественное выделение</translation>
    </message>
    <message>
        <source>Commit selected value immediately</source>
        <translation type="vanished">Сразу передавать выбранное значение</translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="vanished">Добавить</translation>
    </message>
    <message>
        <source>Down</source>
        <translation type="vanished">Вниз</translation>
    </message>
    <message>
        <source>Up</source>
        <translation type="vanished">Вверх</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="vanished">Удалить</translation>
    </message>
    <message>
        <source>Export Value</source>
        <translation type="vanished">Значение для экспорта</translation>
    </message>
    <message>
        <source>Allow user to enter custom text</source>
        <translation type="vanished">Разрешить пользователю вводить текст</translation>
    </message>
    <message>
        <source>Alignment</source>
        <translation type="vanished">Выравнивание</translation>
    </message>
    <message>
        <source>Left</source>
        <translation type="vanished">Слева</translation>
    </message>
    <message>
        <source>Center</source>
        <translation type="vanished">По центру</translation>
    </message>
    <message>
        <source>Right</source>
        <translation type="vanished">Справа</translation>
    </message>
    <message>
        <source>Default Value</source>
        <translation type="vanished">Значение по умолчанию</translation>
    </message>
    <message>
        <source>Multi-line</source>
        <translation type="vanished">Многострочный</translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="vanished">Пароль</translation>
    </message>
    <message>
        <source>Scrollable</source>
        <translation type="vanished">Прокручиваемый</translation>
    </message>
    <message>
        <source>Check spelling</source>
        <translation type="vanished">Проверка орфографии</translation>
    </message>
    <message>
        <source>Limit to</source>
        <translation type="vanished">Ограничить</translation>
    </message>
    <message>
        <source>Allow Rich Text formatting</source>
        <translation type="vanished">Форматированный текст</translation>
    </message>
    <message>
        <source>Split into</source>
        <translation type="vanished">Разделить на</translation>
    </message>
    <message>
        <source>cells</source>
        <translation type="vanished">клетки</translation>
    </message>
    <message>
        <source>chars</source>
        <translation type="vanished">симв.</translation>
    </message>
    <message>
        <source>Checked by Default</source>
        <translation type="vanished">Выбран по умолчанию</translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="vanished">Стиль</translation>
    </message>
    <message>
        <source>Square</source>
        <translation type="vanished">Квадрат</translation>
    </message>
    <message>
        <source>Star</source>
        <translation type="vanished">Звезда</translation>
    </message>
    <message>
        <source>Highlight</source>
        <translation type="vanished">Выделение</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation type="vanished">Вставить</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Signature.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;No available options&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Подпись.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Нет доступных свойств&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation type="vanished">Действия</translation>
    </message>
    <message>
        <source>Add an Action</source>
        <translation type="vanished">Добавить действие</translation>
    </message>
    <message>
        <source>Trigger</source>
        <translation type="vanished">Триггер</translation>
    </message>
    <message>
        <source>Action</source>
        <translation type="vanished">Действие</translation>
    </message>
    <message>
        <source>Mouse Up</source>
        <translation type="obsolete">Mouse Up</translation>
    </message>
    <message>
        <source>Goto a Page View</source>
        <translation type="vanished">Открыть страницу</translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation type="vanished">Открыть файл</translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation type="vanished">Открыть Web ссылку</translation>
    </message>
    <message>
        <source>Reset form</source>
        <translation type="vanished">Сбросить формы</translation>
    </message>
    <message>
        <source>Show/Hide fields</source>
        <translation type="vanished">Показать/скрыть формы</translation>
    </message>
    <message>
        <source>Submit a form</source>
        <translation type="vanished">Отправить формы</translation>
    </message>
    <message>
        <source>Run a JavaScript</source>
        <translation type="vanished">Запуск JavaScript</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="vanished">Редактировать</translation>
    </message>
    <message>
        <source>Link Properties</source>
        <translation type="vanished">Свойства ссылки</translation>
    </message>
    <message>
        <source>Signature Properties</source>
        <translation type="vanished">Свойства подписи</translation>
    </message>
</context>
<context>
    <name>ImportPageDialog</name>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="14"/>
        <source>Insert Pages</source>
        <translation>Вставить страницы</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="26"/>
        <source>Before page</source>
        <translation>Перед страницей</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="78"/>
        <source>After page</source>
        <translation>После страницы</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="178"/>
        <source>Page Range</source>
        <translation>Диапазон страниц</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="184"/>
        <source>All Pages</source>
        <translation>Все страницы</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="194"/>
        <source>Pages</source>
        <translation>Страницы</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="220"/>
        <source>Sample: 1,6-8,12</source>
        <translation>Пример: 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="230"/>
        <source>Import Bookmarks</source>
        <translation>Импорт закладок</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Страницы От:</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">до:</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="130"/>
        <source>File Name</source>
        <translation>Имя файла</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="165"/>
        <source>Browse</source>
        <translation>Обзор</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="145"/>
        <location filename="../src/ImportPageDialog.cpp" line="184"/>
        <source>Total pages :</source>
        <translation>Всего страниц:</translation>
    </message>
    <message>
        <source>Total pages 0</source>
        <translation type="obsolete">Всего страниц</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="20"/>
        <source>Position</source>
        <translation>Позиция</translation>
    </message>
    <message>
        <source>Before current page</source>
        <translation type="vanished">Перед текущей страницей</translation>
    </message>
    <message>
        <source>After current page</source>
        <translation type="vanished">После текущей страницы</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="107"/>
        <source>After last page</source>
        <translation>После последней страницы</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="58"/>
        <source>Before first page</source>
        <translation>Перед первой страницей</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.cpp" line="10"/>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.cpp" line="108"/>
        <source>Open File</source>
        <translation>Открыть файл</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.cpp" line="108"/>
        <source>PDF Files (*.pdf)</source>
        <translation>PDF Файлы (*.pdf)</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.cpp" line="138"/>
        <source>Password</source>
        <translation>Пароль</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.cpp" line="139"/>
        <source>The file is protected. Please enter a Document Open Password:</source>
        <translation>Пожалуйста, введите пароль для открытия документа</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.cpp" line="177"/>
        <source>Error read: This PDF is protected.</source>
        <translation>Этот ПДФ файл защтщен паролем.</translation>
    </message>
    <message>
        <source>This PDF is protected. Error read pdf!</source>
        <translation type="obsolete">Это PDF защищен. Ошибка чтения pdf!</translation>
    </message>
    <message>
        <source>Total pages </source>
        <translation type="obsolete">Всего страниц</translation>
    </message>
</context>
<context>
    <name>InspectorObjectDialog</name>
    <message>
        <source>Text Properties</source>
        <translation type="obsolete">Свойства</translation>
    </message>
    <message>
        <source>Fill color</source>
        <translation type="obsolete">Цвет заливки</translation>
    </message>
    <message>
        <source>Text type</source>
        <translation type="obsolete">Тип текста</translation>
    </message>
    <message>
        <source>Stroke color</source>
        <translation type="obsolete">Цвет обводки</translation>
    </message>
    <message>
        <source>Stroke line size</source>
        <translation type="obsolete">Толщина линии</translation>
    </message>
    <message>
        <source>Enlarge selected text</source>
        <translation type="obsolete">Увеличить выделеный текст</translation>
    </message>
    <message>
        <source>Reduce selected text</source>
        <translation type="obsolete">Уменьшить выделеный текст</translation>
    </message>
</context>
<context>
    <name>JavaScriptEditDialog</name>
    <message>
        <location filename="../src/forms/javascripteditdialog.ui" line="14"/>
        <source>Java Script Editor</source>
        <translation>JavaScript редактор</translation>
    </message>
    <message>
        <location filename="../src/forms/javascripteditdialog.ui" line="20"/>
        <source>Function Name</source>
        <translation>Название функции</translation>
    </message>
    <message>
        <location filename="../src/forms/javascripteditdialog.ui" line="32"/>
        <source>Java Script</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>LoadDialog</name>
    <message>
        <source>Master PDF Editor</source>
        <translation type="obsolete">Master PDF Editor</translation>
    </message>
    <message>
        <source>Loading Document</source>
        <translation type="obsolete">Загрузка документа</translation>
    </message>
</context>
<context>
    <name>MainOptions</name>
    <message>
        <source>Russian</source>
        <translation type="obsolete">Русский</translation>
    </message>
</context>
<context>
    <name>MainOptionsDialog</name>
    <message>
        <source>Options</source>
        <translation type="vanished">Параметры</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="96"/>
        <source>History</source>
        <translation>История</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="108"/>
        <source>Restore last session when application start</source>
        <translation>Восстановить последнюю сессию, при старте</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="115"/>
        <source>Restore last view settings when reopening</source>
        <translation>Восстановить последние параметры просмотра при повторном открытии</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="125"/>
        <source>Enable JavaScript</source>
        <translation>Включить JavaScript</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="188"/>
        <source> Always hide document message bar </source>
        <translation>Всегда скрывать панель сообщений документа</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="250"/>
        <source> ms</source>
        <translation> мс</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="432"/>
        <source>Default Layout and Zoom</source>
        <translation>Расположение и масштаб по умолчанию</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="438"/>
        <source>Default page layout</source>
        <translation>Макет страницы по умолчанию</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="456"/>
        <location filename="../src/mainoptionsdialog.ui" line="533"/>
        <source>Automatic</source>
        <translation>Автоматически</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="538"/>
        <source>Single Page</source>
        <translation>Одна страница</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="543"/>
        <source>Facing Pages</source>
        <translation>Две страницы</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="445"/>
        <source>Zoom</source>
        <translation>Масштаб</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="408"/>
        <source>Automatically change font when editing text</source>
        <translation>Автоматически менять шрифт при редактировании текста</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="461"/>
        <source>Actual Size</source>
        <translation>Фактический размер</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="466"/>
        <source>Fit Page</source>
        <translation>По размеру страницы</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="471"/>
        <source>Fit Width</source>
        <translation>По ширине страницы</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="476"/>
        <source>25%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="481"/>
        <source>50%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="486"/>
        <source>75%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="491"/>
        <source>100%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="496"/>
        <source>125%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="501"/>
        <source>150%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="506"/>
        <source>200%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="511"/>
        <source>300%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="516"/>
        <source>400%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="521"/>
        <source>600%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="551"/>
        <source> Always show Object Inspector</source>
        <translation>Всегда открывать инспектор объектов</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="584"/>
        <source>Smooth text and images</source>
        <translation>Использовать сглаживание</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="561"/>
        <source>Theme</source>
        <translation>Тема</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="567"/>
        <source>Fusion Dark Style</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="627"/>
        <source>Resolution</source>
        <translation>Разрешение</translation>
    </message>
    <message>
        <source>System DPI</source>
        <translation type="vanished">Системное DPI</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="643"/>
        <source>Custom</source>
        <translation>Заказное разрешение</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="1035"/>
        <source>Display</source>
        <translation>Отображение</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="266"/>
        <source>Time before a move or resize starts:</source>
        <translation>Время до перемещения или изменения размера:</translation>
    </message>
    <message>
        <source>Open saved file with the default viewer after saving</source>
        <translation type="vanished">Открывать файл с помощью стандартной программы после сохранения</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="279"/>
        <source>Select item by hovering the mouse</source>
        <translation>Выделять обьекты под мышкой</translation>
    </message>
    <message>
        <source>Save PDF file in PDF/A mode if possible.</source>
        <translation type="obsolete">Сохранять в PDF/A режиме, если это возможно.</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="181"/>
        <source>Highlight color</source>
        <translation>Цвет выделения</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="590"/>
        <location filename="../src/mainoptionsdialog.ui" line="691"/>
        <source>Text</source>
        <translation>Текст</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="597"/>
        <source>Bitmap Images</source>
        <translation>Растровые изображения</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="604"/>
        <source>Vector Images</source>
        <translation>Векторные изображения</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="633"/>
        <source>System PPI</source>
        <translation>Системное PPI</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="679"/>
        <source>Replace Document Colors</source>
        <translation>Изменить цвета в документе</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="698"/>
        <source>Page Background</source>
        <translation>Фон страницы</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="574"/>
        <location filename="../src/mainoptionsdialog.ui" line="789"/>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation>Чтобы изменения вступили в силу. необходимо перезапустить программу.</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="855"/>
        <source>Never</source>
        <translation>Никогда</translation>
    </message>
    <message>
        <source>Daily</source>
        <translation type="obsolete">Ежедневно</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="860"/>
        <source>Weekly</source>
        <translation>Еженедельно</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="865"/>
        <source>Monthly</source>
        <translation>Ежемесячно</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="841"/>
        <source>Check for Updates Automatically</source>
        <translation>Автоматическая проверка обновлений</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="79"/>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <source>Show</source>
        <translation type="vanished">Показывать</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="379"/>
        <source>Color</source>
        <translation>Цвет</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="330"/>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="17"/>
        <source>Settings</source>
        <translation>Параметры</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="721"/>
        <source>Icons in menus</source>
        <translation>Показывать иконки в меню</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="972"/>
        <location filename="../src/mainoptionsdialog.ui" line="975"/>
        <source>System</source>
        <translation>Основные</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="1011"/>
        <source>Forms</source>
        <translation>Формы</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="930"/>
        <source>toolBar</source>
        <translation></translation>
    </message>
    <message>
        <source>Save PDF file in PDF/A mode.</source>
        <translation type="vanished">Сохранить PDF  в PDF/A формате.</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="46"/>
        <source>Saving Documents</source>
        <translation>Сохранение документов</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="86"/>
        <source>Create backup file</source>
        <translation>Создать резервную копию файла</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="72"/>
        <source>Choice destination for &quot;Save As&quot; documents</source>
        <translation>Выбор каталога для документов для команды &quot;Сохранить как&quot;</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="59"/>
        <source>Last used folder</source>
        <translation>Последняя использованная папка</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="64"/>
        <source>Original documents folder</source>
        <translation>Оригинальный каталог документа</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="obsolete">Обзор</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="195"/>
        <source>Required field highlight color</source>
        <translation>Цвет выделения для требуемых форм</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="318"/>
        <source>Default font</source>
        <translation>Шрифт по умолчанию</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="768"/>
        <source>Built-in</source>
        <translation>Встроенный</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="754"/>
        <source>Please choose the interface language</source>
        <translation>Выберите ваш язык</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="1023"/>
        <source>Editing</source>
        <translation>Редактирование</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Общие</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="987"/>
        <source>Language</source>
        <translation>Язык</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="999"/>
        <source>Update</source>
        <translation>Обновление</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="318"/>
        <source>Select directory</source>
        <translation>Выбрать каталог</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="614"/>
        <source>Arabic</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="615"/>
        <source>Armenian</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="616"/>
        <source>Bulgarian</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="617"/>
        <source>Catalan</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="618"/>
        <source>Chinese-Simplified</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="619"/>
        <source>Chinese-Traditional</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="620"/>
        <source>Czech</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="621"/>
        <source>Danish</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="622"/>
        <source>Dutch</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="623"/>
        <source>English</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="624"/>
        <source>Estonian</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="625"/>
        <source>Finnish</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="626"/>
        <source>French</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="627"/>
        <source>Galician</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="628"/>
        <source>German</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="629"/>
        <source>Greek</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="630"/>
        <source>Hebrew</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="631"/>
        <source>Hungarian</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="632"/>
        <source>Irish</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="633"/>
        <source>Italian</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="634"/>
        <source>Japanese</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="635"/>
        <source>Korean</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="636"/>
        <source>Latvian</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="637"/>
        <source>Lithuanian</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="638"/>
        <source>Norwegian</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="639"/>
        <source>Norwegian-Nynorsk</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="640"/>
        <source>Polish</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="641"/>
        <source>Portuguese</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="642"/>
        <source>Portuguese-Brazilian</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="643"/>
        <source>Romanian</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="644"/>
        <source>Russian</source>
        <translation>Русский</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="645"/>
        <source>Serbian</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="646"/>
        <source>Slovak</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="647"/>
        <source>Slovenian</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="648"/>
        <source>Spanish</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="649"/>
        <source>Swedish</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="650"/>
        <source>Thai</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="651"/>
        <source>Turkish</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="652"/>
        <source>Ukrainian</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="653"/>
        <source>Valencian</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="654"/>
        <source>Vietnamese</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>MainOptionsDlg</name>
    <message>
        <source>Settings</source>
        <translation type="obsolete">Параметры</translation>
    </message>
    <message>
        <source>System</source>
        <translation type="obsolete">Основные</translation>
    </message>
    <message>
        <source>Saving Documents</source>
        <translation type="obsolete">Сохранение документов</translation>
    </message>
    <message>
        <source>Create backup file</source>
        <translation type="obsolete">Создать резервную копию файла</translation>
    </message>
    <message>
        <source>Choice destination for &quot;Save As&quot; documents</source>
        <translation type="obsolete">Выбор каталога для документов для команды &quot;Сохранить как&quot;</translation>
    </message>
    <message>
        <source>Last used folder</source>
        <translation type="obsolete">Последняя использованная папка</translation>
    </message>
    <message>
        <source>Original documents folder</source>
        <translation type="obsolete">Оригинальный каталог документа</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="obsolete">Обзор</translation>
    </message>
    <message>
        <source>Editing</source>
        <translation type="obsolete">Редактирование</translation>
    </message>
    <message>
        <source> ms</source>
        <translation type="obsolete"> мс</translation>
    </message>
    <message>
        <source>Time before a move or resize starts:</source>
        <translation type="obsolete">Время до перемещения или изменения размера объекта:</translation>
    </message>
    <message>
        <source>Smooth text and images</source>
        <translation type="obsolete">Использовать сглаживание</translation>
    </message>
    <message>
        <source>Select item by hovering the mouse</source>
        <translation type="obsolete">Выделять обьекты под мышкой</translation>
    </message>
    <message>
        <source>Open saved file with the default viewer after saving</source>
        <translation type="obsolete">Открывать файл с помощью стандартной программы после сохранения</translation>
    </message>
    <message>
        <source>Save PDF file in PDF/A mode if possible.</source>
        <translation type="obsolete">Сохранять в PDF/A режиме, если это возможно.</translation>
    </message>
    <message>
        <source>Forms</source>
        <translation type="obsolete">Формы</translation>
    </message>
    <message>
        <source>Highlight color</source>
        <translation type="obsolete">Цвет выделения</translation>
    </message>
    <message>
        <source>Required field highlight color</source>
        <translation type="obsolete">Цвет выделения для требуемых форм</translation>
    </message>
    <message>
        <source>Default font</source>
        <translation type="obsolete">Шрифт по умолчанию</translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="obsolete">Язык</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://code-industry.net/doc/master-pdfeditor/add_new_language.php&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;How to add or edit your Language&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://code-industry.net/doc/master-pdfeditor/add_new_language.php&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Как добавить или изменить язык&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Please choose the interface language</source>
        <translation type="obsolete">Выберите ваш язык</translation>
    </message>
    <message>
        <source>Check for Updates Automatically</source>
        <translation type="obsolete">Автоматическая проверка обновлений</translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="obsolete">Стиль</translation>
    </message>
    <message>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation type="obsolete">Чтобы изменения вступили в силу. необходимо перезапустить программу.</translation>
    </message>
    <message>
        <source>Save PDF file in PDF/A mode.</source>
        <translation type="obsolete">Сохранить PDF  в PDF/A формате.</translation>
    </message>
    <message>
        <source>Update</source>
        <translation type="obsolete">Обновление</translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="obsolete">Никогда</translation>
    </message>
    <message>
        <source>Daily</source>
        <translation type="obsolete">Ежедневно</translation>
    </message>
    <message>
        <source>Weekly</source>
        <translation type="obsolete">Еженедельно</translation>
    </message>
    <message>
        <source>Monthly</source>
        <translation type="obsolete">Ежемесячно</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="36"/>
        <source>File</source>
        <translation>Файл</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="46"/>
        <source>Export to</source>
        <translation>Экспорт в</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="137"/>
        <location filename="../src/mainwindow.ui" line="1318"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="310"/>
        <source>Edit</source>
        <translation>Правка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="141"/>
        <source>Align Objects</source>
        <translation>Выровнять объекты</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="68"/>
        <location filename="../src/mainwindow.ui" line="1310"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="334"/>
        <source>View</source>
        <translation>Вид</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="165"/>
        <source>Document</source>
        <translation>Документ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="95"/>
        <source>Help</source>
        <translation>Справка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="193"/>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="113"/>
        <source>Insert</source>
        <translation>Вставка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="180"/>
        <location filename="../src/mainwindow.ui" line="1334"/>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="102"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="412"/>
        <source>Comments</source>
        <translation>Комментарии</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="105"/>
        <location filename="../src/mainwindow.ui" line="1326"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="380"/>
        <source>Tools</source>
        <translation>Инструменты</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="689"/>
        <source>New</source>
        <translation>Новый</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;New (Ctrl+N)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Create a new blank PDF&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Новый документ(Ctrl+N)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Создать новый PDF документ&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="695"/>
        <location filename="../src/mainwindow.cpp" line="1916"/>
        <source>Create a new blank PDF</source>
        <translation>Создать новый PDF</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="698"/>
        <source>Ctrl+N</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="219"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="294"/>
        <source>Open</source>
        <translation>Открыть</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="222"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Open File (Ctrl+O)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Open a PDF or XPS file&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Открыть Файл (Ctrl+O)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Открыть PDF или XPS файл&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Open a PDF or XPS file</source>
        <translation type="vanished">Открыть PDF или XPS файл</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="234"/>
        <source>Ctrl+O</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="456"/>
        <location filename="../src/mainwindow.cpp" line="1619"/>
        <source>Save</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="459"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Save (Ctrl+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Save the document&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Сохранить (Ctrl+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Сохранить документ&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="468"/>
        <source>Save the document</source>
        <translation>Сохранить документ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="471"/>
        <source>Ctrl+S</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="480"/>
        <location filename="../src/mainwindow.cpp" line="402"/>
        <location filename="../src/mainwindow.cpp" line="3044"/>
        <location filename="../src/mainwindow.cpp" line="3101"/>
        <source>Save As...</source>
        <translation>Сохранить как...</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Save As PDF(Ctrl+Alt+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Save the document with a new name&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Сохранить как PDF(Ctrl+Alt+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Сохранить документ с новым именем&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="491"/>
        <source>Save the document with a new name</source>
        <translation>Сохранить документ с новым именем</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="503"/>
        <source>Print</source>
        <translation>Печать</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="506"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print (Ctrl+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Печать (Ctrl+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Печать документа&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="512"/>
        <source>Ctrl+P</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="517"/>
        <location filename="../src/mainwindow.ui" line="520"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="523"/>
        <source>Ctrl+W</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="528"/>
        <location filename="../src/mainwindow.ui" line="531"/>
        <source>Exit</source>
        <translation>Выход</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="619"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="861"/>
        <source>Bring to Front</source>
        <translation>На передний план</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="864"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Bring To Front&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Bring to Front selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;На передний план&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Переместить выделеные обьекты на передний план.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Insert a Blank Pages</source>
        <translation type="vanished">Вставить пустые страницы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="944"/>
        <source>Ctrl+R</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="949"/>
        <location filename="../src/mainwindow.ui" line="952"/>
        <source>Extract Pages...</source>
        <translation>Извлечь страницы...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="960"/>
        <location filename="../src/mainwindow.ui" line="963"/>
        <source>Insert Pages...</source>
        <translation>Вставить страницы...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1063"/>
        <location filename="../src/mainwindow.cpp" line="2448"/>
        <source>Text</source>
        <translation>Текст</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1066"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Text (Ctrl+T)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new text to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Вставить Текст (Ctrl+T)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Вставить новый текст на страницу&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1074"/>
        <source>Insert new text to current page</source>
        <translation>Вставить новый Текст в текущюю страницу</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1077"/>
        <source>Ctrl+T</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1086"/>
        <location filename="../src/mainwindow.cpp" line="2457"/>
        <source>Image</source>
        <translation>Рисунок</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1089"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Image (Ctrl+I)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new image to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Вставить Изображение (Ctrl+I)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Вставить изображение на текущюю страницу&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1097"/>
        <source>Insert new image to current page</source>
        <translation>Вставить новый Рисунок в текущюю страницу</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1100"/>
        <source>Ctrl+I</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="846"/>
        <source>Send to Back</source>
        <translation>На задний план</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="849"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Send to Back&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send to Back selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;На задний план&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Переместить выделеные обьекты на задний план.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Send to Background</source>
        <translation type="vanished">На передний план</translation>
    </message>
    <message>
        <source>Bring To Front</source>
        <translation type="vanished">На передний план</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Bring To Front&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Bring To Front selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;На передний план&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Переместить выделеные обьекты на передний план.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Delete Object</source>
        <translation type="vanished">Удалить объект </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="622"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Delete Object(s) (Del)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Delete the currently selected object(s)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Удалить обьект(ы) (Del)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Удалить выделеные обьекты с текущей страницы&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Delete the currently selected object</source>
        <translation type="vanished">Удалить выбранный объект</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="634"/>
        <source>Del</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1294"/>
        <source>Statusbar</source>
        <translation>Строка состояния</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="297"/>
        <location filename="../src/mainwindow.ui" line="300"/>
        <source>First Page</source>
        <translation>Первая страница</translation>
    </message>
    <message>
        <source>Goto first page</source>
        <translation type="vanished">Перейти к первой странице</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="312"/>
        <location filename="../src/mainwindow.ui" line="315"/>
        <source>Previous Page</source>
        <translation>Предыдущая страница</translation>
    </message>
    <message>
        <source>Goto previous page</source>
        <translation type="vanished">Перейти к предыдущей странице</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="327"/>
        <location filename="../src/mainwindow.ui" line="330"/>
        <source>Next Page</source>
        <translation>Следующая страница</translation>
    </message>
    <message>
        <source>Goto next page</source>
        <translation type="vanished">Перейти к следующей странице</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="338"/>
        <location filename="../src/mainwindow.ui" line="341"/>
        <source>Last Page</source>
        <translation>Последняя страница</translation>
    </message>
    <message>
        <source>Goto last page</source>
        <translation type="vanished">Перейти к последней странице</translation>
    </message>
    <message>
        <source>Go to Page</source>
        <translation type="vanished">Перейти на страницу</translation>
    </message>
    <message>
        <source>Insert a Blank Page(s)</source>
        <translation type="vanished">Вставить пустые страницы</translation>
    </message>
    <message>
        <source>Add a blank page</source>
        <translation type="vanished">Добавить пустую страницу</translation>
    </message>
    <message>
        <source>Delete Page(s)</source>
        <translation type="vanished">Удалить страницы</translation>
    </message>
    <message>
        <source>Delete the current page</source>
        <translation type="vanished">Удаление текущей страницы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="645"/>
        <source>Alt+Del</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1195"/>
        <location filename="../src/mainwindow.ui" line="1198"/>
        <source>Check box</source>
        <translation>Флажок</translation>
    </message>
    <message>
        <source>Insert new Check Box to current page</source>
        <translation type="vanished">Вставить новый флажок на текущую страницу</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1180"/>
        <location filename="../src/mainwindow.ui" line="1183"/>
        <source>Edit Box</source>
        <translation>Поле для редактирования</translation>
    </message>
    <message>
        <source>Insert new Edit Box to current page</source>
        <translation type="vanished">Вставить новое поле для редактирования в текущюю страницу</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1207"/>
        <location filename="../src/mainwindow.ui" line="1210"/>
        <source>Radio button</source>
        <translation>Переключатель</translation>
    </message>
    <message>
        <source>Insert new Radio Box to current page</source>
        <translation type="vanished">Вставить Переключатель в текущюю страницу</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1231"/>
        <location filename="../src/mainwindow.ui" line="1234"/>
        <source>List box</source>
        <translation>Список</translation>
    </message>
    <message>
        <source>Insert new List Box to current page</source>
        <translation type="vanished">Вставить новый Список в текущюю страницу</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1219"/>
        <location filename="../src/mainwindow.ui" line="1222"/>
        <source>Combo box</source>
        <translation>Поле ввода с выбором</translation>
    </message>
    <message>
        <source>Insert new Combo Box to current page</source>
        <translation type="vanished">Вставить новое поле ввода с выбором в текущюю страницу</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1302"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="286"/>
        <source>Main</source>
        <translation>Главная</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1255"/>
        <location filename="../src/mainwindow.ui" line="1258"/>
        <source>Signature</source>
        <translation>Подпись</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="765"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Paste (Ctrl+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Paste from the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Вставить (Ctrl+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Вставить из буфера обмена&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="787"/>
        <location filename="../src/mainwindow.ui" line="790"/>
        <source>Set Fit to Page</source>
        <translation>Установить по размерам страницы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1109"/>
        <location filename="../src/mainwindow.ui" line="1112"/>
        <source>Line</source>
        <translation>Линия</translation>
    </message>
    <message>
        <source>Add Line</source>
        <translation type="vanished">Линия</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1121"/>
        <location filename="../src/mainwindow.ui" line="1124"/>
        <source>Rectangle</source>
        <translation>Прямоугольник</translation>
    </message>
    <message>
        <source>Add Rectangle</source>
        <translation type="vanished">Прямоугольник</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1133"/>
        <location filename="../src/mainwindow.ui" line="1136"/>
        <source>Ellipse</source>
        <translation>Эллипс</translation>
    </message>
    <message>
        <source>Add Ellipse</source>
        <translation type="vanished">Эллипс</translation>
    </message>
    <message>
        <source>Polygon</source>
        <translation type="vanished">Многоугольник</translation>
    </message>
    <message>
        <source>Add Polygon</source>
        <translation type="vanished">Многоугольник</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="711"/>
        <location filename="../src/mainwindow.ui" line="714"/>
        <source>Print Preview</source>
        <translation>Предварительный просмотр</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="876"/>
        <location filename="../src/mainwindow.ui" line="879"/>
        <source>Align Left</source>
        <translation>По левому краю</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="888"/>
        <location filename="../src/mainwindow.ui" line="891"/>
        <source>Align Right</source>
        <translation>По правому краю</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="900"/>
        <location filename="../src/mainwindow.ui" line="903"/>
        <source>Align Top</source>
        <translation>По высоте</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="975"/>
        <location filename="../src/mainwindow.ui" line="978"/>
        <source>Align Bottom</source>
        <translation>По нижнему краю</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1354"/>
        <location filename="../src/mainwindow.ui" line="1357"/>
        <source>Open Object Inspector</source>
        <translation>Открыть инспектор объектов</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1362"/>
        <location filename="../src/mainwindow.ui" line="1365"/>
        <source>Crop Pages</source>
        <translation>Обрезка страницы</translation>
    </message>
    <message>
        <source>Font attributes</source>
        <translation type="vanished">Атрибуты шрифта</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="565"/>
        <location filename="../src/mainwindow.ui" line="568"/>
        <source>Reduce Page Thumbnails</source>
        <translation>Уменьшить миниатюры страниц</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="557"/>
        <location filename="../src/mainwindow.ui" line="560"/>
        <source>Enlarge Page Thumbnails</source>
        <translation>Увеличить миниатюры страниц</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Страницы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1268"/>
        <source>Contents</source>
        <translation>Содержание</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Move pages.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Инструмент Рука (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Перемещение страниц, заполнение ПДФ форм, копирование текста&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for copying and pasting&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Выделить текст (Alt+5)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Выделить текст для копирования&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1263"/>
        <source>HTML</source>
        <translation></translation>
    </message>
    <message>
        <source>Export to HTML</source>
        <translation type="vanished">Сохранить как HTML</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="795"/>
        <location filename="../src/mainwindow.ui" line="798"/>
        <location filename="../src/mainwindow.ui" line="1442"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="369"/>
        <source>Find</source>
        <translation>Поиск</translation>
    </message>
    <message>
        <source>Find Next (F3)</source>
        <translation type="vanished">Найти далее</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1431"/>
        <source>Find Next</source>
        <translation>Найти далее</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="938"/>
        <location filename="../src/mainwindow.ui" line="941"/>
        <source>Rotate Pages</source>
        <translation>Поворот страницы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="919"/>
        <location filename="../src/mainwindow.ui" line="922"/>
        <source>Move Pages</source>
        <translation>Переместить страницы</translation>
    </message>
    <message>
        <source>Add Formatted Text</source>
        <translation type="vanished">Добавить Форматированный текст</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="601"/>
        <source>Edit Text</source>
        <translation>Редактировать текст</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text Object(Alt+2)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Редактировать текст(Alt+2)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Редактировать только текстовые обьекты&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Document Info</source>
        <translation type="vanished">Сведения о документе</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="263"/>
        <source>Alt+4</source>
        <translation></translation>
    </message>
    <message>
        <source>Extract Page(s) to PDF</source>
        <translation type="vanished">Извлечь страницы в ПДФ</translation>
    </message>
    <message>
        <source>Insert Page(s) from PDF</source>
        <translation type="vanished">Вставить страницы из ПДФ</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Export to Image&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Save the document to Image&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Экспорт в изображения&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Сохранить документ в формате рисунка&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="703"/>
        <location filename="../src/mainwindow.ui" line="706"/>
        <source>Images</source>
        <translation>Изображения</translation>
    </message>
    <message>
        <source>Export the document to Image</source>
        <translation type="vanished">Экспорт документа в изображение</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="983"/>
        <source>Properties</source>
        <translation>Свойства</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="986"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Properties (Ctrl+D)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Open window with document properties&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Свойства документа(Ctrl+D)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Открыть окно со свойствами документа&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="994"/>
        <source>Open window with document properties</source>
        <translation>Свойства документа</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1000"/>
        <source>Ctrl+D</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1273"/>
        <source>Home page</source>
        <translation>Домашняя страница</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1278"/>
        <source>Register...</source>
        <translation>Регистрация...</translation>
    </message>
    <message>
        <source>&amp;About...</source>
        <translation type="vanished">О Программе...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1283"/>
        <source>Check for Update</source>
        <translation>Проверить обновления</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="810"/>
        <source>Undo</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="813"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Undo (Ctrl+Z)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Undo the last action&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Отменить (Ctrl+Z)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Отменяет последнее действие&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="819"/>
        <source>Ctrl+Z</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1145"/>
        <location filename="../src/mainwindow.ui" line="1148"/>
        <source>Pencil</source>
        <translation>Карандаш</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1171"/>
        <source>Ctrl+L</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1186"/>
        <source>Ctrl+E</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1243"/>
        <location filename="../src/mainwindow.ui" line="1246"/>
        <source>Button</source>
        <translation>Кнопка</translation>
    </message>
    <message>
        <source>Add Button</source>
        <translation type="vanished">Добавить кнопку</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="353"/>
        <location filename="../src/mainwindow.ui" line="356"/>
        <source>Zoom In</source>
        <translation>Увеличить масштаб</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="359"/>
        <source>Ctrl++</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="383"/>
        <location filename="../src/mainwindow.ui" line="386"/>
        <source>Zoom Out</source>
        <translation>Уменьшить масштаб</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="389"/>
        <source>Ctrl+-</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="368"/>
        <location filename="../src/mainwindow.ui" line="371"/>
        <source>Actual Size</source>
        <translation>Фактический размер</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="289"/>
        <location filename="../src/mainwindow.ui" line="292"/>
        <source>Settings</source>
        <translation>Параметры</translation>
    </message>
    <message>
        <source>Help...</source>
        <translation type="obsolete">Справка...</translation>
    </message>
    <message>
        <source>Bookmarks</source>
        <translation type="vanished">Закладки</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="397"/>
        <location filename="../src/mainwindow.ui" line="400"/>
        <source>Highlight Fields</source>
        <translation>Выделить формы</translation>
    </message>
    <message>
        <source>Highlight existing fields</source>
        <translation type="vanished">Выделите существующие формы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="254"/>
        <location filename="../src/mainwindow.ui" line="260"/>
        <source>Hand Tool</source>
        <translation>Инструмент «Рука»</translation>
    </message>
    <message>
        <source>Signature Field</source>
        <translation type="obsolete">Поле подписи</translation>
    </message>
    <message>
        <source>Add Signature Field</source>
        <translation type="obsolete">Добавить Поле подписи </translation>
    </message>
    <message>
        <source>Create PDF from Web Page</source>
        <translation type="obsolete">Создать PDF из Web-страницы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="927"/>
        <location filename="../src/mainwindow.ui" line="930"/>
        <source>Page layout</source>
        <translation>Размер страницы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="828"/>
        <source>Redo</source>
        <translation>Повторить</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="831"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redo (Ctrl+Y)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Redo the previously undone action.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Повторить (Ctrl+Y)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Повторяет последнее отмененное событие.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="837"/>
        <source>Ctrl+Y</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="726"/>
        <source>Cut</source>
        <translation>Вырезать</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="117"/>
        <location filename="../src/mainwindow.ui" line="1342"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="396"/>
        <source>Forms</source>
        <translation>Формы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="239"/>
        <location filename="../src/mainwindow.ui" line="242"/>
        <source>About</source>
        <translation>О Программе</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool (Alt+4)&lt;/span&gt;&lt;/p&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Инструмент Рука (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Перемещение страниц, заполнение ПДФ форм, копирование текста&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="278"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text (Alt+5)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for copying and pasting&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Выделить текст (Alt+5)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Выделить текст для копирования&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="281"/>
        <source>Select text for copying and pasting</source>
        <translation>Выделить текст для копирования</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="284"/>
        <source>Alt+5</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="303"/>
        <source>Home</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="318"/>
        <source>PgUp</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="333"/>
        <source>PgDown</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="344"/>
        <source>End</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="374"/>
        <source>Ctrl+0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="403"/>
        <source>Ctrl+H</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="408"/>
        <location filename="../src/mainwindow.ui" line="411"/>
        <source>Reset Forms</source>
        <translation>Сбросить формы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="423"/>
        <location filename="../src/mainwindow.ui" line="426"/>
        <source>Fit Page</source>
        <translation>По размеру страницы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="429"/>
        <source>Ctrl+1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="441"/>
        <location filename="../src/mainwindow.ui" line="444"/>
        <source>Fit Width</source>
        <translatorcomment>По ширине страницы</translatorcomment>
        <translation>По ширине страницы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="447"/>
        <source>Ctrl+2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="483"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Save As PDF(Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Save the document with a new name&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Сохранить как PDF(Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Сохранить документ с новым именем&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="494"/>
        <source>Ctrl+Shift+S</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="509"/>
        <source>Print the document</source>
        <translation>Печать документа</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="534"/>
        <source>Ctrl+Q</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="546"/>
        <location filename="../src/mainwindow.ui" line="549"/>
        <source>Facing Pages</source>
        <translation>Две страницы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="552"/>
        <source>Ctrl+3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="586"/>
        <source>Select and edit text, images, annotations, form fields ...</source>
        <translation>Выберите для редактирования текста, изображений, аннотации, пдф формы...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="604"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Text Object(Alt+2)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Редактировать текст(Alt+2)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Редактировать только текстовые обьекты&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="607"/>
        <source>Select text for editing</source>
        <translation>Выделить текстовые обьекты для редактирования</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="610"/>
        <source>Alt+2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="631"/>
        <source>Delete the currently selected object(s)</source>
        <translation>Удалить выделеные обьекты с текущей страницы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="639"/>
        <location filename="../src/mainwindow.ui" line="642"/>
        <source>Delete Pages</source>
        <translation>Удалить страницы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="657"/>
        <location filename="../src/mainwindow.ui" line="663"/>
        <source>Edit Forms</source>
        <translation>Редактировать формы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="660"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Form (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select form and annotations for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Редактировать Формы (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Выберите для редактирования форм и аннотаций&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="680"/>
        <source>Ctrl+F11</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1018"/>
        <source>Ctrl+6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1420"/>
        <source>Save Optimized As...</source>
        <translation>Оптимизировать и сохранить как...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1423"/>
        <source>Ctrl+Alt+S</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1434"/>
        <source>F3</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;New (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Create a new blank PDF&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Новый документ(Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Создать новый ПДФ&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="717"/>
        <source>Ctrl+Shift+P</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="729"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cut (Ctrl+X)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cut the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Вырезать (Ctrl+X)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Вырезать выделенные объект(ы) в буфер обмена&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="735"/>
        <source>Ctrl+X</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="744"/>
        <source>Copy</source>
        <translation>Копировать</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="747"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copy (Ctrl+C)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copy the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Копировать (Ctrl+C)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Скопируйте выбранные объект(ы) в буфер обмена&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="753"/>
        <source>Ctrl+C</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="692"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;New (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Create a new blank PDF&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Новый документ(Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Создать новый ПДФ&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="257"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use the hand tool for moving pages, open links and selecting text.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Инструмент Рука (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Перемещение страниц, заполнение ПДФ форм, копирование текста&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="732"/>
        <source>Cut the selection Object(s) and place on the Clipboard</source>
        <translation>Вырезать выделенные объект(ы) в буфер обмена</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="750"/>
        <source>Copy the selection Object(s) and place on the Clipboard</source>
        <translation>Скопировать выбранные объект(ы) в буфер обмена</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="762"/>
        <source>Paste</source>
        <translation>Вставить</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="768"/>
        <source>Paste from the Clipboard</source>
        <translation>Вставить из буфера обмена</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="801"/>
        <source>Ctrl+F</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="816"/>
        <source>Undo the last action</source>
        <translation>Отменяет последнее действие</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="834"/>
        <source>Redo the previously undone action.</source>
        <translation>Повторяет последнее отмененное событие.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="852"/>
        <source>Send to Back selected object.</source>
        <translation>Переместить выделеные обьекты на задний план.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="867"/>
        <source>Bring to Front selected object.</source>
        <translation>На передний план</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="908"/>
        <location filename="../src/mainwindow.ui" line="911"/>
        <source>Insert Blank Pages</source>
        <translation>Вставить пустые страницы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="914"/>
        <source>Ctrl+Shift+N</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="933"/>
        <source>Ctrl+Shift+L</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="955"/>
        <source>Ctrl+Shift+E</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="966"/>
        <source>Ctrl+Shift+I</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1015"/>
        <source>Click the page to add a note at that position</source>
        <translation>Добавить новую заметку в документ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1168"/>
        <source>Insert new link to current page</source>
        <translation>Вставить новую ссылку на текущюю страницу</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1368"/>
        <source>Ctrl+K</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1377"/>
        <location filename="../src/mainwindow.ui" line="1380"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation>Повернуть по часовой стрелке на 90 градусов</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1389"/>
        <location filename="../src/mainwindow.ui" line="1392"/>
        <location filename="../src/mainwindow.ui" line="1395"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation>Повернуть  против часовой стрелки на 90 градусов </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1400"/>
        <source>Export Form Data...</source>
        <translation>Экспорт данных...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1405"/>
        <source>Import Form Data...</source>
        <translation>Импорт данных...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1410"/>
        <source>Export Comments Data...</source>
        <translation>Экспорт данных...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1415"/>
        <source>Import Comments Data...</source>
        <translation>Импорт данных...</translation>
    </message>
    <message>
        <source>Export Data...</source>
        <translation type="vanished">Экспорт данных ...</translation>
    </message>
    <message>
        <source>Import Data...</source>
        <translation type="vanished">Импорт данных ...</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Paste (Ctrl+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Paste the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Вставить (Ctrl+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Вставить из буфера обмена&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="771"/>
        <source>Ctrl+V</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="776"/>
        <location filename="../src/mainwindow.ui" line="779"/>
        <source>Select All</source>
        <translation>Выделить все</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="782"/>
        <source>Ctrl+A</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="580"/>
        <source>Edit Document</source>
        <translation>Редактирование документа</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="583"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Document (Alt+1)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select and edit text, images, annotations, form fields ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Редактировать документ (Alt+1)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Выберите для редактирования текста, изображений, аннотации, пдф формы...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="589"/>
        <source>Alt+1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1157"/>
        <source>Link</source>
        <translation>Ссылка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1160"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Link (Ctrl+L)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new link to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Вставить ссылку (Ctrl+L)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Вставить новую ссылку на текущюю страницу&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Insert new Link to current page</source>
        <translation type="vanished">Вставить новую ссылку на текущую страницу</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1027"/>
        <location filename="../src/mainwindow.ui" line="1030"/>
        <source>Highlight Text</source>
        <translation>Подсветка текста</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1009"/>
        <source>Add Sticky Note</source>
        <translation>Добавить заметку</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1039"/>
        <location filename="../src/mainwindow.ui" line="1042"/>
        <source>Strikeout Text</source>
        <translation>Зачеркивание текста</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1051"/>
        <location filename="../src/mainwindow.ui" line="1054"/>
        <source>Underline Text</source>
        <translation>Подчеркивание текста</translation>
    </message>
    <message>
        <source>Add Stamp</source>
        <translation type="vanished">Добавить штамп</translation>
    </message>
    <message>
        <source>Suggestions...</source>
        <translation type="vanished">Предложения...</translation>
    </message>
    <message>
        <source>Suggestions</source>
        <translation type="vanished">Предложения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="275"/>
        <source>Select Text</source>
        <translation>Выделение текста</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="666"/>
        <source>Alt+3</source>
        <translation></translation>
    </message>
    <message>
        <source>Form Fields</source>
        <translation type="vanished">Формы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="203"/>
        <location filename="../src/mainwindow.cpp" line="268"/>
        <source>There was an error opening the document !</source>
        <translation>Ошибка при открытии документа!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="343"/>
        <source>Saving in XPS is temporarily not supported.
Choose PDF file name for saving.</source>
        <translation>Сохранение в XPS временно не поддерживается.
Выберите PDF имя файла для сохранения.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="402"/>
        <source>PDF Files (*.pdf)</source>
        <translation>PDF Файлы (*.pdf)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1420"/>
        <source>Open failed</source>
        <translation>Открыть не удалось</translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="vanished">Поиск</translation>
    </message>
    <message>
        <source>    This document contains interactive form fields</source>
        <translation type="vanished">    Этот документ содержит PDF формы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1421"/>
        <source>Cannot open file :
</source>
        <translation>Не удается открыть файл :
</translation>
    </message>
    <message>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="38"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="271"/>
        <source>Empty recent files list</source>
        <translation>Очистить список последних файлов</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="231"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="296"/>
        <source>Open a PDF file</source>
        <translation>Открыть PDF или XPS файл</translation>
    </message>
    <message>
        <source>Untitled</source>
        <translation type="obsolete">Без названия</translation>
    </message>
    <message>
        <source>Insert a blank page </source>
        <translation type="vanished">Вставить пустую страницу</translation>
    </message>
    <message>
        <source>Error import from :
</source>
        <translation type="vanished">Ошибка импорта из:
</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="525"/>
        <source>Export completed</source>
        <translation>Экспорт завершен</translation>
    </message>
    <message>
        <source>Cannot save file :
</source>
        <translation type="obsolete">Невозможно создать файл:
</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="383"/>
        <location filename="../src/mainwindow.cpp" line="3035"/>
        <location filename="../src/mainwindow.cpp" line="3092"/>
        <source>untitled</source>
        <translation>Без названия</translation>
    </message>
    <message>
        <source>&quot;untitled&quot;</source>
        <translation type="vanished">&quot;без названия&quot;</translation>
    </message>
    <message>
        <source>Do you want to open?</source>
        <translation type="vanished">Вы хотите открыть?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1613"/>
        <source>The document %s has been modified. 
Do you want to save your changes?</source>
        <translation>Документ %s был изменен.
Вы хотите сохранить изменения?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1620"/>
        <source>Close Without Saving</source>
        <translation>Закрыть без сохранения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1621"/>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <source>This operation has no effect </source>
        <translation type="vanished">Эта операция не имеет никакого эффекта</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="815"/>
        <source>Can&apos;t find :</source>
        <translation>Не найдено:</translation>
    </message>
    <message>
        <source>Save As HTML</source>
        <translation type="vanished">Сохранить как HTML</translation>
    </message>
    <message>
        <source>Save As Docx</source>
        <translation type="vanished">Сохранить как Docx</translation>
    </message>
    <message>
        <source>Can&apos;t create temp file:
</source>
        <translation type="vanished">Невозможно создать временый файл:</translation>
    </message>
    <message>
        <source>
The may be read-only or used by another application.</source>
        <translation type="vanished">
Файл может быть только для чтения или используется другим приложением.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="312"/>
        <source>The unregistered version will insert a watermark</source>
        <translation>ВЫ используете незарегистрированную версию которая вставит водяной знак в сохранённый документ</translation>
    </message>
    <message>
        <source>Image Files (*.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation type="vanished">Файлы изображений (*.tif *.png *.jpg *.jpeg *.bmp)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1716"/>
        <source>A error occurred during the signature verification!</source>
        <translation>Произошла ошибка при проверке подписи!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="359"/>
        <location filename="../src/mainwindow.cpp" line="416"/>
        <source>Save failed</source>
        <translation>Сохранить не удалось</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="40"/>
        <source>Ctrl+Shift++</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="41"/>
        <source>Ctrl+Shift+-</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="360"/>
        <location filename="../src/mainwindow.cpp" line="417"/>
        <source>Can&apos;t save to the file:</source>
        <translation>Невозможно создать файл:
</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="360"/>
        <location filename="../src/mainwindow.cpp" line="417"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
Файл может быть только для чтения или используется другим приложением.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2442"/>
        <source>Chacters</source>
        <translation>Символов</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2443"/>
        <source>Font type</source>
        <translation>Тип шрифта</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2445"/>
        <source>Font Embedded</source>
        <translation>Встроенный шрифт</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2447"/>
        <source>Font Not Embedded</source>
        <translation>Не встроенный шрифт</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2453"/>
        <location filename="../src/mainwindow.cpp" line="2503"/>
        <source>Width</source>
        <translation>Ширина</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2454"/>
        <location filename="../src/mainwindow.cpp" line="2504"/>
        <source>Height</source>
        <translation>Высота</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2455"/>
        <source>Filter</source>
        <translation>Фильтр</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2461"/>
        <source>Path</source>
        <translation>Векторный рисунок</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2465"/>
        <source>Shading</source>
        <translation>Векторный рисунок с заливкой</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2477"/>
        <location filename="../src/mainwindow.cpp" line="2500"/>
        <source>Objects</source>
        <translation>объектов</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2477"/>
        <location filename="../src/mainwindow.cpp" line="2513"/>
        <source>Selected</source>
        <translation>Выделено</translation>
    </message>
    <message>
        <source>Object(s)</source>
        <translation type="vanished">Объектов</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2517"/>
        <source>Page</source>
        <translation>Страница</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3044"/>
        <location filename="../src/mainwindow.cpp" line="3065"/>
        <location filename="../src/mainwindow.cpp" line="3068"/>
        <location filename="../src/mainwindow.cpp" line="3101"/>
        <location filename="../src/mainwindow.cpp" line="3121"/>
        <location filename="../src/mainwindow.cpp" line="3124"/>
        <source>FDF Files (*.fdf)</source>
        <translation>FDF Файлы (*.fdf)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_update.cpp" line="32"/>
        <source>Your version already has the last update!</source>
        <translation>У вас установлена последняя версия!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_update.cpp" line="40"/>
        <source>New Version Is Available !
Do you want to Download Now?</source>
        <translation>Доступна новая версия.
Вы хотите сейчас установить?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <source>Master PDF Editor</source>
        <translation>Master PDF Editor</translation>
    </message>
    <message>
        <source>New Version Is Available.
Do you want to Download Now?</source>
        <translation type="obsolete">Доступна новая версия.
Вы хотите сейчас установить?</translation>
    </message>
    <message>
        <source>Error loading font : 
</source>
        <translation type="obsolete">Ошибка загрузки шрифта:
</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation type="vanished">Открыть изображение</translation>
    </message>
    <message>
        <source>Image Files (*.tif *.png *.jpg *.bmp)</source>
        <translation type="obsolete">Файлы изображений (*.tif *.png *.jpg *.bmp)</translation>
    </message>
    <message>
        <source>ERORR Load Image !</source>
        <translation type="vanished">Ошибка загрузки изображения!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="278"/>
        <location filename="../src/mainwindow.cpp" line="281"/>
        <location filename="../src/mainwindow.cpp" line="3065"/>
        <location filename="../src/mainwindow.cpp" line="3068"/>
        <location filename="../src/mainwindow.cpp" line="3121"/>
        <location filename="../src/mainwindow.cpp" line="3124"/>
        <source>Open File</source>
        <translation>Открыть файл</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="278"/>
        <location filename="../src/mainwindow.cpp" line="281"/>
        <source>All Files (*.pdf *.xps);;PDF Files (*.pdf);;XPS Files (*.xps)</source>
        <translation>Все файлы (*.pdf *.xps);;PDF Формат (*.pdf);;XPS Формат (*.xps)</translation>
    </message>
    <message>
        <source>This document does not contain any form fields.</source>
        <translation type="obsolete">Этот документ не содержит никаких ПДФ форм.</translation>
    </message>
    <message>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="67"/>
        <source>Prev/Next</source>
        <translation>Предыдущая/Следующяя</translation>
    </message>
    <message>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="90"/>
        <source>Edit Tools</source>
        <translation>Инструменты</translation>
    </message>
    <message>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="146"/>
        <source>Page :</source>
        <translation>Страница:</translation>
    </message>
    <message>
        <source>Select tool</source>
        <translation type="obsolete">Редактирование</translation>
    </message>
    <message>
        <source>Move tool</source>
        <translation type="obsolete">Инструмент «Рука»</translation>
    </message>
    <message>
        <source>Text tool</source>
        <translation type="obsolete">Выделение текста</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1012"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Sticky Note&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Click the page to add a note at that position&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Добавить заметку&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Добавить новую заметку в документ&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Add Sticky Notes</source>
        <translation type="obsolete">Добавить заметку</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Highlight Text&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Выделить текст&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Strikeout Text&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Зачеркнутый текст&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Underline Text&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Подчеркивание текста&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="674"/>
        <location filename="../src/mainwindow.ui" line="677"/>
        <location filename="../src/mainwindow.ui" line="1351"/>
        <source>Object Inspector</source>
        <translation>Инспектор объектов</translation>
    </message>
    <message>
        <source>Enlarge selected text</source>
        <translation type="obsolete">Увеличить выделеный текст</translation>
    </message>
    <message>
        <source>Reduce selected text</source>
        <translation type="obsolete">Уменьшить выделеный текст</translation>
    </message>
    <message>
        <source>Document Properties</source>
        <translation type="obsolete">Свойства документа</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_tool_bars.cpp" line="432"/>
        <source>Toolbars</source>
        <translation>Панели инструментов</translation>
    </message>
    <message>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="35"/>
        <location filename="../src/mainwindow.cpp" line="2296"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="268"/>
        <source>Recent Files</source>
        <translation>Недавние файлы</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Шрифт&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Изменить имя шрифта&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Цвет текста&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Изменить цвет текста&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Font Italic</source>
        <translation type="vanished">Курсив</translation>
    </message>
    <message>
        <source>Font Bold</source>
        <translation type="vanished">Жирный</translation>
    </message>
    <message>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="76"/>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="132"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="353"/>
        <source>Zoom</source>
        <translation>Масштаб</translation>
    </message>
    <message>
        <source>Font Attributes</source>
        <translation type="vanished">Атрибуты шрифта</translation>
    </message>
    <message>
        <source>Attachment</source>
        <translation type="vanished">Вложения</translation>
    </message>
</context>
<context>
    <name>MovePagesDialog</name>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="14"/>
        <source>Move Pages</source>
        <translation>Переместить страницы</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="26"/>
        <source>Page Range</source>
        <translation>Диапазон страниц</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="32"/>
        <source>Pages</source>
        <translation>Страницы</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="58"/>
        <source>Sample: 1,6-8,12</source>
        <translation>Пример: 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="78"/>
        <source>Current Page</source>
        <translation>Текущая страница</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="88"/>
        <source>Pages from</source>
        <translation>Страницы   От</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="114"/>
        <source>to:</source>
        <translation>До:</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="140"/>
        <source>Destination</source>
        <translation>Цель</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="152"/>
        <source>To:</source>
        <translation>До:</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="162"/>
        <source>Page</source>
        <translation>Страница</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="211"/>
        <source>First</source>
        <translation>В начало  документа</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="218"/>
        <source>Last</source>
        <translation>В конец документа</translation>
    </message>
</context>
<context>
    <name>MovePagesDlg</name>
    <message>
        <source>Move Pages</source>
        <translation type="vanished">Переместить страницы</translation>
    </message>
    <message>
        <source>Destination</source>
        <translation type="vanished">Цель</translation>
    </message>
    <message>
        <source>To:</source>
        <translation type="vanished">До:</translation>
    </message>
    <message>
        <source>Page</source>
        <translation type="vanished">Страница</translation>
    </message>
    <message>
        <source>First</source>
        <translation type="vanished">В начало  документа</translation>
    </message>
    <message>
        <source>Last</source>
        <translation type="vanished">В конец документа</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Диапазон страниц</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Текущая страница</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">до:</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Страницы   От</translation>
    </message>
</context>
<context>
    <name>NewPageDialog</name>
    <message>
        <location filename="../src/NewPageDialog.ui" line="20"/>
        <source>Page Size</source>
        <translation>Размер страницы</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="191"/>
        <source>Width</source>
        <translation>Ширина</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="228"/>
        <source>Height</source>
        <translation>Высота</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="30"/>
        <source>A0</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="35"/>
        <source>A1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="40"/>
        <source>A2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="45"/>
        <source>A3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="50"/>
        <source>A4</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="55"/>
        <source>A5</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="60"/>
        <source>A6</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="65"/>
        <source>A7</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="70"/>
        <source>A8</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="75"/>
        <source>A9</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="80"/>
        <source>A10</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="85"/>
        <source>Letter</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="90"/>
        <source>Tabloid</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="95"/>
        <source>B0</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="100"/>
        <source>B1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="105"/>
        <source>B2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="110"/>
        <source>B3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="115"/>
        <source>B4</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="120"/>
        <source>B5</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="125"/>
        <source>Statement</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="130"/>
        <source>Executive</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="135"/>
        <source>Folio</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="140"/>
        <source>Quarto</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="145"/>
        <source>Note</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="150"/>
        <source>ANSI C</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="155"/>
        <source>ANSI D</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="160"/>
        <source>ANSI E</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="165"/>
        <source>ANSI F</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="170"/>
        <source>Custom page size</source>
        <translation>Пользовательский размер страницы</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="215"/>
        <source>Portrait</source>
        <translation>Портрет</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="220"/>
        <source>Landscape</source>
        <translation>Пейзаж</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="264"/>
        <source>Units</source>
        <translation>Единицы измерения</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="272"/>
        <source>points</source>
        <translation>пикселы</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="277"/>
        <source>inch</source>
        <translation>дюймы</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="282"/>
        <source>millimeter</source>
        <translation>милиметры</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="293"/>
        <source>Contents Size</source>
        <translation>Pазмер cодержания</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="305"/>
        <source>Left margin</source>
        <translation>Левое поле</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="345"/>
        <source>Top margin</source>
        <translation>Верхнее поле</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="325"/>
        <source>Right margin</source>
        <translation>Правое поле</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="365"/>
        <source>Bottom margin</source>
        <translation>Нижнее поле</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="388"/>
        <source>Position</source>
        <translation>Позиция</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="394"/>
        <source>Before current page</source>
        <translation>Перед текущей страницей</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="411"/>
        <source>After current page</source>
        <translation>После текущей страницы</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="418"/>
        <source>After last page</source>
        <translation>После последней страницы</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="404"/>
        <source>Before first page</source>
        <translation>Перед первой страницей</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="428"/>
        <source>Number of pages</source>
        <translation>Количество страниц</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="454"/>
        <source>Page(s)</source>
        <translation>Страниц</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="434"/>
        <source>Create</source>
        <translation>Создать</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.cpp" line="142"/>
        <source> px</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.cpp" line="166"/>
        <source> in</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.cpp" line="188"/>
        <source> mm</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>ObjectInspector</name>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="60"/>
        <source>No Properties
There is no object selections.</source>
        <translation>Не выбран ни один обьект. </translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="308"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2708"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2927"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1638"/>
        <source>Text</source>
        <translation>Текст</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="142"/>
        <source>Property</source>
        <translation>Свойства</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="147"/>
        <source>Value</source>
        <translation>Значение</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="443"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="647"/>
        <source>Add</source>
        <translation>Добавить</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="453"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2390"/>
        <source>Actions</source>
        <translation>Действия</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="475"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1672"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1706"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1778"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1834"/>
        <source>Edit</source>
        <translation>Изменить</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="485"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="664"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="541"/>
        <source>Up Label</source>
        <translation>Надпись</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="548"/>
        <source>Behavior</source>
        <translation>Поведение</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="562"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1096"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1258"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1413"/>
        <source>None</source>
        <translation>Нет</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="567"/>
        <source>Push</source>
        <translation>Нажимать</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="572"/>
        <source>Outline</source>
        <translation>Очерчивать</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="577"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1101"/>
        <source>Invert</source>
        <translation>Инвертировать</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="585"/>
        <source>Down Label</source>
        <translation>Надпись при нажатии</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="595"/>
        <source>RollOver Label</source>
        <translation>Надпись при наведении</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="631"/>
        <source>Item</source>
        <translation>Пункт</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="654"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="969"/>
        <source>Export Value</source>
        <translation>Значение для экспорта</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="693"/>
        <source>Up</source>
        <translation>Вверх</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="706"/>
        <source>Down</source>
        <translation>Вниз</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="713"/>
        <source>Sort Items</source>
        <translation>Сортировать</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="720"/>
        <source>Commit selected value immediately</source>
        <translation>Сразу передавать выбранное значение</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="727"/>
        <source>Multiple selection</source>
        <translation>Множественное выделение</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="734"/>
        <source>Allow user to enter custom text</source>
        <translation>Разрешить пользователю вводить текст</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="866"/>
        <source>Password</source>
        <translation>Пароль</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="859"/>
        <source>Scrollable</source>
        <translation>Прокручиваемый</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="852"/>
        <source>Check spelling</source>
        <translation>Проверка орфографии</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="767"/>
        <source>Limit to</source>
        <translation>Ограничить</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="781"/>
        <source>chars</source>
        <translation>симв.</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="788"/>
        <source>Split into</source>
        <translation>Разделить на</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="802"/>
        <source>Allow Rich Text formatting</source>
        <translation>Форматированный текст</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="873"/>
        <source>Multi-line</source>
        <translation>Многострочный</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="812"/>
        <source>cells</source>
        <translation>клетки</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="820"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2195"/>
        <source>Left</source>
        <translation>Слева</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="825"/>
        <source>Center</source>
        <translation>По центру</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="830"/>
        <source>Right</source>
        <translation>Справа</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="838"/>
        <source>Default Value</source>
        <translation>Значение по умолчанию</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="845"/>
        <source>Alignment</source>
        <translation>Выравнивание</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="912"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2276"/>
        <source>Style</source>
        <translation>Стиль</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="923"/>
        <source>Check</source>
        <translation>Флажок</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="928"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="203"/>
        <source>Circle</source>
        <translation>Круг</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="933"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="205"/>
        <source>Cross</source>
        <translation>Крест</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="938"/>
        <source>Diamond</source>
        <translation>Ромб</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="943"/>
        <source>Square</source>
        <translation>Квадрат</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="948"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="214"/>
        <source>Star</source>
        <translation>Звезда</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="992"/>
        <source>Checked by Default</source>
        <translation>Выбран по умолчанию</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1038"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2698"/>
        <source>Line Thickness</source>
        <translation>Толщина линии</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1052"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2648"/>
        <source>Border Color</source>
        <translation>Цвет границы</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1059"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2691"/>
        <source>Line Style</source>
        <translation>Стиль линии</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1067"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2663"/>
        <source>Solid</source>
        <translation>Сплошной</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1072"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2668"/>
        <source>Dashed</source>
        <translation>Штриховая</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1077"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2683"/>
        <source>Underline</source>
        <translation>Подчеркивание</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1085"/>
        <source>Highlight</source>
        <translation>Выделение</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1106"/>
        <source>OutLine</source>
        <translation>Контурный</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1111"/>
        <source>Insert</source>
        <translation>Вставить</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1145"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Signature.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;No available options&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Подпись.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Нет доступных свойств&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1204"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2409"/>
        <source>Format</source>
        <translation>Формат</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1244"/>
        <source>Format category</source>
        <translation>Категория</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1263"/>
        <source>Number</source>
        <translation>Номер</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1268"/>
        <source>Percentage</source>
        <translation>Процент</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1273"/>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1278"/>
        <source>Time</source>
        <translation>Время</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1283"/>
        <source>Special</source>
        <translation>Специальный</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1288"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1443"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="189"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="193"/>
        <source>Custom</source>
        <translation>Другой</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1307"/>
        <source>0</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1312"/>
        <source>1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1317"/>
        <source>2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1322"/>
        <source>3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1327"/>
        <source>4</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1332"/>
        <source>5</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1337"/>
        <source>6</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1342"/>
        <source>7</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1347"/>
        <source>8</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1352"/>
        <source>9</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1357"/>
        <source>10</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1366"/>
        <source>1,234.56</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1371"/>
        <source>1234.56</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1376"/>
        <source>1.234,56</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1381"/>
        <source>1234,56</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1395"/>
        <source>Currency Symbol</source>
        <translation>Символ валюты</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1418"/>
        <source>Dollar ($)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1423"/>
        <source>Euro (€)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1428"/>
        <source>Pound (£)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1433"/>
        <source>Yen (¥)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1438"/>
        <source>Ruble (Руб)</source>
        <translation>Рубль (Руб)</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1464"/>
        <source>Show parentheses</source>
        <translation>Показать скобки</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1484"/>
        <source>Decimal Places</source>
        <translation>Знаки после запятой</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1491"/>
        <source>Separation Style</source>
        <translation>Стиль</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1498"/>
        <source>Use red text</source>
        <translation>Красный текст</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1515"/>
        <source>Date Options</source>
        <translation>Параметры даты</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1554"/>
        <source>Time Options</source>
        <translation>Параметры времени</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1587"/>
        <source>Special Options</source>
        <translation>Специальные параметры</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1645"/>
        <source>Format Script</source>
        <translation>Скрипт форматирования</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1679"/>
        <source>KeyStroke Script</source>
        <translation>Скрипт KeyStroke</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1730"/>
        <source>Validate</source>
        <translation>Валидация </translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1751"/>
        <source>Validation Script</source>
        <translation>Скрипт валидации</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1786"/>
        <source>Calculate</source>
        <translation>Калькуляция</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1807"/>
        <source>Calculation Script</source>
        <translation>Скрипт калькуляции</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1936"/>
        <source>Full text</source>
        <translation>Заливка</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1941"/>
        <source>Stroke Text</source>
        <translation>Обводка</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1946"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2488"/>
        <source>Full and Stroke</source>
        <translation>Заливка и Обводка</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1951"/>
        <source>Invisible</source>
        <translation>Невидимый</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1991"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2556"/>
        <source>Line Width</source>
        <translation>Толщина линии</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2020"/>
        <source>Character spacing</source>
        <translation>Интервал между символами</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2027"/>
        <source>Word spacing</source>
        <translation>Интервал между словами</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2061"/>
        <source>F</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2087"/>
        <source>D</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2097"/>
        <source>E</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2107"/>
        <source>A</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2117"/>
        <source>C</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2127"/>
        <source>B</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2168"/>
        <source>Top</source>
        <translation>Сверху</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2216"/>
        <source>Maintain aspect ratio</source>
        <translation>Сохранять пропорции</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2673"/>
        <source>Beveled</source>
        <translation>Выпуклый</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2678"/>
        <source>Inset</source>
        <translation>Вставка</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2733"/>
        <source>Auto</source>
        <translation>Автоматически</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2797"/>
        <source>ToolTip</source>
        <translation>Подсказка</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2813"/>
        <source>Orientation</source>
        <translation>Ориентация</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2821"/>
        <source>0 Degrees</source>
        <translation>0 Градусов</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2826"/>
        <source>90 Degrees</source>
        <translation>90 Градусов</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2831"/>
        <source>180 Degrees</source>
        <translation>180 Градусов</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2836"/>
        <source>270 Degrees</source>
        <translation>270 Градусов</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2857"/>
        <source>Read Only</source>
        <translation>Только для чтения</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2872"/>
        <source>Visible</source>
        <translation>Видимый</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2877"/>
        <source>Hidden</source>
        <translation>Невидимый</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2882"/>
        <source>Visible but doesn&apos;t print</source>
        <translation>Видимый, но не печатаемый</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2887"/>
        <source>Hidden but printable</source>
        <translation>Невидемый но печатаемый</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2895"/>
        <source>Required</source>
        <translation>Требуемый</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2905"/>
        <source>Locked</source>
        <translation>Заблокированный</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2934"/>
        <source>Subject</source>
        <translation>Cубъект</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2982"/>
        <source>Author</source>
        <translation>Автор</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1871"/>
        <source>Font Family</source>
        <translation>Шрифт</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1900"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2720"/>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1916"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2458"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="3002"/>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2175"/>
        <source>Coordinates</source>
        <translation>Координаты</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2203"/>
        <source>Absolute</source>
        <translation>Абсолютные</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2208"/>
        <source>Relative</source>
        <translation>Относительные</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2235"/>
        <source>Geometry</source>
        <translation>Геометрия</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2257"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2762"/>
        <source>Font</source>
        <translation>Шрифт</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2295"/>
        <source>Matrix</source>
        <translation>Матрица</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2314"/>
        <source>Cliping Path</source>
        <translation>Контур обрезки</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2333"/>
        <source>General</source>
        <translation>Общие</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2352"/>
        <source>Appearance</source>
        <translation>Внешний вид</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2371"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2428"/>
        <source>Options</source>
        <translation>Параметры</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2478"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2496"/>
        <source>Full</source>
        <translation>Заливка</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2483"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2531"/>
        <source>Stroke</source>
        <translation>Обводка</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2521"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2543"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2749"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2959"/>
        <source>Color</source>
        <translation>Цвет</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2623"/>
        <source>Borders and Colors</source>
        <translation>Границы и цвета</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2630"/>
        <source>Thin</source>
        <translation>Тонкая</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2635"/>
        <source>Medium</source>
        <translation>Средняя</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2640"/>
        <source>Thick</source>
        <translation>Толстая</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2655"/>
        <source>Fill Color</source>
        <translation>Цвет заливки</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1978"/>
        <source>Stroke Color</source>
        <translation>Цвет границы</translation>
    </message>
    <message>
        <source>Line width</source>
        <translation type="vanished">Толщина линии</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2004"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2508"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2569"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2972"/>
        <source>Opacity</source>
        <translation>Непрозрачность</translation>
    </message>
    <message>
        <source>Clipping path</source>
        <translation type="vanished">Контур обрезки</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="196"/>
        <source>Zip Code</source>
        <translation>Индекс</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="196"/>
        <source>Zip Code+4</source>
        <translation>Индекс+4</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="196"/>
        <source>Phone Number</source>
        <translation>Номер телефона</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="196"/>
        <source>Social Security Number</source>
        <translation>Номер социального страхования</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="202"/>
        <source>Check Mark</source>
        <translation type="unfinished">Галочка</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="204"/>
        <source>Comment</source>
        <translation>Комментарий</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="206"/>
        <source>Help</source>
        <translation>Справка</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="207"/>
        <source>Insert Text</source>
        <translation>Вставка текста</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="208"/>
        <source>Key</source>
        <translation>Ключ</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="209"/>
        <source>New Paragraph</source>
        <translation>Новый параграф</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="210"/>
        <source>Text Note</source>
        <translation>Текст</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="211"/>
        <source>Paragraph</source>
        <translation>Параграф</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="212"/>
        <source>Right Arrow</source>
        <translation>Стрелка в право</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="213"/>
        <source>Right Pointer</source>
        <translation>Указатель в право</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="215"/>
        <source>Up Arrow</source>
        <translation>Стрелка в верх</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="216"/>
        <source>Up Left Arrow</source>
        <translation>Стрелка в верх и влево</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="217"/>
        <source>Graph</source>
        <translation>График</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="218"/>
        <source>Paper Clip</source>
        <translation>Скрепка</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="219"/>
        <source>Attachment</source>
        <translation>Вложение</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="220"/>
        <source>Tag</source>
        <translation>Метка</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1215"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1222"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1235"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1242"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1284"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the fill color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Цвет заливки текста&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Изменить цвет заливки текста&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1290"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font Stroke color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the stroke color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Цвет обводки текста &lt;/span&gt;&lt;/p&gt;&lt;p&gt;Изменить цвет обводки текста&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1661"/>
        <source>Image</source>
        <translation>Рисунок</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1701"/>
        <source>Shading</source>
        <translation>Векторный рисунок с заливкой</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1723"/>
        <source>Image Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Do you want to set the current position?</source>
        <translation type="vanished">Вы хотите установить текущую позицию?</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2158"/>
        <source>Width</source>
        <translation>Ширина</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2185"/>
        <source>Height</source>
        <translation>Высота</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1681"/>
        <source>Path</source>
        <translation>Векторный рисунок</translation>
    </message>
    <message>
        <source>Fill Opacity</source>
        <translation type="vanished">Непрозрачность фона</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1965"/>
        <source>Full Color</source>
        <translation>Цвет заливки</translation>
    </message>
    <message>
        <source>Full Opacity</source>
        <translation type="obsolete">Непрозрачность фона</translation>
    </message>
    <message>
        <source>Stroke Opacity</source>
        <translation type="vanished">Непрозрачность края</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2864"/>
        <source>Form Field</source>
        <translation>Поле формы</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2787"/>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Export Item</source>
        <translation type="vanished">Значение для экспорта</translation>
    </message>
    <message>
        <source>Action type</source>
        <translation type="vanished">Действие</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="vanished">Жирный</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="vanished">Курсив</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1227"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1272"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Шрифт&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Изменить шрифт&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Text Mode&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the text mode&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Свойства текста&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Изменить свойства текста&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Цвет текста&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Изменить цвет текста&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font Stroke color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font stroke color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Цвет контура текста &lt;/span&gt;&lt;/p&gt;&lt;p&gt;Изменить цвет контура текста&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2604"/>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="399"/>
        <source>Goto a Page View</source>
        <translation>Открыть страницу</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="331"/>
        <source>Add an Action</source>
        <translation>Добавить действие</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="337"/>
        <source>Trigger</source>
        <translation>Триггер</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="345"/>
        <source>Mouse Up</source>
        <translation>Кнопка нажата</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="350"/>
        <source>Mouse Down</source>
        <translation>Кнопка отпущена</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="355"/>
        <source>Mouse Enter</source>
        <translation>Курсор наведен</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="360"/>
        <source>Mouse Exit</source>
        <translation>Курсор отведен</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="365"/>
        <source>On Receive Focus</source>
        <translation>Получение фокуса</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="370"/>
        <source>On Lose Focus</source>
        <translation>Потеря фокуса</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="391"/>
        <source>Action</source>
        <translation>Действие</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="404"/>
        <source>Open/execute a File</source>
        <translation>Открыть файл</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="409"/>
        <source>Open a web link</source>
        <translation>Открыть Web ссылку</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="414"/>
        <source>Reset form</source>
        <translation>Сбросить формы</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="419"/>
        <source>Show/Hide fields</source>
        <translation>Показать/скрыть формы</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="424"/>
        <source>Submit a form</source>
        <translation>Отправить формы</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="429"/>
        <source>Run a JavaScript</source>
        <translation>Выполнить JavaScript</translation>
    </message>
    <message>
        <source>Link Properties</source>
        <translation type="vanished">Свойства ссылки</translation>
    </message>
    <message>
        <source>Signature Properties</source>
        <translation type="vanished">Свойства подписи</translation>
    </message>
</context>
<context>
    <name>PageLayoutDialog</name>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="14"/>
        <source>Page Layout</source>
        <translation>Макет страницы</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="96"/>
        <source>Contents Size</source>
        <translation>Pазмер cодержания</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="108"/>
        <source>Left margin</source>
        <translation>Левое поле</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="122"/>
        <source>Top margin</source>
        <translation>Верхнее поле</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="136"/>
        <source>Right margin</source>
        <translation>Правое поле</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="150"/>
        <source>Bottom margin</source>
        <translation>Нижнее поле</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="53"/>
        <source>Page Size</source>
        <translation>Размер страницы</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="59"/>
        <source>Width</source>
        <translation>Ширина</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.cpp" line="236"/>
        <source> px</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.cpp" line="260"/>
        <source> in</source>
        <translation>дюймы</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.cpp" line="282"/>
        <source> mm</source>
        <translation>мм</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="76"/>
        <source>Height</source>
        <translation>Высота</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="167"/>
        <source>Units</source>
        <translation>Единицы измерения</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="178"/>
        <source>points</source>
        <translation>пикселы</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="183"/>
        <source>inch</source>
        <translation>дюймы</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="188"/>
        <source>millimeter</source>
        <translation>милиметры</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="196"/>
        <source>Page Range</source>
        <translation>Диапазон страниц</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="255"/>
        <source>Even and Odd pages</source>
        <translation>Четные и нечетные страницы</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="260"/>
        <source>Even pages</source>
        <translation>Четные страницы</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="265"/>
        <source>Odd pages</source>
        <translation>Нечетные страницы</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="283"/>
        <source>Pages from</source>
        <translation>Страницы   От</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="273"/>
        <source>Current Page</source>
        <translation>Текущая страница</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="202"/>
        <source>All Pages</source>
        <translation>Все страницы</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="231"/>
        <source>to:</source>
        <translation>До:</translation>
    </message>
    <message>
        <source>Only for Current Page</source>
        <translation type="obsolete">Только для текущей страницы</translation>
    </message>
    <message>
        <source>For All Pages</source>
        <translation type="obsolete">Для всех страниц</translation>
    </message>
</context>
<context>
    <name>PasswordOpenDialog</name>
    <message>
        <location filename="../src/passwordopendialog.ui" line="14"/>
        <source>Enter Password</source>
        <translation>Введите пароль</translation>
    </message>
    <message>
        <location filename="../src/passwordopendialog.ui" line="66"/>
        <source>Password:</source>
        <translation>Пароль:</translation>
    </message>
    <message>
        <location filename="../src/passwordopendialog.ui" line="56"/>
        <source>The file is protected. Please enter a Document Open Password</source>
        <translation>Пожалуйста, введите пароль для открытия документа</translation>
    </message>
</context>
<context>
    <name>PlainTextEdit</name>
    <message>
        <location filename="../src/docpage/texteditor/plaintextedit.cpp" line="234"/>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation>Этот шрифт не содержит эти символы. Попробуйте выбрать другой шрифт.</translation>
    </message>
</context>
<context>
    <name>PrintDialog</name>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="14"/>
        <source>Print Preview</source>
        <translation>Предварительный просмотр</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="35"/>
        <source>Printer</source>
        <translation>Принтер</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="50"/>
        <source>Properties</source>
        <translation>Свойства</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="74"/>
        <source>72</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="79"/>
        <source>150</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="84"/>
        <source>300</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="89"/>
        <source>600</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="94"/>
        <source>900</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="99"/>
        <source>1200</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="113"/>
        <source>DPI</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="237"/>
        <source>Antialiasing</source>
        <translation>Сглаживание</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="244"/>
        <source>Center</source>
        <translation>По центру</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="251"/>
        <source>Print as Grayscale</source>
        <translation>Печать в оттенках серого</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="258"/>
        <source>Aspect Ratio</source>
        <translation>Соотношение сторон</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="265"/>
        <source>Ignore aspect ratio</source>
        <translation>Игнорировать соотношение сторон</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="270"/>
        <source>Keep aspect ratio</source>
        <translation>Сохранять пропорции</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="275"/>
        <source>Keep aspect ratio by expanding</source>
        <translation>Сохранять пропорции за счет расширения</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="289"/>
        <source>Orientation</source>
        <translation>Ориентация</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="295"/>
        <source>Portrait</source>
        <translation>Портрет</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="302"/>
        <source>Landscape</source>
        <translation>Пейзаж</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="371"/>
        <source>Page</source>
        <translation>Страница</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="381"/>
        <source>of:</source>
        <translation>от :</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="66"/>
        <source>Resolution</source>
        <translation>Разрешение</translation>
    </message>
    <message>
        <source>Low</source>
        <translation type="vanished">Низкое</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation type="vanished">Обычное</translation>
    </message>
    <message>
        <source>High</source>
        <translation type="vanished">Высокое</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="129"/>
        <source>Page Range</source>
        <translation>Диапазон страниц</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="135"/>
        <source>All Pages</source>
        <translation>Все страницы</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="145"/>
        <source>Pages from</source>
        <translation>От</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="152"/>
        <source>Current Page</source>
        <translation>Текущая страница</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="175"/>
        <source>to:</source>
        <translation>До:</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="207"/>
        <source>Number of copies</source>
        <translation>Количество копий</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="221"/>
        <source>Collate</source>
        <translation>Разобрать по копиям</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.cpp" line="67"/>
        <source>of </source>
        <translation>от :</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.cpp" line="97"/>
        <source>Print</source>
        <translation>Печать</translation>
    </message>
</context>
<context>
    <name>QAttachment</name>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="19"/>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="19"/>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="19"/>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="19"/>
        <source>Location</source>
        <translation>Расположение</translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="34"/>
        <source>Insert</source>
        <translation>Вставить</translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="35"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="36"/>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="415"/>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="435"/>
        <source>Save As...</source>
        <translation>Сохранить как...</translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="98"/>
        <source>Page </source>
        <translation>Страница</translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="102"/>
        <source>Attachment Tab</source>
        <translation>Панель вложений</translation>
    </message>
</context>
<context>
    <name>QBookmarksTree</name>
    <message>
        <location filename="../src/leftTab/bookmark/qbookmarks.cpp" line="17"/>
        <source>Add Bookmark</source>
        <translation>Добавить закладку</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/qbookmarks.cpp" line="18"/>
        <source>Delete Bookmark</source>
        <translation>Удалить закладку</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/qbookmarks.cpp" line="19"/>
        <source>Bookmark Properties</source>
        <translation>Свойства Закладки</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/qbookmarks.cpp" line="20"/>
        <source>Set Destination</source>
        <translation>Установить текущую позицию</translation>
    </message>
</context>
<context>
    <name>QDocTab</name>
    <message>
        <location filename="../src/document/qdoctab.cpp" line="77"/>
        <source>untitled</source>
        <translation>Без названия</translation>
    </message>
    <message>
        <location filename="../src/document/qdoctab.cpp" line="620"/>
        <source>The clipboard doesn&apos;t contain an data</source>
        <translation>Буфер обмена не содержит данных</translation>
    </message>
</context>
<context>
    <name>QHTMLEditor</name>
    <message>
        <source>File</source>
        <translation type="obsolete">Файл</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Отменить</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">Повторить</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">Копировать</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">Вставить</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">Жирный</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">Курсив</translation>
    </message>
    <message>
        <source>Underline</source>
        <translation type="obsolete">Подчеркивание</translation>
    </message>
    <message>
        <source>Left</source>
        <translation type="obsolete">Слева</translation>
    </message>
    <message>
        <source>Right</source>
        <translation type="obsolete">Справа</translation>
    </message>
    <message>
        <source>Master PDF Editor</source>
        <translation type="obsolete">Master PDF Editor</translation>
    </message>
</context>
<context>
    <name>QHtmlFormEditor</name>
    <message>
        <source>File Actions</source>
        <translation type="vanished">Действия с файлами</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="vanished">Применить</translation>
    </message>
    <message>
        <source>Quit</source>
        <translation type="obsolete">Выход</translation>
    </message>
    <message>
        <source>Open...</source>
        <translation type="vanished">Открыть</translation>
    </message>
    <message>
        <source>Save &amp;As...</source>
        <translation type="vanished">Сохранить как...</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="vanished">Отменить</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="vanished">Повторить</translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation type="vanished">Вырезать</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="vanished">Копировать</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="vanished">Вставить</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="vanished">Жирный</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="vanished">Курсив</translation>
    </message>
    <message>
        <source>Underline</source>
        <translation type="vanished">Подчеркивание</translation>
    </message>
    <message>
        <source>Left</source>
        <translation type="vanished">Слева</translation>
    </message>
    <message>
        <source>C&amp;enter</source>
        <translation type="vanished">По центру</translation>
    </message>
    <message>
        <source>Right</source>
        <translation type="vanished">Справа</translation>
    </message>
    <message>
        <source>Justify</source>
        <translation type="vanished">Выровнять</translation>
    </message>
    <message>
        <source>Color...</source>
        <translation type="vanished">Цвет...</translation>
    </message>
    <message>
        <source>Format Actions</source>
        <translation type="vanished">Форматирование</translation>
    </message>
    <message>
        <source>Standard</source>
        <translation type="vanished">Стандартный</translation>
    </message>
    <message>
        <source>View current PDF</source>
        <translation type="vanished">Просмотр текущего PDF</translation>
    </message>
    <message>
        <source>Open File...</source>
        <translation type="vanished">Открыть файл...</translation>
    </message>
    <message>
        <source>HTML-Files (*.htm *.html);;All Files (*)</source>
        <translation type="vanished">HTML-Файлы (*.htm *.html);;All Files (*)</translation>
    </message>
    <message>
        <source>Master PDF Editor</source>
        <translation type="vanished">Master PDF Editor</translation>
    </message>
    <message>
        <source>The document has been modified.
Do you want to apply your changes?</source>
        <translation type="vanished">Документ был изменен.
Вы хотите сохранить изменения?</translation>
    </message>
    <message>
        <source>Save as...</source>
        <translation type="vanished">Сохранить как...</translation>
    </message>
</context>
<context>
    <name>QHttp</name>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="370"/>
        <source>HTTPS connection requested but SSL support not compiled in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="1579"/>
        <location filename="../src/qhttp/qhttp.cpp" line="2375"/>
        <source>Unknown error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="1830"/>
        <source>Request aborted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2386"/>
        <source>No server set to connect to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2550"/>
        <source>Wrong content length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2554"/>
        <source>Server closed connection unexpectedly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2609"/>
        <source>Connection refused (or timed out)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2612"/>
        <source>Host %1 not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2632"/>
        <source>HTTP request failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2726"/>
        <source>Invalid HTTP response header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2770"/>
        <source>Unknown authentication method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2780"/>
        <source>Proxy authentication required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2784"/>
        <source>Authentication required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2867"/>
        <location filename="../src/qhttp/qhttp.cpp" line="2915"/>
        <source>Invalid HTTP chunked body</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2953"/>
        <source>Error writing response to device</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QPDFDocument</name>
    <message>
        <location filename="../src/document/qpdfdocument.cpp" line="1108"/>
        <source>Error!</source>
        <translation>Ошибка!</translation>
    </message>
    <message>
        <location filename="../src/document/qpdfdocument.cpp" line="1527"/>
        <source>There was a problem with your form submission.</source>
        <translation>Не удалось отправить данные!</translation>
    </message>
    <message>
        <location filename="../src/document/qpdfdocument.cpp" line="1529"/>
        <source>Your form was successfully submitted!</source>
        <translation>Отправка данных выполнена успешно!</translation>
    </message>
</context>
<context>
    <name>QPDFPlainTextEdit</name>
    <message>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation type="vanished">Этот шрифт не содержит эти символы.
Попробуйте выбрать другой шрифт.</translation>
    </message>
</context>
<context>
    <name>QTabPage</name>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="73"/>
        <source>Pages</source>
        <translation>Страницы</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="78"/>
        <source>Enlarge Page Thumbnails</source>
        <translation>Увеличить миниатюры страниц</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="81"/>
        <source>Reduce Page Thumbnails</source>
        <translation>Уменьшить миниатюры страниц</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="86"/>
        <source>Delete Pages</source>
        <translation>Удалить страницы</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="99"/>
        <source>Bookmarks</source>
        <translation>Закладки</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="112"/>
        <source>Attachment</source>
        <translation>Вложения</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="119"/>
        <source>Search</source>
        <translation>Поиск</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="134"/>
        <source>Object Inspector</source>
        <translation>Инспектор объектов</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="385"/>
        <source>This document contains interactive form fields</source>
        <translation>Этот документ содержит PDF формы</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="386"/>
        <source>Highlight Fields</source>
        <translation>Выделить формы</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="404"/>
        <source>This document is protected. You do not have permissions to edit this document</source>
        <translation>Документ защищен. У Вас не хватает прав для редактирования этого документа.</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="405"/>
        <source>Change</source>
        <translation>Изменить</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="742"/>
        <source>There was an error printing the document</source>
        <translation>Произошла ошибка при печати документа</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="1167"/>
        <source>Insert Blank Pages</source>
        <translation>Вставить пустые страницы</translation>
    </message>
    <message>
        <source>Insert a blank page </source>
        <translation type="vanished">Вставить пустые страницы</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="1919"/>
        <source>Do you want to open?</source>
        <translation>Вы хотите открыть?</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="2550"/>
        <source>Are you sure you want to set the destination of the selected bookmark to the current location?</source>
        <translation>Вы уверены, что хотите установить текущую позицию?</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="2615"/>
        <source>untitled</source>
        <translation>Без названия</translation>
    </message>
</context>
<context>
    <name>QtColorComboBox</name>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="131"/>
        <source>More...</source>
        <translation>Больше...</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="263"/>
        <source>User color %1</source>
        <translation>Пользовательский цвет %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="314"/>
        <source>User Color 99</source>
        <translation>Пользовательский цвет 99</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="328"/>
        <source>Black</source>
        <translation>Черный</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="329"/>
        <source>White</source>
        <translation>Белый</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="330"/>
        <source>Red</source>
        <translation>Красный</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="331"/>
        <source>Dark red</source>
        <translation>Темно-красный</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="332"/>
        <source>Green</source>
        <translation>Зеленый</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="333"/>
        <source>Dark green</source>
        <translation>Темно-зеленый</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="334"/>
        <source>Blue</source>
        <translation>Синий</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="335"/>
        <source>Dark blue</source>
        <translation>Темно-синий</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="336"/>
        <source>Cyan</source>
        <translation>Голубой</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="337"/>
        <source>Dark cyan</source>
        <translation>Темно голубой</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="338"/>
        <source>Magenta</source>
        <translation>Пурпурный</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="339"/>
        <source>Dark magenta</source>
        <translation>Темно пурпурный</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="340"/>
        <source>Yellow</source>
        <translation>Жёлтый</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="341"/>
        <source>Dark yellow</source>
        <translation>Темно-желтый</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="342"/>
        <source>Gray</source>
        <translation>Серый</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="343"/>
        <source>Dark gray</source>
        <translation>Темно-серый</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="344"/>
        <source>Light gray</source>
        <translation>Светло-серый</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="346"/>
        <source>Transparent</source>
        <translation>Прозрачный фон</translation>
    </message>
</context>
<context>
    <name>RegDialog</name>
    <message>
        <location filename="../src/regdialog.ui" line="14"/>
        <source>Registration Info</source>
        <translation>Информация о регистрации</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="343"/>
        <source>Ok</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="145"/>
        <source>After your order has been completed, 
you will automatically 
receive your Registration code via e-mail.</source>
        <translation>После завершения вашего заказа
Вы  автоматически получите регистрационный код 
на вашу электронную почту.</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="116"/>
        <source>Buy Online</source>
        <translation>Купить онлайн</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="39"/>
        <location filename="../src/regdialog.ui" line="242"/>
        <source>Registration Code</source>
        <translation>Регистрационный код</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="46"/>
        <location filename="../src/regdialog.ui" line="262"/>
        <source>Activate</source>
        <translation>Активировать</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="69"/>
        <source>Offline Activation</source>
        <translation>Оффлайн Активация</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="170"/>
        <source>Registered version</source>
        <translation>Зарегистрированная версия</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="177"/>
        <source>If you want to register that license on another PC 
click &quot;Deactivate&quot; button. 

Then register it where you need.</source>
        <translation>Если Вы хотите зарегистрировать эту лицензию на другом компьютере
нажмите &quot;Деактивировать&quot; кнопку.

Затем зарегистрируйте там, где вам нужно.</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="203"/>
        <source>Deactivate</source>
        <translation>Деактивировать</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="282"/>
        <source>Back</source>
        <translation>Назад</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="252"/>
        <source>Activation Code</source>
        <translation>Код активации</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="302"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please send the ID key and Registration code to: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Once you receive your code enter it into &amp;quot;Activation code&amp;quot; field&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Пожалуйста, пришлите Идентификатор компьютера и регистрационный код на: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;После того как вы получите код введите его в поле:&amp;quot;Код активации&amp;quot; &lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="309"/>
        <source>ID</source>
        <translation>Идентификатор компьютера</translation>
    </message>
</context>
<context>
    <name>RotatePagesDlg</name>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="14"/>
        <source>Rotate</source>
        <translation>Поворот</translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="20"/>
        <source>Page Range</source>
        <translation>Диапазон страниц</translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="26"/>
        <source>Pages</source>
        <translation>Страницы</translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="52"/>
        <source>Sample: 1,6-8,12</source>
        <translation>Пример: 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="72"/>
        <source>Current Page</source>
        <translation>Текущая страница</translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="82"/>
        <source>Pages from</source>
        <translation>Страницы   От</translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="108"/>
        <source>to:</source>
        <translation>До:</translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="134"/>
        <source>Direction</source>
        <translation>Направление</translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="141"/>
        <source>Clockwise 90 degrees</source>
        <translation>По часовой стрелке на 90 градусов</translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="146"/>
        <source>180 degrees</source>
        <translation>180 градусов</translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="151"/>
        <source>Counterclockwise 90 degrees</source>
        <translation>Против часовой стрелки на 90 градусов </translation>
    </message>
</context>
<context>
    <name>SaveImageDialog</name>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="14"/>
        <source>Export to Image</source>
        <translation>Сохранить как изображение</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="20"/>
        <source>File Name</source>
        <translation>Имя файла</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="29"/>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="39"/>
        <source>Page Range</source>
        <translation>Диапазон страниц</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="51"/>
        <source>All Pages</source>
        <translation>Все страницы</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="67"/>
        <source>Pages from</source>
        <translation>Страницы  от:</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="84"/>
        <source>to:</source>
        <translation>до:</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="107"/>
        <source>Format</source>
        <translation>Формат</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="148"/>
        <location filename="../src/SaveImageDialog.ui" line="217"/>
        <source>JPEG</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="113"/>
        <source>BMP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="120"/>
        <source>PNG</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="158"/>
        <source>TIFF</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="127"/>
        <source>JPEG Quality</source>
        <translation>Качество JPEG</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="197"/>
        <source>LZW</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="202"/>
        <source>ZIP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="207"/>
        <source>CCITT FAX 3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="212"/>
        <source>CCITT FAX 4</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="134"/>
        <source>TIFF Compression</source>
        <translation>Сжатие TIFF</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="141"/>
        <source>Transparent</source>
        <translation>Прозрачный фон</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="225"/>
        <source>MultiPage</source>
        <translation>Многостраничный</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="235"/>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="241"/>
        <source>Width</source>
        <translation>Ширина</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="267"/>
        <source>Height</source>
        <translation>Высота</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="331"/>
        <source>Antialiasing</source>
        <translation>Сглаживание</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="293"/>
        <source>DPI</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="13"/>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="vanished">Сохранить</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="14"/>
        <source>Export</source>
        <translation>Экспорт</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="76"/>
        <source>Can&apos;t save to the file:</source>
        <translation>Невозможно создать файл:
</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="76"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
Файл может быть только для чтения или используется другим приложением.</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="430"/>
        <source>Save As TIFF Image</source>
        <translation>Сохранить как TIFF изображение</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="430"/>
        <source>TIFF Files (*.tif *.tiff)</source>
        <translation>TIFF Файлы (*.tif *.tiff)</translation>
    </message>
    <message>
        <source>Cannot save file :
</source>
        <translation type="obsolete">Невозможно создать файл:
</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="449"/>
        <source>Save As Image</source>
        <translation>Сохранить как изображение</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="449"/>
        <source>All Files (*)</source>
        <translation>Все Файлы (*)</translation>
    </message>
</context>
<context>
    <name>SaveOptimizedDialog</name>
    <message>
        <source>Master PDF Editor</source>
        <translation type="obsolete">Master PDF Editor</translation>
    </message>
    <message>
        <location filename="../src/SaveOptimizedDialog.ui" line="14"/>
        <source>Save Optimized As...</source>
        <translation>Оптимизировать и сохранить как...</translation>
    </message>
    <message>
        <location filename="../src/SaveOptimizedDialog.ui" line="39"/>
        <source>Remove unused elements</source>
        <translation>Удалить не используемые элементы</translation>
    </message>
    <message>
        <location filename="../src/SaveOptimizedDialog.ui" line="49"/>
        <source>Flatten form fields</source>
        <translation>Преобразовать поля форм в векторные рисунки</translation>
    </message>
    <message>
        <location filename="../src/SaveOptimizedDialog.ui" line="78"/>
        <source>Color and Grayscale Images</source>
        <translation>Цветные изображения</translation>
    </message>
    <message>
        <location filename="../src/SaveOptimizedDialog.ui" line="90"/>
        <location filename="../src/SaveOptimizedDialog.ui" line="233"/>
        <source>DPI</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/SaveOptimizedDialog.ui" line="123"/>
        <location filename="../src/SaveOptimizedDialog.ui" line="266"/>
        <source>Compression</source>
        <translation>Сжатие</translation>
    </message>
    <message>
        <location filename="../src/SaveOptimizedDialog.ui" line="143"/>
        <location filename="../src/SaveOptimizedDialog.ui" line="286"/>
        <source>ZIP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/SaveOptimizedDialog.ui" line="148"/>
        <source>JPEG</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/SaveOptimizedDialog.ui" line="156"/>
        <source>Lossless</source>
        <translation>Без потерь</translation>
    </message>
    <message>
        <location filename="../src/SaveOptimizedDialog.ui" line="176"/>
        <source>JPEG Quality</source>
        <translation>Качество JPEG</translation>
    </message>
    <message>
        <location filename="../src/SaveOptimizedDialog.ui" line="221"/>
        <source>Black and White Images</source>
        <translation>Черно-белые изображения</translation>
    </message>
    <message>
        <location filename="../src/SaveOptimizedDialog.ui" line="291"/>
        <source>CCITT Group 4</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/SaveOptimizedDialog.ui" line="296"/>
        <source>JBIG2</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>SearchFormTab</name>
    <message>
        <location filename="../src/leftTab/search/searchformtab.ui" line="14"/>
        <location filename="../src/leftTab/search/searchformtab.ui" line="20"/>
        <source>Search</source>
        <translation>Поиск</translation>
    </message>
    <message>
        <location filename="../src/leftTab/search/searchformtab.ui" line="46"/>
        <source>0 result</source>
        <translation>нет результата</translation>
    </message>
    <message>
        <location filename="../src/leftTab/search/searchformtab.cpp" line="11"/>
        <source>Case Sensitive</source>
        <translation>С учетом регистра</translation>
    </message>
    <message>
        <location filename="../src/leftTab/search/searchformtab.cpp" line="15"/>
        <source>Include Comments</source>
        <translation>Включая Комментарии</translation>
    </message>
    <message>
        <location filename="../src/leftTab/search/searchformtab.cpp" line="57"/>
        <source> result</source>
        <translation> реультат</translation>
    </message>
    <message>
        <location filename="../src/leftTab/search/searchformtab.cpp" line="59"/>
        <source> result(s)</source>
        <translation> результата</translation>
    </message>
    <message>
        <location filename="../src/leftTab/search/searchformtab.cpp" line="61"/>
        <source> results</source>
        <translation> результатов</translation>
    </message>
</context>
<context>
    <name>SearchLineEdit</name>
    <message>
        <location filename="../src/leftTab/search/searchlineedit.cpp" line="75"/>
        <source>Case Sensitive</source>
        <translation>С учетом регистра</translation>
    </message>
    <message>
        <location filename="../src/leftTab/search/searchlineedit.cpp" line="76"/>
        <source>Include Comments</source>
        <translation>Включая Комментарии</translation>
    </message>
</context>
<context>
    <name>SecurityDialog</name>
    <message>
        <location filename="../src/SecurityDialog.ui" line="14"/>
        <source>Security PDF</source>
        <translation>Безопасность</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="36"/>
        <source>Required a password to open the document</source>
        <translation>Требуется пароль для открытия документа</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="51"/>
        <source>Document Open Password</source>
        <translation>Пароль для открытия документа</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="71"/>
        <location filename="../src/SecurityDialog.ui" line="132"/>
        <source>Password Confirm</source>
        <translation>Подтвердите пароль</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="94"/>
        <source>Permissions</source>
        <translation>Разрешения</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="122"/>
        <source>Commenting</source>
        <translation>Комментирование</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="142"/>
        <source>Modifying document</source>
        <translation>Изменение документа</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="155"/>
        <source>Content copying for accessibility</source>
        <translation>Копирование содержимого для расширенного доступа </translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="168"/>
        <source>Printing the document</source>
        <translation>Разрешить печать документа</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="181"/>
        <source>Extract the content of the document</source>
        <translation>Извлечение содержимого документа</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="194"/>
        <source>Print a high resolution version of the document</source>
        <translation>Печать с высоким разрешением</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="207"/>
        <source>Fill in existing form or signature fields</source>
        <translation>Заполнять существующие формы или подписывать</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="223"/>
        <source>Permissions Password</source>
        <translation>Пароль владельца</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="233"/>
        <source>Manage Pages and bookmarks</source>
        <translation>Управление страницами и закладками</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.cpp" line="84"/>
        <source>Document Open password does not match.</source>
        <translation>Пароль для открытия документа не совпадает.</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.cpp" line="96"/>
        <source>Document Permission password does not match.</source>
        <translation>Пароль владельца документа не совпадает.</translation>
    </message>
</context>
<context>
    <name>SignatureDialog</name>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="14"/>
        <source>Signature Properties</source>
        <translation>Свойства подписи</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="52"/>
        <location filename="../src/signature/SignatureDialog.cpp" line="20"/>
        <source>Signature is VALID</source>
        <translation>Подпись действительна</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="72"/>
        <source>Details</source>
        <translation>Детали</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="129"/>
        <source>Signed by:</source>
        <translation>Подписанный:</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="78"/>
        <source>Reason:</source>
        <translation>Причина:</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="92"/>
        <source>Date:</source>
        <translation>Дата:</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="115"/>
        <source>Location:</source>
        <translation>Расположение:</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="169"/>
        <source>Validation Summary</source>
        <translation>Подробности проверки</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="185"/>
        <source>Signer&apos;s Contact Information:</source>
        <translation>Контактная информация:</translation>
    </message>
    <message>
        <source>Sing As</source>
        <translation type="vanished">Подписать как</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="367"/>
        <source>Show Image</source>
        <translation>Показывать изображение</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="396"/>
        <source>Stretch Image</source>
        <translation>Растянуть</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="389"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="406"/>
        <source>Show Text</source>
        <translation>Показавать текст</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="136"/>
        <location filename="../src/signature/SignatureDialog.ui" line="244"/>
        <source>Info</source>
        <translation>Информация</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="224"/>
        <source>Sign As</source>
        <translation>Подписать как</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="254"/>
        <source>Text For Signing</source>
        <translation>Текст для подписания</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="266"/>
        <source>Location</source>
        <translation>Расположение</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="282"/>
        <source>Reason</source>
        <translation>Причина</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="299"/>
        <source>Lock document after signing</source>
        <translation>Блокировка документ после подписания</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="325"/>
        <source>Signature Preview</source>
        <translation>Предварительный просмотр подписи</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="39"/>
        <source>I have reviewed this document</source>
        <translation>Я рецензировал этот документ</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="40"/>
        <source>I am approving this document</source>
        <translation>Я одобряю этот документ</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="41"/>
        <source>I attest to the accuracy and integrity of this document</source>
        <translation>Я свидетельствую о точности и целостности этого документа</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="42"/>
        <source>I agree to specified parts of this document</source>
        <translation>Я согласен с определёнными частями этого документа</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="17"/>
        <source>The document has been altered or corrupted since the signatures was applied.</source>
        <translation>Документ был изменен или поврежден с момента применения Подписи.</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="18"/>
        <source>Document has not been changed since the signatures was applied.</source>
        <translation>Документ не был изменен с момента применения этой подписи.</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="19"/>
        <source>Signature is INVALID</source>
        <translation>Подпись недействительна</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="21"/>
        <source>Signature validity is UNKNOWN</source>
        <translation>Подпись действительна но подлинность подписанта не известна</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="22"/>
        <source>This certificate is not trusted</source>
        <translation>Этот сертификат не является доверенным</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="23"/>
        <source>The signers identity is unknown because it has not been include in your list of trusted identities and none of its parent certificates is trust identities.</source>
        <translation>Подлинность подписанта не известна, потому что он не включён в список доверенных личностей и сертификаты его опекунов не пренадлежат доверенным личностями.</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="24"/>
        <source>Error during signature verification.</source>
        <translation>Произошла ошибка при проверке подписи.</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="25"/>
        <source>Details: The signature byte range is invalid</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="26"/>
        <source>I am the author of this document</source>
        <translation>Я автор этого документа</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="84"/>
        <source>Open Image</source>
        <translation>Открыть изображение</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="84"/>
        <source>Image Files (*.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation></translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="obsolete">Обзор</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="363"/>
        <source>Open File</source>
        <translation>Открыть файл</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="363"/>
        <source>p12 Files (*.p12)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="348"/>
        <source>A error occurred during the signature verification!</source>
        <translation>Произошла ошибка при проверке подписи!</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="188"/>
        <source>Browse...</source>
        <translation>Обзор...</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="265"/>
        <source>A password is required to open certificate:</source>
        <translation>Пожалуйста, введите пароль для открытия сертификата:</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="152"/>
        <source>Sign</source>
        <translation>Подписать</translation>
    </message>
</context>
<context>
    <name>SignatureInfoDialog</name>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="14"/>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="34"/>
        <source>Info</source>
        <translation>Информация</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="40"/>
        <source>Issuer</source>
        <translation>Эмитент</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="46"/>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="132"/>
        <source>Common Name (CN)</source>
        <translation>Общее имя</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="60"/>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="139"/>
        <source>Organization (O)</source>
        <translation>Организация</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="74"/>
        <source>Organizational Unit (OU)</source>
        <translation>Подразделение </translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="88"/>
        <source>Serial Number</source>
        <translation>Серийный номер</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="102"/>
        <source>Algorithm</source>
        <translation>Алгоритм</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="119"/>
        <source>Subject</source>
        <translation>Тема</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="153"/>
        <source>Email</source>
        <translation>Эл. адрес</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="166"/>
        <source>Validity</source>
        <translation>Период действия</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="172"/>
        <source>Not Before</source>
        <translation>Не раньше</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="179"/>
        <source>Not After</source>
        <translation>Не поэже</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="209"/>
        <source>SHA-1:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="229"/>
        <source>MD5</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="278"/>
        <source>Add to Trusted Identities</source>
        <translation>Добавить к доверенным</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="286"/>
        <source>Data</source>
        <translation>Данные</translation>
    </message>
</context>
<context>
    <name>StickyNoteDlg</name>
    <message>
        <location filename="../src/forms/StickyNoteDlg.ui" line="17"/>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="vanished">Параметры</translation>
    </message>
</context>
<context>
    <name>TextDialog</name>
    <message>
        <source>Text Settings</source>
        <translation type="obsolete">Параметры текста</translation>
    </message>
    <message>
        <source>Font:</source>
        <translation type="obsolete">Шрифт:</translation>
    </message>
    <message>
        <source>Font size:</source>
        <translation type="obsolete">Размер шрифта:</translation>
    </message>
    <message>
        <source>Font color:</source>
        <translation type="obsolete">Цвет шрифта:</translation>
    </message>
</context>
</TS>
